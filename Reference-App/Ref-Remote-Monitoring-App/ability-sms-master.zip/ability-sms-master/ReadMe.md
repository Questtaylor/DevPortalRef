This is an example application for simple monitoring. It is an angular 7 application that connects to the ability platform to display data for devices.

To run the project, the following needs to be done:

1. Switch to the ABB.Ability.SMS.SPA directory.
2. Check if you have angular installed at the command line by running `ng version`. If that command returns an error, run `npm install -g @angular/cli`.
3. Run `npm install` 
4. Run `npm run build`. This will build the 'abb-controls' and 'ability-api' libraries.
5. Finally, you can run `ng serve` to run the project.