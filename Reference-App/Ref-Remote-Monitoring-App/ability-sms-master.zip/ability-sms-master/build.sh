#!/usr/bin/env bash

echo "Building the Single Page Application"
cd ABB.Ability.SMS.SPA
rm -rf node_modules
rm -rf dist

npm install
npm run build-prod

echo "Building the Web API Application"
cd ../ABB.Ability.SMS.API
rm -rf wwwroot/*

echo "Copying the Single Page Application into webroot of Web API"
cp -R ../ABB.Ability.SMS.SPA/dist/ABB-Ability-SMS-SPA/* wwwroot/

dotnet clean
dotnet restore "ABB.Ability.SMS.API.csproj"
dotnet build
dotnet publish "ABB.Ability.SMS.API.csproj"

echo "Now, run the following to start the project: dotnet run -p .ABB.Ability.SMS.API.csprojcsproj --launch-profile web"
