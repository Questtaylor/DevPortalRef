# ABBAbilitySMSSPA

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 7.0.4.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4300/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Building and publishing docker image

```
docker login -u AbilityMTPoC -p "wULKal6iUSOoP8uMZHf40TBsazRiJf=c" https://abilitymtpoc.azurecr.io (First time only, not needed later as credentials will be stored locally after the first time)
docker build -t abilitymtpoc.azurecr.io/abb.ability.poc.mt.refui:latest . (from a terminal/command prompt in the ABB.Ability.PoC.MT.Portal directory)
docker push abilitymtpoc.azurecr.io/abb.ability.poc.mt.refui:latest
```

## Running the docker image
Please see below for the list of environment variables defined in [Dockerfile](./Dockerfile). These environment variables can be passed to runtime when the docker container is innstantiated. Note that the docker file is built with some defaults as shown below but should be overriden when deployed as needed

```
# Customizable environment variables
# HTTP Port run in the docker container
ENV WEBSITES_PORT=4300

# Verbose flag to enable/disable logging
ENV VERBOSE=false

# API Management URL for the regional level APIs
ENV API_URL=https://abiapiapmarc1usedev.azure-api.net

# B2C Tenant
ENV TENANT=abilityplatform

# Reference Solution namespace (shouldn't change and will be constant)
ENV SOLUTION_NAMESPACE=sms

# Client Id of the Reference UI application
ENV CLIENT_ID=a3f55978-5f06-4596-b3d5-89d51362b19b

# Policy prefix and suffix (shouldn't change and will be constant)
ENV POLICY_PREFIX=B2C_1A_
ENV POLICY_SUFFIX=_RP

# Redirect URI needs to be the same as registered in the portal application
ENV REDIRECT_URI=https://abilitymtsmsui.azurewebsites.net

# Reference UI
ENV REFERENCEUI_API=http://localhost:4500

# Telemetry Hub name
ENV TELEMETRY_HUB_NAME=teleHub

```

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
