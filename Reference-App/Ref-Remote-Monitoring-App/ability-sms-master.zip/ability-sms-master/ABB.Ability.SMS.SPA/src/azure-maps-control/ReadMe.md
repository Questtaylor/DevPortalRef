# Mesh Systems
The typescript definition for version 2.0.1 of the azure maps control is broken. We're adding the package directly to source control here 
in order to have successful builds.

# Azure Maps Web Control

The Azure Maps Web Control lets you customize interactive maps with your own content and imagery for display in your web or mobile applications. This control makes use of WebGL, allowing you to render large data sets with high performance. Develop with the control using JavaScript or TypeScript.

## How to Install

You can embed the Azure Maps Web Control source code into your app by installing the NPM package:

> npm install azure-maps-control

This package includes a minified version of the source code as well as the TypeScript definitions for the Azure Maps Web Control. 


Alternatively, you can also reference the hosted version of the Azure Maps Web Control by adding the following script tags to your application. 

```html
<link rel="stylesheet" href="https://atlas.microsoft.com/sdk/css/atlas.min.css?api-version=2" type="text/css" />
<script src="https://atlas.microsoft.com/sdk/js/atlas.min.js?api-version=2"></script>
```

## Developer Resources

* [Quickstart Guide](https://docs.microsoft.com/azure/azure-maps/quick-demo-map-app)
* [Setup your Azure Maps account]( https://docs.microsoft.com/azure/azure-maps/how-to-manage-account-keys)
* [Tutorials]( https://docs.microsoft.com/azure/azure-maps/tutorial-search-location)
* [How-to Documentation](https://docs.microsoft.com/azure/azure-maps/how-to-use-map-control)
* [API Reference Documentation](https://docs.microsoft.com/javascript/api/azure-maps-control/)
* [Code Samples](https://aka.ms/azuremapssamples)

## Related Packages

* [Azure Maps Search Module](https://www.npmjs.com/package/azure-maps-rest) – A JavaScript library that makes it easy to work with the Azure Maps REST services in any web or NodeJS app. 