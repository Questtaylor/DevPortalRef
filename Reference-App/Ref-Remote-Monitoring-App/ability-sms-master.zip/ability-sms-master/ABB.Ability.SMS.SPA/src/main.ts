import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

// if (environment.production) {
//   enableProdMode();
// }

// platformBrowserDynamic().bootstrapModule(AppModule)
//   .catch(err => console.error(err));

(async () => {
  if (environment.production) {
    const response = await fetch('/api/configuration');
    const config = await response.json();

    environment['apiUrl'] = config.apiUrl;
    environment['msal'] = config.msal;
    environment['provisionUrl'] = config.provisionUrl;
    environment['referenceUiApi'] = config.referenceUiApi;
    environment['showFakeDevices'] = config.showFakeDevices;
    environment['verbose'] = config.verbose;

    console.log(environment['apiUrl']);
    enableProdMode();
  }
  platformBrowserDynamic().bootstrapModule(AppModule)
    .catch(err => console.error(err));
})();
