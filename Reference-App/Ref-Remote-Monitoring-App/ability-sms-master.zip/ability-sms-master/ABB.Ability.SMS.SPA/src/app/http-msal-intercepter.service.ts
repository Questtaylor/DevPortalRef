import {Injectable} from '@angular/core';
import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {map, catchError} from 'rxjs/operators';
import {NotificationMessage, NotificationsService} from 'abb-controls';

@Injectable()
export class HttpMsalInterceptorService implements HttpInterceptor {
  B2CTodoAccessTokenKey = 'b2c.access.token';

  constructor(private notificationsService: NotificationsService) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token: string = sessionStorage.getItem(this.B2CTodoAccessTokenKey);

    if (token) {
        req = req.clone({ headers: req.headers.set('Authorization', 'Bearer ' + token) });
    }

    if (!req.headers.has('Content-Type')) {
        req = req.clone({ headers: req.headers.set('Content-Type', 'application/json') });
    }

    req = req.clone({ headers: req.headers.set('Accept', 'application/json') });

    return next.handle(req).pipe(
        map((event: HttpEvent<any>) => {
            if (event instanceof HttpResponse) {
                console.log('event--->>>', event);
            }
            return event;
        }),
        catchError((error: HttpErrorResponse) => {
            // let data = {};
            // data = {
            //     reason: error && error.error.reason ? error.error.reason : '',
            //     status: error.status
            // };
            console.log(error);
            if (error.status === 401 || error.status === 403) {
                this.notificationsService.send(new NotificationMessage('You are not authorized!', 'error', true, false));
            }
            return throwError(error);
        }));
  }
}

