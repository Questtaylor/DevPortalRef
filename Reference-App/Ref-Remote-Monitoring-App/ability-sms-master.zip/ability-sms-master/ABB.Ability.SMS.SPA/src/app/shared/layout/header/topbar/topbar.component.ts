import {Component, Input} from '@angular/core';

import {MenuItem} from '../menu/menu.models';
import {MenuService} from '../menu/menu.service';
import {Store, select} from '@ngrx/store';
import {AppState} from 'src/app/redux-core/redux-core';
import {Observable} from 'rxjs';

@Component({
  selector: 'abb-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.scss']
})
export class TopbarComponent {

  @Input() public applicationTitle;
  public menu: Array<MenuItem>;
  public authenticated$: Observable<boolean>;

  constructor(
    menuSvc: MenuService,
    store: Store<AppState>
  ) {
    this.menu = menuSvc.fetch();
    this.authenticated$ = store.pipe(select(x => x.auth.authenticated));
  }

}

