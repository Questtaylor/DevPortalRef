import {NgModule, OnDestroy} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Store, select} from '@ngrx/store';
import {PlatformeventsComponent} from './platformevents.component';
import {RouterModule} from '@angular/router';
import {AppState} from 'src/app/redux-core/redux-core';
import {Observable, Subscription} from 'rxjs';
import {CustomPlatformEvent} from '../../../../../services/signal-r/models/custom-platform-event';
import {TimeAgoPipe} from './time-ago.pipe';
import {PlatformEventsReduxModule} from './platform-events-redux/platform-events-redux.module';
import {AddOnePlatformEvent} from './platform-events-redux/platform-events-redux.actions';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    PlatformEventsReduxModule
  ],
  declarations: [PlatformeventsComponent, TimeAgoPipe],
  exports: [PlatformeventsComponent],
  entryComponents: [
    PlatformeventsComponent
  ]
})
export class PlatformeventsModule implements OnDestroy {
  private platformEventsSubscription: Subscription;

  private platfromEvents$: Observable<CustomPlatformEvent[]>;

  constructor(private store: Store<AppState>) {
    this.platfromEvents$ = this.store.pipe(select((state: AppState) => state.signalR.platformEvents));

    this.platformEventsSubscription = this.platfromEvents$.subscribe((platformevent: CustomPlatformEvent[]) => {
      if (platformevent
          && platformevent.length > 0
          && platformevent[0].eventType.indexOf('MethodInvoked') === -1
          && platformevent[0].eventType.indexOf('Method.Invoked') === -1) {
        this.store.dispatch(new AddOnePlatformEvent({customPlatformEvent: platformevent[0]}));
      }
    });
  }

  ngOnDestroy(): void {
    if (this.platformEventsSubscription) {
      this.platformEventsSubscription.unsubscribe();
    }
  }
}
