import {createFeatureSelector, createSelector} from '@ngrx/store';
import {platformeventAdapter, PlatformeventsState} from './platform-events-redux.reducer';

export const platformeventState = createFeatureSelector<PlatformeventsState>('platformEvents');

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal,
} = platformeventAdapter.getSelectors(platformeventState);

export const seletSelectedPlatformEvent = state => state.platformEvents;

export const selectedPlatformEvent = createSelector(
  seletSelectedPlatformEvent,
  platformEvents => platformEvents.selectedPlatformevent
);

// export const seletOrginalPlatformeventPayload = state => state.platformEvents;

export const orginalPlatformeventPayload = createSelector(
  seletSelectedPlatformEvent,
  platformEvents => platformEvents.selectedPlatformevent.originalPayload
);

export const rediretionToEventObject = createSelector(
  seletSelectedPlatformEvent,
  platformEvents => platformEvents.selectedPlatformevent.redirectHref
);
