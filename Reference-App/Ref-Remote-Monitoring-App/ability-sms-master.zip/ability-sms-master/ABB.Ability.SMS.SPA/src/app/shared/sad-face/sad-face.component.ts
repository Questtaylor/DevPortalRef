import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-sad-face',
  templateUrl: './sad-face.component.html',
  styleUrls: ['./sad-face.component.scss']
})
export class SadFaceComponent {

  @Input() public message: string;
  @Input() public stackTrace: string;
}
