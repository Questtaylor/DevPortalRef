import {Injectable} from '@angular/core';
import {Actions} from '@ngrx/effects';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';


@Injectable()
export class PlatformeventsReduxEffects {

  // @Effect({dispatch: false})
  // modalPlatformEvent$ = this.actions$.pipe(
  //   ofType<OpenPlatformEvent>(PlatformEventsActionTypes.OPEN_PLATFORM_EVENT),
  //   tap(action => {
  //     console.log(action);
  //   })
  // );


  constructor(private actions$: Actions, private modalService: NgbModal) {


  }


}
