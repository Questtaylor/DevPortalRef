export interface ObjectDefinition {
    variables?: {
      [name: string]: { dataType: string }
    };
    alarms?: {
      [name: string]: { description: string, payload: {} }
    };
    events?: {
      [name: string]: { description: string, payload: {} }
    };
    methods?: {
      [name: string]: { input?: {}, output?: {} }
    };

    [key: string]: any;
  }
