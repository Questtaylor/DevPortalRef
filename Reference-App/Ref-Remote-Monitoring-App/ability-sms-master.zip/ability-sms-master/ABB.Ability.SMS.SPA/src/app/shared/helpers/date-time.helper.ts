export class DateTimeHelper {

    public static mergeTimeWithDate(time: string, dateISOString: string, addOneDay = false): string {
      if (time) {
        const hours: number = +time.split(':')[0];
        const minutes: number = +time.split(':')[1];
        const date = new Date(dateISOString);
        date.setHours(hours, minutes);
        return date.toISOString();
      } else if (addOneDay && dateISOString) {
        const date = new Date(dateISOString);
        date.setDate(date.getDate() + 1);
        date.setSeconds(date.getSeconds() - 1);
        return date.toISOString();
      }
      return dateISOString;
    }

  }
