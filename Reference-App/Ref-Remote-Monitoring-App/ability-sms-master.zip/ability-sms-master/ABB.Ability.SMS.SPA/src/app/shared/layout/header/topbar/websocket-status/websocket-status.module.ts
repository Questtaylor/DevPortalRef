import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {WebsocketStatusComponent} from './websocket-status/websocket-status.component';

@NgModule({
  declarations: [
    WebsocketStatusComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    WebsocketStatusComponent
  ]
})
export class WebsocketStatusModule {
}
