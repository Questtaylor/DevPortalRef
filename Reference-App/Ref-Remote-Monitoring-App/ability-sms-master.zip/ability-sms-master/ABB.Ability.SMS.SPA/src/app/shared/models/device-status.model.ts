export class StatusInfo {
    constructor(
      public status: number,
      public description: string,
      public colorClass: string) {

    }
}

export function createStatusInfo(status: number) {
    let description: string;
    let colorClass: string;
    switch (status) {
        case 0:
            description = '100% operational';
            colorClass = 'text-green';
            break;
        case 1:
            description = 'Running on battery';
            colorClass = 'text-yellow';
            break;
        case 2:
            description = 'Battery low';
            colorClass = 'text-red';
            break;
    }
    return new StatusInfo(status, description, colorClass);
}
