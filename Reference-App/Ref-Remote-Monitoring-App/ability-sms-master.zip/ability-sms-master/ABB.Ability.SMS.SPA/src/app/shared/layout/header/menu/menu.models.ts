export class MenuItem {
    displayName: string;
    routerLink: string;
    icon?: string;
    children?: MenuItem[];
  }
