import {Injectable} from '@angular/core';
import {MenuItem} from './menu.models';
import { Store, select } from '@ngrx/store';
import { AppState } from 'src/app/redux-core/redux-core';

const NAVIGATIONMENU: MenuItem[] = [
  {
    displayName: 'Dashboard',
    routerLink: 'dashboard'
  },
  // {
  //   displayName: 'Cases',
  //   routerLink: null,
  //   children: [
  //     {
  //       displayName: 'Edge',
  //       routerLink: 'cases/edge'
  //     }
  //   ]
  // },
];

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  private items: Array<MenuItem> = [];

  constructor(store: Store<AppState>) {
    store.pipe(select(s => s.auth.authenticated)).subscribe(s => {
      this.setItems(s);
    });
  }

  setItems(isAuthenticated: boolean): void {
    if (isAuthenticated) {
      this.items = this.items.concat(NAVIGATIONMENU);
    }
  }

  addItem(displayName: string, routerLink: string, icon?: string) {
    this.items.push({
      displayName,
      routerLink,
      icon
    });
  }

  fetch(): Array<MenuItem> {
    if (this.items.length <= 0) {
      console.warn('[WARNING] Empty collection of menu items!');
    }
    return this.items;
  }

}
