export function distinct<T>(array: T[]): Array<T> {
    return (array || []).reduce((reducer, item) => {
        if (reducer.indexOf(item) === -1) {
          reducer.push(item);
        }
        return reducer;
      },
      []
    );
  }
