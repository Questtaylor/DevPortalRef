import {Component, OnInit, OnDestroy} from '@angular/core';
import {Observable, Subscription} from 'rxjs';
import {AppState} from '../../../../../../redux-core/redux-core';
import {select, Store} from '@ngrx/store';
import {map, tap} from 'rxjs/operators';
import {SignalRService} from '../../../../../../services/signal-r/signal-r.service';

@Component({
  selector: 'abb-websocket-status',
  templateUrl: './websocket-status.component.html',
  styleUrls: ['./websocket-status.component.scss']
})
export class WebsocketStatusComponent implements OnInit, OnDestroy {

  public isUserAuthenticated$: Observable<boolean>;
  public connectionStatus: string;
  public connectionStatusTooltip: string;

  private webSocketStatusSubscription: Subscription;

  constructor(private store: Store<AppState>, private signalRService: SignalRService) {
  }

  ngOnInit() {
    this.isUserAuthenticated$ = this.store.pipe(
      select(s => s.auth.authenticated)
    );

    this.webSocketStatusSubscription = this.store.pipe(select(s => s.signalR.connectionState),
      tap(m => this.connectionStatus = m),
      map(m => {
        switch (m) {
          case 'connected':
            return 'Connected to backend API. Application is fully operational.';
          case 'connecting':
            return 'Connecting to backend API... Please wait...';
          default:
            return 'Disconnected from backend API. Reference UI will not work with ABB Ability subscriptions. Click to try to reconnect';
        }
      }),
      tap(c => this.connectionStatusTooltip = c)
    ).subscribe();
  }

  public tryToReconnect() {
    if (this.connectionStatus === 'disconnected') {
      this.signalRService.init();
    }
  }

  ngOnDestroy(): void {
    if (this.webSocketStatusSubscription) {
      this.webSocketStatusSubscription.unsubscribe();
    }
  }
}
