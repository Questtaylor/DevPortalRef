import {FormControl} from '@angular/forms';

export function validateJsonFormControl(formControl: FormControl): { json: true, jsonParseError: string } | null {
  //FormControl's value is changed only when new VALID json is inputted to the control. Invalid jsons are not propagated into FormControl
  const value = formControl.value;

  if (value) {
    try {
      if (value instanceof Object) {
        return null;
      } else {
        return {json: true, jsonParseError: 'Please provide a JSON object'};
      }
    } catch (e) {
      return {json: true, jsonParseError: `Invalid JSON. Details: ${e}`};
    }
  } else {
    return null;
  }
}
