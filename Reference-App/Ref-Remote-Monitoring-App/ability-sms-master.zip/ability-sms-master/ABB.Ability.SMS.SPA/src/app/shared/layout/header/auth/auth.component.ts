import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs';
import {Store, select} from '@ngrx/store';
import {AppState} from 'src/app/redux-core/redux-core';
import { ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';
import { MsalLogout, MsalLogin, Login } from 'src/app/redux-core/auth-redux/auth.actions';
import { MsalService } from 'src/app/services/msal.service';
import { Router } from '@angular/router';

@Component({
  selector: 'abb-nav-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss']
})
export class AuthComponent implements OnInit {

  public username$: Observable<string>;
  public authenticated$: Observable<boolean>;
  public tenantParam: string;
  public tenantName = localStorage.getItem('tenantName');

  constructor(private store: Store<AppState>, private route: ActivatedRoute, private msalService: MsalService, private router: Router) {
    this.msalService.loginSuccess.subscribe((data) => {
      if (data) {
          const user = this.msalService.getUser();
          this.store.dispatch(new Login({userName: user.name, authenticated: true}));
          this.router.navigateByUrl('/');
      }
    });
  }

  ngOnInit() {
    this.username$ = this.store.pipe(select((state: AppState) => state.auth.userName));
    this.authenticated$ = this.store.pipe(select((state: AppState) => state.auth.authenticated));
    this.route.queryParams.pipe(filter(params => params.tenant !== undefined)).subscribe(params => {this.tenantParam = params.tenant; });

  }

  logIn() {
    if (this.tenantParam || this.tenantName) {
      this.store.dispatch(new MsalLogin({tenant: this.tenantParam ? this.tenantParam : this.tenantName}));
    }
  }

  logOut() {
    this.store.dispatch(new MsalLogout());
  }
}
