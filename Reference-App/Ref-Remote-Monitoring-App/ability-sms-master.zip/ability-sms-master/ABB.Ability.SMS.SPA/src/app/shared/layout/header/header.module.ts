import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TopbarComponent } from './topbar/topbar.component';
import { AuthComponent } from './auth/auth.component';
import {RouterModule} from '@angular/router';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {PlatformeventsModule} from './topbar/platformevents/platformevents.module';
import {BreadcrumbsModule} from 'ng6-breadcrumbs';
import { WebsocketStatusModule } from './topbar/websocket-status/websocket-status.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    NgbModule,
    FormsModule,
    PlatformeventsModule,
    BreadcrumbsModule,
    WebsocketStatusModule
  ],
  declarations: [TopbarComponent, AuthComponent],
  exports: [TopbarComponent]
})
export class HeaderModule { }
