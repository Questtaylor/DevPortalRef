export interface Location {
    objectId: string;
    latLon: {
        lat: number,
        lon: number
    };
}

export interface LastLocation extends Location {
    timestamp: string;
}
