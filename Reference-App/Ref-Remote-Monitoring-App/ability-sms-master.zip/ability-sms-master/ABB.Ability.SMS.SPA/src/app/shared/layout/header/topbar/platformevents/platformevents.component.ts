import {Component, OnInit} from '@angular/core';
import {CustomPlatformEvent} from '../../../../../services/signal-r/models/custom-platform-event';
import {select, Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {AppState} from 'src/app/redux-core/redux-core';
import {OpenPlatformEvent, RemoveAllPlatformEvents, RemoveOnePlatformEvent} from './platform-events-redux/platform-events-redux.actions';
import {
  orginalPlatformeventPayload,
  rediretionToEventObject,
  selectAll,
  selectTotal
} from './platform-events-redux/platform-events-redux-selector';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import { filter, map } from 'rxjs/operators';


@Component({
  selector: 'abb-platformevents',
  templateUrl: './platformevents.component.html',
  styleUrls: ['./platformevents.component.scss']
})
export class PlatformeventsComponent implements OnInit {

  public platfromEvents$: Observable<CustomPlatformEvent[]>;
  public platformEventsTotal$: Observable<number>;
  public selectedPlatformEvent$: Observable<CustomPlatformEvent>;
  public rediretionToEventObject$: Observable<string>;

  constructor(private store: Store<AppState>, private modalService: NgbModal) {
  }

  ngOnInit() {
    this.platfromEvents$ = this.store.pipe(select(selectAll),
      map(events => events.filter(e => e.eventType.indexOf('MethodInvoked') === -1 && e.eventType.indexOf('Method.Invoked') === -1)));
    this.platformEventsTotal$ = this.store.pipe(select(selectTotal));
    this.selectedPlatformEvent$ = this.store.pipe(select(orginalPlatformeventPayload));
    this.rediretionToEventObject$ = this.store.pipe(select(rediretionToEventObject));
  }

  public openDetails(content, event) {
    this.store.dispatch(new OpenPlatformEvent({customPlatformEvent: event}));
    this.modalService.open(content, {size: 'lg'});
  }

  public removeEventPlatform(customPlatformEvent: CustomPlatformEvent) {
    this.store.dispatch(new RemoveOnePlatformEvent({customPlatformEvent: customPlatformEvent}));
  }

  public onDismissAll() {
    this.store.dispatch(new RemoveAllPlatformEvents());
  }


}
