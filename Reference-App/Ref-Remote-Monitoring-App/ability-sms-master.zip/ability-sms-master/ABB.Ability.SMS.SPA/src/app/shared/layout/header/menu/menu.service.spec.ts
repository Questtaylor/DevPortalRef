import {inject, TestBed} from '@angular/core/testing';

import {MenuService} from './menu.service';
import { MsalService } from 'src/app/services/msal.service';

describe('MenuService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MenuService, MsalService]
    });
  });

  it('should be created', inject([MenuService, MsalService], (service: MenuService, msal: MsalService) => {
    expect(service).toBeTruthy();
  }));
});
