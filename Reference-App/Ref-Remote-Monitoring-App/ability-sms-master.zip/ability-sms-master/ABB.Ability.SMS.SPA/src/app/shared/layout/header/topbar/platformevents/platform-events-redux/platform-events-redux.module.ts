import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {StoreModule} from '@ngrx/store';
import {platformeventReducer} from './platform-events-redux.reducer';
import {EffectsModule} from '@ngrx/effects';
import {PlatformeventsReduxEffects} from './platform-events-redux.effects';

@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature('platformEvents', platformeventReducer),
    EffectsModule.forFeature([PlatformeventsReduxEffects]),
  ],
  declarations: []
})
export class PlatformEventsReduxModule { }
