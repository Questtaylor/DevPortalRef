import { Location } from 'src/app/shared/models/location.models';
import { Device } from './device.model';

export interface TableDevice extends Location {
    name: string;
    model: string;
    type: string;
    firmwareVersion: string;
    isProvisioned: boolean;
    isProvisionedPending: boolean;
    serialNumber: string;
    locationName: string;
    status: number;
    fake: boolean;
}

export function mapFromDevice(device: Device): TableDevice {
    return <TableDevice> ({
        name: device.name,
        objectId: device.objectId,
        model: device.model,
        type: device.type,
        serialNumber: device.properties && device.properties.serialNumber ? device.properties.serialNumber.value : '',
        firmwareVersion: device.properties && device.properties.firmwareVersion ? device.properties.firmwareVersion.value : '',
        isProvisioned: device.properties && device.properties.isProvisioned ? device.properties.isProvisioned ? device.properties.isProvisioned.value : false : false,
        isProvisionedPending: device.properties && device.properties.isProvisionedPending ? device.properties.isProvisionedPending.value : false,
        latLon: {lat: device.properties && device.properties.location ? device.properties.location.lat.value : '', lon: device.properties && device.properties.location ? device.properties.location.lon.value : ''},
        fake: false
      });
}

export function getOEE(device: TableDevice): number {
    let x: number;
    switch (device.status) {
        case -1:
            x = 0;
            break;
        case 0:
            x = 100;
            break;
        case 1:
            x = 66;
            break;
        case 2:
            x = 33;
            break;
    }
    return x;
}
