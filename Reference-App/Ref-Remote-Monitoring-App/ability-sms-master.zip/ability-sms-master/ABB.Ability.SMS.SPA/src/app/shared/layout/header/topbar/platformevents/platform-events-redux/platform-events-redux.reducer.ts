import {createEntityAdapter, EntityState} from '@ngrx/entity';
import {CustomPlatformEvent} from '../../../../../../services/signal-r/models/custom-platform-event';
import {PlatformEventsActions, PlatformEventsActionTypes} from './platform-events-redux.actions';
import {tassign} from 'tassign';

export const platformeventAdapter = createEntityAdapter<CustomPlatformEvent>();

export interface PlatformeventsState extends EntityState<CustomPlatformEvent> {
  connectedToPlatformevents: boolean;
  selectedPlatformevent: CustomPlatformEvent;
}

const defaultState = {
  ids: [],
  entities: {},
  connectedToPlatformevents: false,
  selectedPlatformevent: null
};

export const initialState: PlatformeventsState = platformeventAdapter.getInitialState(defaultState);

export function platformeventReducer(
  state: PlatformeventsState = initialState,
  action: PlatformEventsActions): PlatformeventsState {

  switch (action.type) {

    case PlatformEventsActionTypes.ADD_ONE:
      return platformeventAdapter.addOne(action.payload.customPlatformEvent, state);
    case PlatformEventsActionTypes.REMOVE_ONE:
      return platformeventAdapter.removeOne(action.payload.customPlatformEvent.id, state);
    case PlatformEventsActionTypes.REMOVE_ALL:
      return platformeventAdapter.removeAll(state);
    case PlatformEventsActionTypes.CONNECTED_TO_PLATFORM_EVENTS:
      return tassign(state, {connectedToPlatformevents: action.payload.state});
    case PlatformEventsActionTypes.OPEN_PLATFORM_EVENT:
      return tassign(state, {selectedPlatformevent: action.payload.customPlatformEvent});
    default:
      return state;
  }

}
