import {Action} from '@ngrx/store';
import {CustomPlatformEvent} from '../../../../../../services/signal-r/models/custom-platform-event';

export enum PlatformEventsActionTypes {
  ADD_ONE = '[Signal R Service] Add One',
  REMOVE_ONE = '[Platformevent box] Remove One',
  REMOVE_ALL = '[Platformevent box] Remove all',
  CONNECTED_TO_PLATFORM_EVENTS = '[Platform event service] Connected to platform events',
  OPEN_PLATFORM_EVENT = '[Platformevent box] Show platform event body'
}

export class OpenPlatformEvent implements Action {
  readonly type = PlatformEventsActionTypes.OPEN_PLATFORM_EVENT;

  constructor(public payload: {customPlatformEvent: CustomPlatformEvent }) {
  }
}

export class ConnectedToPlatformevents implements Action {
  readonly type = PlatformEventsActionTypes.CONNECTED_TO_PLATFORM_EVENTS;

  constructor(public payload: { state: boolean }) {
  }
}

export class AddOnePlatformEvent implements Action {
  readonly type = PlatformEventsActionTypes.ADD_ONE;

  constructor(public payload: { customPlatformEvent: CustomPlatformEvent }) {
  }
}

export class RemoveOnePlatformEvent implements Action {
  readonly type = PlatformEventsActionTypes.REMOVE_ONE;

  constructor(public payload: { customPlatformEvent: CustomPlatformEvent }) {
  }
}

export class RemoveAllPlatformEvents implements Action {
  readonly type = PlatformEventsActionTypes.REMOVE_ALL;
}

export type PlatformEventsActions
  = AddOnePlatformEvent | RemoveOnePlatformEvent | RemoveAllPlatformEvents | ConnectedToPlatformevents | OpenPlatformEvent;
