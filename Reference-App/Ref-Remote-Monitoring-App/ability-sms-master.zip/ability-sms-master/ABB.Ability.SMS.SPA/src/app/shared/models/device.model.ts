export interface Device {
    name: string;
    model: string;
    type: string;
    objectId: string;
    properties: {
        serialNumber: {
            value: string;
        },
        firmwareVersion: {
            value: string;
        },
        isProvisioned: {
            value: boolean;
        },
        isProvisionedPending: {
            value: boolean;
        },
        deviceId: {
            value: string;
        },
        location: {
            lat: {
                value: number;
            },
            lon: {
                value: number;
            }
        };
    };
}
