import {Action} from '@ngrx/store';
import {DeviceEventModel, TimeSeriesMessageModel} from './models/events-alarms-model';
import {CustomPlatformEvent} from './models/custom-platform-event';
import {ConnectionStates} from './signal-r.reducer';

export enum SignalRActionTypes {
  PlatformEventAction = '[PlatformEvents] Fetch platformevents',
  DeviceEventAction = '[DeviceEvent] Fetch device event',
  DeviceAlarmAction = '[DeviceAlarm] Fetch device alarm',
  DeviceTimeSeriesAction = '[DeviceTimeSeries] Fetch device timeseries',
  SignalRConnectionAction = '[SignalRConnectionAction] Check signalr connection state',
}

export class SignalRConnection implements Action {
  readonly type = SignalRActionTypes.SignalRConnectionAction;

  constructor(public payload: { state: ConnectionStates }) {
  }
}

export class DeviceAlarm implements Action {
  readonly type = SignalRActionTypes.DeviceAlarmAction;

  constructor(public payload: { alarm: DeviceEventModel }) {
  }
}

export class DeviceEvent implements Action {
  readonly type = SignalRActionTypes.DeviceEventAction;

  constructor(public payload: { event: DeviceEventModel }) {
  }
}

export class PlatformEvent implements Action {
  readonly type = SignalRActionTypes.PlatformEventAction;

  constructor(public payload: { platformEvent: CustomPlatformEvent }) {
  }
}

export class DeviceTimeSeriesEvent implements Action {
  readonly type = SignalRActionTypes.DeviceTimeSeriesAction;

  constructor(public payload: { timeseries: TimeSeriesMessageModel }) {
  }
}

export type SignalRActions = PlatformEvent | DeviceEvent | DeviceAlarm |
  DeviceTimeSeriesEvent | SignalRConnection;
