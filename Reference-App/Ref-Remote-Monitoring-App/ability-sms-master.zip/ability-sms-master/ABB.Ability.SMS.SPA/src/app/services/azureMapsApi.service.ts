import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Location } from 'src/app/shared/models/location.models';

@Injectable({providedIn: 'root'})
export class AzureMapsApiService {
    constructor(private httpClient: HttpClient) {

    }

    public async reverseGeocode(latitude: number, longitude: number): Promise<string> {
        if (!latitude || !longitude) {
            return new Promise<string>(resolve => {
                resolve('');
            });
        }
        const key = this.getKey(latitude, longitude);
        const value = sessionStorage.getItem(key);
        if (value != null) {
            return new Promise<string>(resolve => {
                resolve(value);
            });
        }

        const baseUrl = 'https://atlas.microsoft.com/search/address/reverse/json';
        const latLong = `${latitude},${longitude}`;
        const url = `${baseUrl}?subscription-key=${environment.azureMapsKey}&api-version=1.0&query=${latLong}`;
        return this.httpClient.get(url).toPromise()
        .then(response => {
            const responseData = (response as any);

            if (responseData.addresses.length > 0) {
                const address = responseData.addresses[0].address;
                const formattedAddress = `${address.municipality}, ${address.countrySubdivision}`;
                sessionStorage.setItem(key, formattedAddress);
                return formattedAddress;
            }
            sessionStorage.setItem(key, '');
            return '';
         }, error => {
            return '';
         });
    }

    public async reverseGeocodeMultiple(locations: Location[])
        : Promise<{objectId: string, location: string}[]> {

        const tasks = locations.map(async location => {
            const task = this.reverseGeocode(location.latLon.lat, location.latLon.lon)
                            .then(response => ({ objectId: location.objectId, response}));
            return task;
        });

        const responses = await Promise.all(tasks);
        const data = responses.map(r => ({
            objectId: r.objectId,
            location: r.response
        }));

        return data;
    }

    private getKey(latitude: number, longitude: number): string {
        return `lat${latitude}lon${longitude}`;
    }
}
