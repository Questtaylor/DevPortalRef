import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { MsalService } from './msal.service';

@Injectable()
export class AuthguardService implements CanActivate {

    constructor(private router: Router, private msalService: MsalService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (!this.msalService.isLoggedIn()) {
            // this.router.navigate(['/error']);
            return false;
        }

        const permissions = this.msalService.getPermissions();
        const requiredPermissions = route.data['permissions'] as Array<string>;
        if (!requiredPermissions) {
            return true;
        }

        const canNavigate = requiredPermissions.every(rp => permissions.includes(rp));

        return canNavigate;
    }
}
