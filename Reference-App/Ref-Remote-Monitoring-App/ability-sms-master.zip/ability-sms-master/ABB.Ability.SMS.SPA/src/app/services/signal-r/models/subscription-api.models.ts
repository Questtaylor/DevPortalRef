import {CreateSubscriptionResponse} from 'ability-api';

export interface SubscriptionInfo {

  creationResponse: CreateSubscriptionResponse;

  subscriptionTopic: string;

  dataAccessApiUrl: string;

  ocpApimSubscriptionKey: string;

  token: string;
}
