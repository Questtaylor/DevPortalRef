import {Injectable, OnDestroy} from '@angular/core';
import {SignalRService} from '../signal-r/signal-r.service';
import {select, Store} from '@ngrx/store';
import {AppState} from 'src/app/redux-core/redux-core';
import {CreateSubscriptionRequest, CreateSubscriptionResponse, SubscriptionsService} from 'ability-api';
import {NotificationMessage, NotificationsService} from 'abb-controls';
import {
  ConnectedToPlatformevents
} from '../../shared/layout/header/topbar/platformevents/platform-events-redux/platform-events-redux.actions';
import {ConnectionStates} from '../signal-r/signal-r.reducer';
import { Subscription } from 'rxjs';
import { MsalService } from '../msal.service';


@Injectable({
  providedIn: 'root'
})
export class PlatformeventsService implements OnDestroy {

  private tokenGenerated = false;
  private connectedWebscockets = false;
  private subscriptions: Subscription[];
  private canCreateSubscriptions: boolean;

  constructor(
    private notificationsService: NotificationsService,
    private signalRService: SignalRService,
    private store: Store<AppState>,
    private msal: MsalService,
    private subscriptionsService: SubscriptionsService
  ) {


    this.subscriptions = [
      this.store.pipe(select(state => state.signalR.connectionState))
        .subscribe(async (connected: ConnectionStates) => {
          this.connectedWebscockets = connected === 'connected';

          if (this.tokenGenerated && this.connectedWebscockets) {
            this.checkPermissions();
            if (this.canCreateSubscriptions) {
              await this.connectToPlatformEvents();
            }
          }
        }),
      this.store.pipe(select(state => state.auth.authenticated)).subscribe(async (authenticated) => {
        if (authenticated) {
          this.tokenGenerated = true;
        }

        if (this.tokenGenerated && this.connectedWebscockets) {
          this.checkPermissions();
          if (this.canCreateSubscriptions) {
            await this.connectToPlatformEvents();
          }
        }
      }),
    ];
  }

  checkPermissions() {
    const permissions = this.msal.getPermissions();
    // console.log('permissions', permissions);
    this.canCreateSubscriptions = permissions.indexOf('subscription_create') !== -1;
    // console.log('Can create subscriptions?', this.canCreateSubscriptions);
  }

  private async connectToPlatformEvents() {
    // console.log('Creating subscription');
    try {

      const createSubscriptionRequest: CreateSubscriptionRequest = {
        sasTokenTTL: 60,
        subscriptionTTL: 60,
        type: 'platformEvents'
      };

      const promise = this.subscriptionsService.createSubscription(createSubscriptionRequest).toPromise();
      const response: CreateSubscriptionResponse = await promise;
      // console.log('response', response);

      const token = this.msal.getAccessTokenFromCache();
      await this.signalRService.invokeOpenSubscription(response, 'platformEvents', token);

      this.notificationsService.send(new NotificationMessage('Connected to platform events', 'info', true));

      this.store.dispatch(new ConnectedToPlatformevents({state: true}));
    } catch (e) {
      console.error(e);
      this.notificationsService.send(new NotificationMessage('Cannot run platform events', 'error', true));
    }
  }

  ngOnDestroy(): void {
    if (this.subscriptions) {
      this.subscriptions.forEach(s => s.unsubscribe());
    }
  }

}
