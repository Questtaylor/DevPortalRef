import {SignalRActions, SignalRActionTypes} from './signal-r.actions';
import {DeviceEventModel, TimeSeriesMessageModel} from './models/events-alarms-model';
import {CustomPlatformEvent} from './models/custom-platform-event';
import {tassign} from 'tassign';

export type ConnectionStates = 'connected' | 'connecting' | 'disconnected';

export interface SignalRState {
  platformEvents: CustomPlatformEvent[];
  deviceAlarms: DeviceEventModel[];
  deviceEvents: DeviceEventModel[];
  deviceTimeSeries: TimeSeriesMessageModel[];
  connectionState: ConnectionStates;
}

export const signalRInitialState: SignalRState = {
  platformEvents: [],
  deviceEvents: [],
  deviceAlarms: [],
  deviceTimeSeries: [],
  connectionState: 'disconnected'
};

export function signalRreducer(state = signalRInitialState, action: SignalRActions): SignalRState {

  switch (action.type) {
    case SignalRActionTypes.PlatformEventAction:
      return tassign(state, {platformEvents: [action.payload.platformEvent]});
    case SignalRActionTypes.DeviceAlarmAction:
      return tassign(state, {deviceAlarms: [action.payload.alarm]});
    case SignalRActionTypes.DeviceEventAction:
      return tassign(state, {deviceEvents: [action.payload.event]});
    case SignalRActionTypes.DeviceTimeSeriesAction:
      return tassign(state, {deviceTimeSeries: [action.payload.timeseries]});
    case SignalRActionTypes.SignalRConnectionAction:
      return tassign(state, {connectionState: action.payload.state});
    default:
      return state;
  }
}
