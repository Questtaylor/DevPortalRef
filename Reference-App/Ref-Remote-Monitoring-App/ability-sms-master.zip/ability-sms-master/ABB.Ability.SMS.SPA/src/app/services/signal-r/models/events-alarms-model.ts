export interface DeviceEventModel {
  objectId: string;
  timestamp: string;
  model: string;
  timestampOffset: string;
  path: string;
  code: string;
  severity: string;
  instanceName: string;
  type: string;
  event: string;
  alarm: string;
  value: any; // payload
}

export interface TimeSeriesMessageModel {
  objectId: string;
  model: string;
  timestamp: string;
  value: any;
  variable: string;
  quality: string;
}

export interface PlatformEventModel {
  data?: any;
  userProperties: any;
  headers?: Headers;
  payload?: Payload;
  type: string;
}

export interface Payload {
  typeId: string;
  objectId: string;
  version: number;
  properties: Properties;
  name: string;

  // model CRUD Rest API returns "modelId". Others return "model"
  model?: string;
  modelId?: string;
}

export interface Properties {
  serialNumber: SerialNumber;
}

export interface SerialNumber {
  value: string;
}

export interface Headers {
  customHeaders?: any;
  eventType: number;
  eventTime: string;
  id: string;
  severity: number;
}
