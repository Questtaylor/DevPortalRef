import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

import * as Msal from '../../assets/js/msal';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { NotificationsService, NotificationMessage } from 'abb-controls';
import { LoaderService } from './loader.service';

@Injectable()

export class MsalService {

    B2CTodoAccessTokenKey = 'b2c.access.token';
    defaultTenant = 'ABB-Ability';

    private afterLogin = new BehaviorSubject<boolean>(false);
    loginSuccess = this.afterLogin.asObservable();

    tenantConfig = {
        tenant: environment.msal.tenant + '.onmicrosoft.com',
        tenantb2c: 'https://' + environment.msal.tenant + '.b2clogin.com/',
        b2cScopes: ['openid', 'https://' + environment.msal.tenant + '.onmicrosoft.com/' +
                    environment.msal.solutionNamespace + '/instance'],
        clientID: environment.msal.clientID,
        redirectUri: environment.msal.redirectUri,
        solutionNamespace: environment.msal.solutionNamespace,
        policyPrefix: environment.msal.policyPrefix,
        policySuffix: environment.msal.policySuffix
    };

    // Configure the authority for Azure AD B2C
    authority = this.tenantConfig.tenantb2c + this.tenantConfig.tenant + '/' + this.tenantConfig.policyPrefix +
                        this.tenantConfig.solutionNamespace + '_' + this.defaultTenant + this.tenantConfig.policySuffix;

    /*
     * B2C SignIn SignUp Policy Configuration
     */
    conf = {
        auth: {
            clientId: this.tenantConfig.clientID,
            redirectUri: this.tenantConfig.redirectUri,
            authority: this.authority,
            validateAuthority: false,
            postLogoutRedirectUri: this.tenantConfig.redirectUri,
        },
        system: {
            loadFrameTimeout: 60000
        }
    };

    clientApplication = new Msal.UserAgentApplication(this.conf);

    constructor(private router: Router, private loaderService: LoaderService, public notificationService: NotificationsService) {
        if (environment.verbose) {
            console.log('MSAL Configuration: ', JSON.stringify(this.tenantConfig));
        }
    }

    public login(id?): void {
      localStorage.setItem('tenantName', id);
      this.loaderService.show();
      id = id ? id.trim().split(' ').join('-') : this.defaultTenant;
      const policy = this.tenantConfig.policyPrefix + this.tenantConfig.solutionNamespace + '_' + id + this.tenantConfig.policySuffix;
      this.clientApplication.authority = this.tenantConfig.tenantb2c + this.tenantConfig.tenant + '/' + policy;
      this.authenticate();
  }
    public signup(): void {
      let id = localStorage.getItem('tenantName') ? localStorage.getItem('tenantName') : this.defaultTenant;
      id = id.trim().split(' ').join('-');
      const policy = this.tenantConfig.policyPrefix + this.tenantConfig.solutionNamespace + '_' + id + this.tenantConfig.policySuffix;
      this.clientApplication.authority = this.tenantConfig.tenantb2c + this.tenantConfig.tenant + '/' + policy;
      this.authenticate();
  }

    public authenticate(): void {
        const _this = this;
        const loginRequest = {
            scopes: this.tenantConfig.b2cScopes,
            prompt: 'select_account',
        };

        this.clientApplication.loginPopup(loginRequest).then(function (loginResponse) {
            const tokenKey = '{\"authority\":\"' + _this.clientApplication.authority;
            for (const key in sessionStorage) {
                if (key.startsWith(tokenKey.toLowerCase())) {
                    const user = JSON.parse(sessionStorage.getItem(key));
                    return _this.saveAccessTokenToCache(user.accessToken);
                }
            }
        }).catch(function (error) {
            _this.loaderService.hide();
            console.log('Login Error: ', error);
            let errMsg = error.errorMessage;
            errMsg = errMsg.slice(errMsg.indexOf(':') + 1, errMsg.indexOf('Correlation'));
            _this.notificationService.send(new NotificationMessage(errMsg, 'error', true));
        });
    }

    saveAccessTokenToCache(accessToken: string): void {
        sessionStorage.setItem(this.B2CTodoAccessTokenKey, accessToken);
        this.loaderService.hide();
        this.afterLogin.next(true);
    }

    getAccessTokenFromCache() {
        return sessionStorage.getItem(this.B2CTodoAccessTokenKey);
    }

    logout(): void {
        this.clientApplication.logout();
        sessionStorage.removeItem(this.B2CTodoAccessTokenKey);
    }

    isLoggedIn(): boolean {
        return this.clientApplication.getAccount() != null;
    }

    getUser() {
        return this.clientApplication.getAccount();
    }

    getEnvironment() {
        return this.tenantConfig;
    }

    getPermissions(): string[] {
        const token = this.getAccessTokenFromCache();
        if (!token) {
            return [];
        }
        const data = this.parseJwt(token);
        return data.permissions;
    }

    getTenantId() {
        return this.isLoggedIn() ? (<any>this.clientApplication.getAccount().idToken).tid : null;
    }

    private parseJwt(token) {
        if (!token) {
            throw new Error(('Can\'t parse null token'));
        }

        const base64Url = token.split('.')[1];
        const base64 = decodeURIComponent(atob(base64Url).split('').map(function (c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));

        return JSON.parse(base64);
    }
}
