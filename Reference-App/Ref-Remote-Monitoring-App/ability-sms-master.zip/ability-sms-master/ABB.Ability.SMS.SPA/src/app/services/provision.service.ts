import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { NotificationsService, NotificationMessage } from 'abb-controls';

@Injectable({providedIn: 'root'})
export class ProvisionService {
    constructor(private httpClient: HttpClient,
                private notification: NotificationsService) { }

    public updateProvisionStatus(deviceId: string, isProvisionedPending: boolean, isProvisioned: boolean): Promise<void> {
        const url = `${environment.provisionUrl}/${deviceId}?isProvisionedPending=${isProvisionedPending}&isProvisioned=${isProvisioned}`;

        return this.httpClient.get(url, {observe: 'response', responseType: 'text'})
        .toPromise().then((response) => {
            if (response.status === 200) {
                this.notification.send(new NotificationMessage('Device has been updated', 'success', true, false));
            } else {
                this.notification.send(new NotificationMessage('Device failed to update', 'error', true, false));
            }
        }).catch(err => {
            this.notification.send(new NotificationMessage('Device failed to update', 'error', true, false));
            return Promise.reject(err || 'Server Error');
        });
    }
}
