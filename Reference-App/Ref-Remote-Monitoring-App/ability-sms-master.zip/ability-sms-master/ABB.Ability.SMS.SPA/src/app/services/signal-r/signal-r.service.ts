import {Injectable, OnDestroy, Inject} from '@angular/core';
import {DeviceEventModel, PlatformEventModel, TimeSeriesMessageModel} from './models/events-alarms-model';
import * as SignalR from '@aspnet/signalr';
import {DeviceAlarm, DeviceEvent, DeviceTimeSeriesEvent, PlatformEvent, SignalRConnection} from './signal-r.actions';
import {select, Store} from '@ngrx/store';
import {AppState} from 'src/app/redux-core/redux-core';
import {CustomPlatformEvent} from './models/custom-platform-event';
import {NotificationMessage, NotificationsService} from 'abb-controls';
import {isAuthenticated} from '../../redux-core/auth-redux/auth.selectors';
import {SubscriptionInfo} from './models/subscription-api.models';
import {CreateSubscriptionResponse, SubscriptionTypes, DataAccessApiBaseUrl} from 'ability-api';
import { Subscription } from 'rxjs';
import { MsalService } from '../msal.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SignalRService implements OnDestroy {

  public connection: SignalR.HubConnection;

  private isDisabled = false;
  private authenticatedSubscription: Subscription;

  constructor(
    private store: Store<AppState>,
    private msalService: MsalService,
    private notificationsService: NotificationsService,
    @Inject(DataAccessApiBaseUrl) private dataAccessApiUrl: string) {
    this.authenticatedSubscription = this.store.pipe(select(isAuthenticated)).subscribe(async (authenticated: boolean) => {
      if (authenticated) {
        await this.init();
      }
    });
  }

  public async disable(): Promise<void> {
    this.isDisabled = true;
    if (this.connection) {
      await this.connection.stop();
    }
    this.store.dispatch(new SignalRConnection({state: 'disconnected'}));
  }

  public async invokeOpenSubscription(creationResponse: CreateSubscriptionResponse,
    subscriptionTopic: SubscriptionTypes, token: string): Promise<void> {

    const subscription: SubscriptionInfo = {
      creationResponse,
      subscriptionTopic,
      dataAccessApiUrl: this.dataAccessApiUrl,
      ocpApimSubscriptionKey: '', // environment.ocpApimSubscriptionKey,
      token
    };

    await this.invoke('Open', subscription);
  }

  public async invoke(methodName: string, model: any): Promise<void> {
    if (this.connection && !this.isDisabled) {
      await this.connection.invoke(methodName, JSON.stringify(model));
    } else {
      this.notificationsService.send(new NotificationMessage('Web Socket connection is dead. Try to refresh / relogin.', 'error', true));
    }
  }

  public async init(): Promise<void> {

    try {
      if (this.isDisabled) {
        this.notificationsService.send(
          new NotificationMessage('Skipped establishing websocket connection. SignalR explicitly disabled.', 'warning', true)
        );
        return;
      }

      if (this.msalService.isLoggedIn()) {
        this.setAllEvents();
        try {
          this.store.dispatch(new SignalRConnection({state: 'connecting'}));
          await this.connection.start();
          this.store.dispatch(new SignalRConnection({state: 'connected'}));
        } catch (err) {
          this.store.dispatch(new SignalRConnection({state: 'disconnected'}));
          this.notificationsService.send(
            new NotificationMessage('Cannot establish websocket connection', 'error', true),
            new NotificationMessage(err, 'error', false),
          );
        }
      } else {
        this.store.dispatch(new SignalRConnection({state: 'disconnected'}));
      }
    } catch (e) {
      this.notificationsService.send(
        new NotificationMessage(e, 'error', false),
      );
    }
  }

  private setAllEvents() {
    this.connection = new SignalR.HubConnectionBuilder()
      .withUrl(`${environment.referenceUiApi}/${environment.telemetryHubName}`)
      .build();

    this.connection.onclose((error) => {
      this.store.dispatch(new SignalRConnection({state: 'disconnected'}));
      this.notificationsService.send(
        new NotificationMessage('Lost websocket connection', 'error', true),
        new NotificationMessage(JSON.stringify(error), 'error', false),
      );
    });

    this.connection.on('event', event => {
      const msg: DeviceEventModel = JSON.parse(event);
      msg.type = 'event';
      this.store.dispatch(new DeviceEvent({event: msg}));
    });

    this.connection.on('platformevent', event => {
      // console.log('Platform Event: ', event);
      const msg: PlatformEventModel = JSON.parse(event);
      msg.type = 'platformevent';
      // console.log('Platform event model: ', msg);
      const customPlatformEvent = new CustomPlatformEvent(msg);
      // console.log('Custom Platform event: ', customPlatformEvent);
      if (customPlatformEvent.eventType !== undefined && customPlatformEvent.eventType !== null) {
        this.store.dispatch(new PlatformEvent({platformEvent: customPlatformEvent}));
      }
    });

    this.connection.on('alarm', alarm => {
      const msg: DeviceEventModel = JSON.parse(alarm);
      msg.type = 'alarm';
      this.store.dispatch(new DeviceAlarm({alarm: msg}));
    });

    this.connection.on('TimeSeries', message => {
      const msg: TimeSeriesMessageModel = JSON.parse(message);
      this.store.dispatch(new DeviceTimeSeriesEvent({timeseries: msg}));
    });
  }

  ngOnDestroy(): void {
    if (this.authenticatedSubscription) {
      this.authenticatedSubscription.unsubscribe();
    }
  }
}
