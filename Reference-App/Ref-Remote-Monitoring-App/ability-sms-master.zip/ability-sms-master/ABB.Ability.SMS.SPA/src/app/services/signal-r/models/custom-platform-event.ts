import {PlatformEventModel} from './events-alarms-model';

export class CustomPlatformEvent {

  public get eventType() {
    return this._eventType;
  }

  public get eventTime() {
    return this._eventTime;
  }

  public get eventObject(): string {
    return this._eventObject;
  }

  public get eventText(): string {
    return this._eventText;
  }

  public get redirectHref(): string {
    return this._redirectHref;
  }

  public displayTextTime: string;
  public originalPayload: string;
  public id: string;

  private readonly _eventObject: string;
  private readonly _eventType: string;
  private readonly _eventTime: Date;
  private readonly _eventText: string;
  private _redirectHref: string;


  constructor(platformEventModel: any) {
    this.originalPayload = platformEventModel;

    this._eventType = platformEventModel.userProperties.eventType;
    this._eventTime = platformEventModel.userProperties.eventTime;

    this._eventObject = this.getEventObject(this._eventType, platformEventModel);
    this._eventText = this.getEventText(this._eventType, platformEventModel, this._eventObject);
    this.id = `${this._eventObject}_${this._eventType}_${this._eventTime}`;
  }


  private getEventObject(event: string, platformEventModel: PlatformEventModel): string {
    switch (event) {
      case 'Abb.Ability.TypeRegistry.TypeCreated':
      case 'Abb.Ability.TypeRegistry.TypeUpdated':
        return platformEventModel.payload.typeId;
      case 'Abb.Ability.InformationModel.ObjectModelCreated':
      case 'Abb.Ability.InformationModel.ObjectModelUpdated':
      case 'Abb.Ability.InformationModel.ObjectModelDeleted':
        return platformEventModel.payload.name ? platformEventModel.payload.name : platformEventModel.payload.objectId;
      case 'Abb.Ability.TypeRegistry.ModelDefinitionCreated':
        return this.getModel(platformEventModel);
      case 'Microsoft.IoTHub.DeviceLifecycleEvent':
        return platformEventModel.data.deviceId;
      case 'Abb.Ability.Commands.Methods':
        return platformEventModel.headers.customHeaders.objectId;
      case 'Abb.Ability.Device.Updated':
      case 'Abb.Ability.Device.Created':
      case 'Abb.Ability.Device.SyncModel':
        return platformEventModel.userProperties.objectId;
      case 'Abb.Ability.Commands.MethodInvoked':
      case 'Abb.Ability.Commands.Method.Invoked':
      case 'Abb.Ability.ObjectModel.Method.Invoked':
        return platformEventModel.userProperties.objectId;
    }
  }


  private getEventText(event: any, platformEventModel, eventObject) {

    switch (event) {
      case 'Abb.Ability.TypeRegistry.ModelDefinitionCreated':
        return `Model definition has been created ${eventObject}`;
      case 'Abb.Ability.TypeRegistry.TypeCreated':
        this._redirectHref = `/browse/apps/details/${this.getModel(platformEventModel)}/${platformEventModel.payload.typeId}`;
        return `Type definition has been created ${eventObject}`;
      case 'Abb.Ability.TypeRegistry.TypeUpdated':
        this._redirectHref = `/browse/apps/details/${this.getModel(platformEventModel)}/${platformEventModel.payload.typeId}`;
        return `Type definition updated ${eventObject}`;
      case 'Abb.Ability.TypeRegistry.TypeDeleted':
        // TODO: not implemented yet on platform
        return;
      case 'Abb.Ability.InformationModel.ObjectModelCreated':
        this._redirectHref = `/browse/apps/details/${this.getModel(platformEventModel)}/${platformEventModel.payload.type}/${platformEventModel.payload.objectId}`;
        return `Infomodel object has been created ${eventObject}`;
      case 'Abb.Ability.InformationModel.ObjectModelUpdated':
        this._redirectHref = `/browse/apps/details/${this.getModel(platformEventModel)}/${platformEventModel.payload.type}/${platformEventModel.payload.objectId}`;
        return `Infomodel updated: ${eventObject}`;
      case 'Abb.Ability.InformationModel.ObjectModelDeleted':
        // TODO: not implemented yet on platform
        return;
      case 'Abb.Ability.Device.Created':
        return `Device ${platformEventModel.userProperties.objectId} created on DCS`;
      case 'Abb.Ability.Device.Updated':
        return `Device ${platformEventModel.userProperties.objectId} updated on DCS`;
      case 'Abb.Ability.Device.SyncModel':
        return `Device ${platformEventModel.objectId} sync model with DCS`;
      case 'Abb.Ability.Commands.Methods':
        return `Method ${platformEventModel.headers.customHeaders.method} on ${platformEventModel.headers.customHeaders.objectId} has been requested`;
      case 'Abb.Ability.Commands.MethodInvoked':
      case 'Abb.Ability.Commands.Method.Invoked':
      case 'Abb.Ability.ObjectModel.Method.Invoked':
        return `Method ${platformEventModel.headers.customHeaders.method} on ${platformEventModel.headers.customHeaders.objectId} has been invoked`;
      case 'Abb.Ability.Files.FileUploaded':
      case 'Abb.Ability.File.Uploaded':
        return 'File(s) uploaded';
      case 'Abb.Ability.Files.FileDeleted':
      case 'Abb.Ability.File.Deleted':
        return 'File(s) deleted';
      case 'Microsoft.IoTHub.DeviceLifecycleEvent':
        if (platformEventModel.data.opType === 'deleteDeviceIdentity') {
          return `Device ${platformEventModel.data.deviceId} has been removed from IOTHUB ${platformEventModel.data.hubName}`;
        } else if (platformEventModel.data.opType === 'createDeviceIdentity') {
          return `Device ${platformEventModel.data.deviceId} has been created on IOTHUB ${platformEventModel.data.hubName}`;
        }
        break;
      case 'Microsoft.Storage.BlobCreated':
        // TODO: not implemented yet on platform
        return;

      case 'Abb.Ability.InformationModel.ReferenceCreated':
        return `Created new "${platformEventModel.payload.name}" object reference`;
      case 'Abb.Ability.InformationModel.ReferenceDeleted':
        const from = platformEventModel.payload.from.name || platformEventModel.payload.from.objectId;
        const to = platformEventModel.payload.to.name || platformEventModel.payload.to.objectId;
        return `Removed relation of name "${platformEventModel.payload.name}" from object ${from} to ${to}`;
    }

  }

  private getModel(platformEventModel: PlatformEventModel): string {
    return platformEventModel.payload.modelId || platformEventModel.payload.model;
  }

}
