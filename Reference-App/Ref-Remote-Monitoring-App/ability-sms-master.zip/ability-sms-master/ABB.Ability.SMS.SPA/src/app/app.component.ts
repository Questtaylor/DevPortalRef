import {Component, OnInit} from '@angular/core';
import {SignalRService} from './services/signal-r/signal-r.service';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { AppState } from './redux-core/redux-core';
import { BreadcrumbsService, IBreadcrumb } from 'ng6-breadcrumbs';
import { MsalService } from './services/msal.service';
import { Login } from './redux-core/auth-redux/auth.actions';

@Component({
  selector: 'abb-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: []
})
export class AppComponent implements OnInit {
  public authenticated$: Observable<boolean>;
  public active = true;

  constructor(private signalRService: SignalRService,
              private msal: MsalService,
              private store: Store<AppState>,
              private breadcrumbsService: BreadcrumbsService) {
  }


  public ngOnInit(): void {
    if (this.msal.isLoggedIn()) {
      this.store.dispatch(new Login({userName: this.msal.getUser().name, authenticated: true}));
    }

    this.authenticated$ = this.store.pipe(select((state: AppState) => state.auth.authenticated));

    const breadcrumb: IBreadcrumb = {label: 'Fleet View', url: '/', params: []};
    this.breadcrumbsService.storePrefixed(breadcrumb);
  }

  public async turnOffSignalR(): Promise<void> {
    await this.signalRService.disable();
  }

  public toggle(): void {
    this.active = !this.active;
  }
}
