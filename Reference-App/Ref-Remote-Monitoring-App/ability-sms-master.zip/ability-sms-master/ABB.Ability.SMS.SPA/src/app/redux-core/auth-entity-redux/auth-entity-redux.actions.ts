import {AuthEntityModel} from './auth-entity.model';

export enum ChildrenEntityActionTypes {
  FETCH_ACCESS_TOKEN = '[AUTH] FETCH TOKENS'
}

export class FetchAccessToken {
  readonly type = ChildrenEntityActionTypes.FETCH_ACCESS_TOKEN;

  constructor(public payload: { entity: AuthEntityModel }) {
  }
}

export type AuthEntityActions = FetchAccessToken;
