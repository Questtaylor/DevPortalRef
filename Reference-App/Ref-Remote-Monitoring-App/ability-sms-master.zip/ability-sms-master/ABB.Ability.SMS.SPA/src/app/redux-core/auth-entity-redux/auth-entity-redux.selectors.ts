import {createFeatureSelector, createSelector} from '@ngrx/store';
import {ChildrenEntityState} from '../../feature/browse-info-model/apps/manage/manage-info-model-object/children-entity-state/children-entity-state.reducer';


export const selectDataAccessTokenGenerated = createFeatureSelector<ChildrenEntityState>('authEntity');



export const isTokenGenerated = (entity) => createSelector(
  selectDataAccessTokenGenerated,
  auth => auth.entities[entity]
);
