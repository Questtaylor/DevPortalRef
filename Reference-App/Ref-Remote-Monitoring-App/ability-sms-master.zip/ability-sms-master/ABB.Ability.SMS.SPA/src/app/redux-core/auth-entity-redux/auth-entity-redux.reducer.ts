import {createEntityAdapter, EntityState} from '@ngrx/entity';
import {createFeatureSelector} from '@ngrx/store';
import {AuthEntityModel} from './auth-entity.model';
import {AuthEntityActions, ChildrenEntityActionTypes} from './auth-entity-redux.actions';


export const authEntityAdapter = createEntityAdapter<AuthEntityModel>({
  selectId: (children: AuthEntityModel) => children.api,
});

export interface AuthEntityState extends EntityState<AuthEntityModel> {
}

export const initialState: AuthEntityState = authEntityAdapter.getInitialState();

export function authEntityReducer(
  state: AuthEntityState = initialState,
  action: AuthEntityActions) {

  switch (action.type) {

    case ChildrenEntityActionTypes.FETCH_ACCESS_TOKEN:
      return authEntityAdapter.addOne(action.payload.entity, state);
    default:
      return state;
  }

}

export const getAuthEntityState = createFeatureSelector<AuthEntityState>('authEntity');

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal,
} = authEntityAdapter.getSelectors(getAuthEntityState);

