import {createSelector} from '@ngrx/store';


export const selectAuthenticated = (state) => state.auth;

export const isAuthenticated = createSelector(
  selectAuthenticated,
  auth => auth.authenticated
);
