import {Action} from '@ngrx/store';

export enum AuthActionTypes {
  Login = '[Auth] Login',
  Logout = '[Auth] Logout',
  MsalLogin = '[Auth] MsalLogin',
  MsalLogout = '[Auth] MsalLogout',
  SetHref = '[Auth] SetHref'
}

export class SetHref implements Action {
  readonly type = AuthActionTypes.SetHref;

  constructor(public payload: { href: string }) {
  }
}

export class MsalLogout implements Action {
  readonly type = AuthActionTypes.MsalLogout;
}

export class MsalLogin implements Action {
  readonly type = AuthActionTypes.MsalLogin;

  constructor(public payload: {tenant: string}) {

  }
}

export class Login implements Action {
  readonly type = AuthActionTypes.Login;

  constructor(public payload: { userName: string, authenticated: boolean }) {
  }
}

export class Logout implements Action {
  readonly type = AuthActionTypes.Logout;
}

export type AuthActions = Login | Logout | MsalLogin | MsalLogout | SetHref;
