import {Injectable} from '@angular/core';
import {Actions} from '@ngrx/effects';



@Injectable()
export class ChildrenEntityStateEffects {
  constructor(private actions$: Actions) {
  }
}
