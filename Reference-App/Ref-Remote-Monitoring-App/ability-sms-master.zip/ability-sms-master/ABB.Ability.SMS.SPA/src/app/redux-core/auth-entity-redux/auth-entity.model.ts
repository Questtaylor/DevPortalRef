export class AuthEntityModel {
  token: string;
  resource: string;
  expiresAt: number;
  api: string;
}
