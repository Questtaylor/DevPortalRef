import {ActionReducer, ActionReducerMap, MetaReducer} from '@ngrx/store';
import {environment} from '../../environments/environment';
import {signalRreducer, SignalRState} from '../services/signal-r/signal-r.reducer';
import {authReducer, AuthState} from './auth-redux/auth.reducer';
import {routerReducer, RouterReducerState} from '@ngrx/router-store';
import {storeFreeze} from 'ngrx-store-freeze';

export interface AppState {
  signalR: SignalRState;
  router: RouterReducerState;
  auth: AuthState;
}

export const reducers: ActionReducerMap<AppState> = {
  signalR: signalRreducer,
  router: routerReducer,
  auth: authReducer
};


export const metaReducers: MetaReducer<AppState>[] = environment.production ? [] : [storeFreeze/*debug*/];


// console.log all actions
export function debug(reducer: ActionReducer<any>): ActionReducer<any> {
  return function (state, action) {
    // console.log('state', state);
    // console.log('action', action);

    return reducer(state, action);
  };
}
