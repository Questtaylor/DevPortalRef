import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {StoreModule} from '@ngrx/store';
import {authEntityReducer} from './auth-entity-redux.reducer';

@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature('authEntity', authEntityReducer),
    // EffectsModule.forFeature([ChildrenEntityStateEffects])
  ],
  declarations: []
})
export class AuthEntityReduxModule { }
