import {AuthActions, AuthActionTypes} from './auth.actions';
import {tassign} from 'tassign';


export interface AuthState {
  userName: any;
  authenticated: boolean;
}

export const initialState: AuthState = {
  userName: '',
  authenticated: false
};


export function authReducer(state = initialState, action: AuthActions): AuthState {
  switch (action.type) {
    case AuthActionTypes.Login:
      return tassign(state, {userName: action.payload.userName, authenticated: action.payload.authenticated});
    case AuthActionTypes.MsalLogin:
      return state;
    case AuthActionTypes.MsalLogout:
      return state;
    default:
      return state;
  }
}
