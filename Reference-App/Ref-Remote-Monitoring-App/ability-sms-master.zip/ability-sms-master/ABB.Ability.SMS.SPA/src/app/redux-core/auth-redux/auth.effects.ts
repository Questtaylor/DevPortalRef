import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {MsalLogin, MsalLogout, AuthActionTypes } from './auth.actions';
import { tap } from 'rxjs/operators';
import { MsalService } from 'src/app/services/msal.service';

@Injectable()
export class AuthEffects {

  @Effect({dispatch: false})
  msalLogin$ = this.actions$.pipe(
    ofType<MsalLogin>(AuthActionTypes.MsalLogin),
    tap((x) => {
      this.msalService.login(x.payload.tenant);
    })
  );

  @Effect({dispatch: false})
  msalLogout$ = this.actions$.pipe(
    ofType<MsalLogout>(AuthActionTypes.MsalLogout),
    tap(() => {
      this.msalService.logout();
    })
  );

  constructor(
    private actions$: Actions,
    private msalService: MsalService
  ) {
  }
}
