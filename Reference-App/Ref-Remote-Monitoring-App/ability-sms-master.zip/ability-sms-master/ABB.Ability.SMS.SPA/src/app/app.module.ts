import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {SharedModule} from './shared';
import {AppRoutingModule} from './app-routing.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {HeaderModule} from './shared/layout/header/header.module';
import {environment} from '../environments/environment';
import {MainModule} from './main/main.module';
// AdalService reference needs to be kept, otherwise azure maps won't be able
// to find a reference to adal and will cause compiling to fail.
import { AdalService} from 'adal-angular4';
import {HTTP_INTERCEPTORS} from '@angular/common/http';
import {LoggingModule} from './feature/logging/logging.module';
import {NgSelectConfig} from '@ng-select/ng-select';
import {
  DataAccessApiBaseUrl,
  ReferenceUiApiBaseUrl,
  InfoModelApiBaseUrl,
  TypeDefinitionApiBaseUrl,
  DataService,
  LoggingService,
  SubscriptionsService,
  ObjectsService,
  FilesService,
  CommandsService
} from 'ability-api';
import {NotificationsService, SnackBarModule} from 'abb-controls';
import {PlatformeventsService} from './services/platformevents/platformevents.service';
import { StoreModule } from '@ngrx/store';
import { metaReducers, reducers } from 'src/app/redux-core/redux-core';
import {StoreDevtoolsModule} from '@ngrx/store-devtools';
import {SignalRService} from './services/signal-r/signal-r.service';
import {RouterStateSerializer, StoreRouterConnectingModule} from '@ngrx/router-store';
import {CustomSerializer} from './custom-router-serializer';
import {AuthEffects} from './redux-core/auth-redux/auth.effects';
import {EffectsModule} from '@ngrx/effects';
import {AuthEntityReduxModule} from './redux-core/auth-entity-redux/auth-entity-redux.module';
import { MsalService } from './services/msal.service';
import { HttpMsalInterceptorService } from './http-msal-intercepter.service';
import { LoaderComponent } from './components/loader.component';

export function init_api_url() {
  return environment.apiUrl;
}

export function init_refapi_url() {
  return environment.referenceUiApi;
}

@NgModule({
  declarations: [
    AppComponent,
    LoaderComponent
  ],
  imports: [
    BrowserModule,
    SharedModule,
    MainModule,
    AppRoutingModule,
    HeaderModule,
    SnackBarModule,
    LoggingModule,
    StoreModule.forRoot(reducers, {metaReducers}),
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    EffectsModule.forRoot([AuthEffects]),
    StoreRouterConnectingModule.forRoot({stateKey: 'router'}),
    AuthEntityReduxModule
  ],
  providers: [
    MsalService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpMsalInterceptorService,
      deps: [NotificationsService],
      multi: true
    },
    {
      provide: DataAccessApiBaseUrl,
      useFactory: init_api_url
    },
    {
      provide: InfoModelApiBaseUrl,
      useFactory: init_api_url
    },
    {
      provide: TypeDefinitionApiBaseUrl,
      useFactory: init_api_url
    },
    {
      provide: ReferenceUiApiBaseUrl,
      useFactory: init_refapi_url
    },
    {
      provide: NgSelectConfig,
      useValue: {
        placeholder: 'Select item',
        notFoundText: 'Items not found',
        addTagText: 'Add item',
        typeToSearchText: 'Type to search',
        loadingText: 'Loading...',
        clearAllText: 'Clear all'
      }
    },
    {
      provide: RouterStateSerializer,
      useClass: CustomSerializer
    },
    SignalRService,
    DataService,
    FilesService,
    CommandsService,
    SubscriptionsService,
    ObjectsService,
    LoggingService,
    NotificationsService,
    BrowserAnimationsModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private signalRService: SignalRService,
    private platformeventsService: PlatformeventsService) {

    }
 }
