export interface Command {
    name: string;
    inputs?: {
        name: string,
        dataType: string
    }[];
    model: string;
    objectId: string;
}
