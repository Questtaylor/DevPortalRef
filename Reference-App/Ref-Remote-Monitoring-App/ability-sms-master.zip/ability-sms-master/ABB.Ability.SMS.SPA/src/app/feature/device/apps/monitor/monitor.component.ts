import { Component, OnDestroy } from '@angular/core';
import { Subscription, Observable, interval } from 'rxjs';
import { DataPoint, ValueBox, Variable } from './_models/monitor.models';
import { Store, select } from '@ngrx/store';
import { GetDataAggregatedRequest, GetDataRawRequest, GetDataResponse } from 'ability-api';
import { MonitorDataLoaderService } from './_services/monitor-data-loader.service';
import { startWith, filter, map, distinctUntilChanged, skip } from 'rxjs/operators';
import { ResetAction,
         AvailableVariablesReceivedAction,
         AvailableVariablesReceivedActionPayload,
         LastValueTelemetryReceivedPayload,
         LastValueTelemetryReceivedAction,
         LastWkAvgDataReceivedAction,
         LastWkAvgDataReceivedActionPayload,
         NewSearchAction,
         NewSearchActionPayload} from './monitor-redux/monitor.actions';
import { State } from './monitor-redux/monitor.reducer';
import { DeviceState } from '../../device-redux/device.reducers';
import { getFriendlyNames, getMeasurementUnits } from '../definition-mapping/definition-mapping.models';
import { DecimalPipe } from '@angular/common';
import { MsalService } from 'src/app/services/msal.service';

@Component({
    selector: 'abb-monitor',
    templateUrl: 'monitor.component.html',
    styleUrls: ['monitor.component.scss'],
    providers: [
        MonitorDataLoaderService
    ]
})

export class MonitorComponent implements OnDestroy {
    private subscriptions: Subscription[];
    private dataMode: 'live' | 'historical';
    private selectedVariables: string[];

    public variableData$: Observable<DataPoint[]>;
    canReadEvents: boolean;
    canReadVariables: boolean;

    constructor(private store: Store<State>,
                private deviceStore: Store<DeviceState>,
                private monitorDataLoaderService: MonitorDataLoaderService,
                private msalService: MsalService) {

        this.store.dispatch(new ResetAction());

        this.checkPermissions();

        this.variableData$ = store.pipe(select(s => s.monitor.variableData));

        this.configureSubscriptions();
    }

    checkPermissions() {
        const permissions = this.msalService.getPermissions();

        this.canReadEvents = permissions.indexOf('event_read') !== -1;
        this.canReadVariables = permissions.indexOf('variable_read') !== -1;
    }

    configureSubscriptions() {
        const deviceObject$ = this.deviceStore.pipe(
            select(s => s.device.objectDefintion),
            filter(s => s != null)
        );

        this.subscriptions = [];
        this.subscriptions.push(deviceObject$.subscribe(async object => {
            const objectId = object.objectId;

            const friendlyNames = getFriendlyNames(object);

            const units = getMeasurementUnits(object);

            const variables = object.variables.properties.map(v => {
                const friendlyName = friendlyNames.filter(f => f.name === v.name)[0].friendlyName;
                const unit = units.filter(f => f.name === v.name)[0].unit;

                if (v.name === 'temperature') {
                    return <Variable>{ name: v.name, friendlyName, unitOfMeasurement: unit, selected: true };
                } else {
                    return <Variable>{ name: v.name, friendlyName, unitOfMeasurement: unit, selected: false };
                }
            });

            const payload: AvailableVariablesReceivedActionPayload = {
                variables
            };
            this.store.dispatch(new AvailableVariablesReceivedAction(payload));

            // start refreshing every 10 seconds, starting immediately.
            const updateInterval$ = interval(10000).pipe(startWith(0));
            const historicalChange$ = this.store.pipe(select(s => s.monitor.mode));

            const selectedVariables$ = this.store.pipe(select(s => s.monitor.availableVariables),
                filter(av => av != null),
                map(av => av.filter(v => v.selected).map(v => v.name).sort().join(',')));

            // const updateChartData$ = combineLatest(updateInterval$, historicalChange$, selectedVariables$, (ui, hm, sv) => ({
            //     ui, hm, sv
            // })).pipe(distinctUntilChanged((x: any, y: any) => x.ui === y.ui && x.hm === y.hm && x.sv === y.sv));

            // this.subscriptions.push(updateChartData$.subscribe(async (x) => {
            //     this.dataMode = x.hm;
            //     this.getData(objectId, 'variables');
            // }));

            const distinctVariableChanged$ = selectedVariables$.pipe(distinctUntilChanged((x: string, y: string) => x === y));

            this.subscriptions.push(distinctVariableChanged$.subscribe(x => {
                this.selectedVariables = x.split(',');
            }));

            this.subscriptions.push(distinctVariableChanged$.pipe(skip(1)).subscribe(async () => {
                const newSearchPayload: NewSearchActionPayload = {mode: this.dataMode};
                this.store.dispatch(new NewSearchAction(newSearchPayload));

                await this.getData(objectId, 'variables');
            }));

            this.subscriptions.push(updateInterval$.subscribe(async () => {
                await this.loadLiveTelemetry(objectId, variables);
            }));

            // listen for changes to the data mode.
            this.subscriptions.push(historicalChange$.subscribe(mode => {
                this.dataMode = mode;
            }));

            this.subscriptions.push(historicalChange$.pipe(skip(1)).subscribe(async mode => {
                await this.getData(objectId, 'variables');
            }));
        }));
    }

    public ngOnDestroy(): void {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }

    private async loadLiveTelemetry(objectId: string, variables: Variable[]): Promise<void> {
        const variableNames = variables.map(v => v.name);
        if (this.canReadEvents) {
            await this.getData(objectId, 'events');
        }
        if (this.canReadVariables) {
            if ( this.dataMode === 'live') {
                await this.getData(objectId, 'variables');
            }
            await this.loadLastWkAvg(objectId, variables);
            const result = await this.loadLastValueForVariables(objectId, variableNames);

            const variableData = result.data.map(d => <Variable>{
                name: d.variable,
                lastValue: d.last.value,
                timestamp: d.last.timestamp
            });

            const payload: LastValueTelemetryReceivedPayload = {
                variables: variableData
            };

            this.store.dispatch(new LastValueTelemetryReceivedAction(payload));
        }
    }

    private async loadLastValueForVariables(objectId: string, variables: string[]): Promise<GetDataResponse<any>> {
        const dataType = 'variables';
        const filteredVariables = variables.filter(v => v.indexOf('.') === -1);
        const tFilter = this.createTelemetryRequestFilter(objectId, dataType, filteredVariables);
        const to = new Date();
        const from = new Date(to);
        from.setDate(to.getDate() - 7);

        const request: GetDataAggregatedRequest = {
            date: {
                from: from.toISOString(),
                to: to.toISOString()
            },
            select: {last: 'value, timestamp'},
            requestType: <any> dataType.toLowerCase(),
            filter: tFilter,
            orderBy: {
                property: 'timestamp',
                order: 'desc'
            },
            groupBy: {
                properties: 'objectId, variable'
            },
            limit: filteredVariables.length
        };

        return this.monitorDataLoaderService.loadAggregatedData(request).toPromise();
    }

    private async loadLastWkAvg(objectId: string, variables: Variable[]): Promise<void> {
        const dataType = 'variables';
        const tFilter = this.createTelemetryRequestFilter(objectId, dataType, ['temperature']);
        const to = new Date();
        const from = new Date(to);
        from.setHours(from.getHours() - 24);

        const request: GetDataAggregatedRequest = {
            date: {
                from: from.toISOString(),
                to: to.toISOString()
            },
            requestType: <any> dataType.toLowerCase(),
            filter: tFilter,
            select: {
                avg: 'value'
            },
            groupBy: {
                time: '24h',
                properties: 'objectId, variable'
            },
            orderBy: {
                property: 'timestamp',
                order: 'desc'
            },
            limit: 1
        };

        const data = await this.monitorDataLoaderService.loadAggregatedData(request).toPromise();

        let unit = '';
        const temp = variables.filter(v => v.name === 'temperature');
        if (temp.length === 1) {
            unit = temp[0].unitOfMeasurement;
        }

        const decimalPipe = new DecimalPipe('en-US');
        if (data.data == null || data.data.length === 0) {
            data.data = null;
        }
        const mappedData = ((data.data) || <any>[{avg: {value: null}}]).map(m => {
            const name = unit ? `Avg Temperature (${unit})` : 'Avg Temperature';
            const value = m.avg.value ? decimalPipe.transform(m.avg.value, '1.0-2') : '';
            return new ValueBox(name, 'Past 24 hours', value);
        });

        this.store.dispatch(new LastWkAvgDataReceivedAction(<LastWkAvgDataReceivedActionPayload>{
          lastWkAvg : mappedData[0]
        }));
    }

    private async getHistoricalData(objectId: string): Promise<void> {
        const dataType = 'variables';
        const tFilter = this.createTelemetryRequestFilter(objectId, dataType, this.selectedVariables ? this.selectedVariables : []);
        const to = new Date();
        const from = new Date(to);

        from.setHours(from.getHours() - 24);

        const request: GetDataAggregatedRequest = {
            date: {
                from: from.toISOString(),
                to: to.toISOString(),
            },
            requestType: dataType,
            filter: tFilter,
            select: {
                avg: 'value'
            },
            groupBy: {
                time: '10m',
                properties: 'objectId, variable'
            },
            orderBy: {
                property: 'timestamp',
                order: 'desc'
            },
            limit: 10000
        };

        await this.monitorDataLoaderService.loadHistoricalData(request);
    }

    private async getData(objectId: string, dataType: 'variables' | 'alarms' | 'events'): Promise<void> {
        const tFilter = this.createTelemetryRequestFilter(objectId, dataType, this.selectedVariables ? this.selectedVariables : []);
        const to = new Date();
        const from = new Date(to);
        let selectS: any;
        if (dataType === 'variables' && this.dataMode === 'historical') {
            from.setHours(from.getHours() - 24);
        } else if (dataType === 'events') {
            from.setHours(from.getHours() - 24);
            selectS = {
                properties: 'event,timestamp,eventContent.source'
            };
        } else {
            from.setMinutes(from.getMinutes() - 10);
        }

        const request: GetDataRawRequest = {
            date: {
                from: from.toISOString(),
                to: to.toISOString(),
            },
            requestType: <any> dataType.toLowerCase(),
            filter: tFilter,
            limit: 10000
        };

        if (selectS != null) {
            request.select = selectS;
        }

        await this.monitorDataLoaderService.loadData(request);
    }

    private createTelemetryRequestFilter(objectId, dataType, variables) {
        let tFilter = `objectId='${objectId}'`;
        if (dataType === 'variables') {
          const predicateConditions = variables.map(v => `variable='${v}'`);
          if (!!predicateConditions.length) {
            tFilter += ` and (${predicateConditions.join(' or ')})`;
          }
        }
        return tFilter;
      }
}
