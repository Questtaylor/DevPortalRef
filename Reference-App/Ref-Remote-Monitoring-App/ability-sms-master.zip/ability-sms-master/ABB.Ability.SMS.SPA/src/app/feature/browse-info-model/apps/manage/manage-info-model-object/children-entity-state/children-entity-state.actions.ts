export enum ChildrenEntityActionTypes {
  LOAD_CHILDREN = '[Manage Infomodel View] Load Children',
  CHILDREN_LOADED = '[Dataccess API] Children Loaded'
}

export class LoadChildren {
  readonly type = ChildrenEntityActionTypes.LOAD_CHILDREN;

  constructor(public payload: { objectId: string, model: string }) {
  }
}

export class ChildrenLoaded {
  readonly type = ChildrenEntityActionTypes.CHILDREN_LOADED;

  constructor(public payload: { entity: any }) {
  }
}


export type ChildrenEntityActions = LoadChildren | ChildrenLoaded;
