import {
    VariableDataReceivedActionPayload,
    EventDataReceivedActionPayload,
    LiveDataReceivedActionPayload,
    MonitorActions,
    MonitorActionTypes,
    LastValueDataReceivedActionPayload,
    LastWkAvgDataReceivedActionPayload,
    NewSearchActionPayload,
    VariableAddedActionPayload,
    VariableRemovedActionPayload,
    AvailableVariablesReceivedActionPayload,
    LastValueTelemetryReceivedPayload
  } from './monitor.actions';
  import { DataPoint, ValueBox, Variable } from '../_models/monitor.models';
  import { tassign } from 'tassign';
  import { AppState } from 'src/app/redux-core/redux-core';
  import { ActionReducer } from '@ngrx/store/src/models';
import { EventPoint } from '../../_models/event.model';

  export interface State extends AppState {
    monitor: MonitorState;
  }

  export const monitorReducers: ActionReducer<MonitorState> = monitorReducer;

  interface MonitorState {
    lastValue: ValueBox;
    lastWkAvg: ValueBox;
    variableData: DataPoint[];
    eventData: EventPoint[];
    mode: 'live' | 'historical';
    availableVariables: Variable[];
  }

  const monitorInitState: MonitorState = {
    variableData: null,
    eventData: null,
    lastValue: null,
    lastWkAvg: null,
    mode: 'live',
    availableVariables: null
  };

  function monitorReducer(state = monitorInitState, action: MonitorActions): MonitorState {
    switch (action.type) {
      case MonitorActionTypes.resetAction:
        return reduceResetAction();

      case MonitorActionTypes.newSearchAction:
        return reduceNewSearchAction(state, action.payload);

      case MonitorActionTypes.liveDataReceivedAction:
        return reduceLiveDataReceivedAction(state, action.payload);

      case MonitorActionTypes.eventDataReceivedAction:
        return reduceEventDataReceivedAction(state, action.payload);

      case MonitorActionTypes.variableDataReceivedAction:
        return reduceVariableDataReceivedAction(state, action.payload);

      case MonitorActionTypes.lastValueDataReceivedAction:
        return reduceLastValueDataReceivedAction(state, action.payload);

      case MonitorActionTypes.lastWkAvgDataReceivedAction:
        return reduceLastWkAvgDataReceivedAction(state, action.payload);

      case MonitorActionTypes.availableVariablesReceivedAction:
        return reduceAvailableVariablesReceivedAction(state, action.payload);

      case MonitorActionTypes.variableAddedAction:
        return reduceVariableAddedAction(state, action.payload);

      case MonitorActionTypes.variableRemovedAction:
        return reduceVariableRemovedAction(state, action.payload);

      case MonitorActionTypes.lastValueTelemetryReceivedAction:
        return reduceLastValueTelemetryReceivedAction(state, action.payload);
    }

    return state;
  }

  function reduceResetAction(): MonitorState {
    return tassign(monitorInitState);
  }

  function reduceNewSearchAction(state: MonitorState, payload: NewSearchActionPayload): MonitorState {
    return tassign(state, {
      mode: payload.mode,
      variableData: null
    });
  }

  function reduceEventDataReceivedAction(state: MonitorState, payload: EventDataReceivedActionPayload): MonitorState {
    return tassign(state, {
      mode: state.mode,
      eventData: payload.eventData
    });
  }

  function reduceVariableDataReceivedAction(state: MonitorState, payload: VariableDataReceivedActionPayload): MonitorState {
    return tassign(state, {
      mode: state.mode,
      variableData: payload.variableData
    });
  }

  function reduceLiveDataReceivedAction(state: MonitorState, payload: LiveDataReceivedActionPayload): MonitorState {
    if (payload) {
      return tassign(state, {
        variableData: payload.data.concat(state.variableData || [])
      });
    } else {
      return tassign(state, {
        mode: state.mode,
        variableData: []
      });
    }
  }

  function reduceLastValueDataReceivedAction(state: MonitorState, payload: LastValueDataReceivedActionPayload): MonitorState {
    return tassign(state, {
      lastValue: payload.lastValue
    });
  }

  function reduceLastWkAvgDataReceivedAction(state: MonitorState, payload: LastWkAvgDataReceivedActionPayload): MonitorState {
    return tassign(state, {
      lastWkAvg: payload.lastWkAvg
    });
  }

  function reduceAvailableVariablesReceivedAction(state: MonitorState, payload: AvailableVariablesReceivedActionPayload): MonitorState {
    return tassign(state, {
      availableVariables: payload.variables
    });
  }

  function reduceVariableAddedAction(state: MonitorState, payload: VariableAddedActionPayload): MonitorState {
    // let newArray: string[];
    // if (state.availableVariables) {
    //   newArray = state.availableVariables.slice();
    //   newArray.push(payload.variableName);
    // } else {
    //   newArray = [payload.variableName];
    // }

    return tassign(state, {
      availableVariables: state.availableVariables.map(content => {
        if (content.name !== payload.variableName) {
          return content;
        }
        return tassign(content, {selected: true});
      })
    });
  }

  function reduceVariableRemovedAction(state: MonitorState, payload: VariableRemovedActionPayload): MonitorState {
    // return tassign(state, {
    //   selectedVariables: state.availableVariables.filter(v => v !== payload.variableName)
    // });

    return tassign(state, {
      availableVariables: state.availableVariables.map(content => {
        if (content.name !== payload.variableName) {
          return content;
        }
        return tassign(content, {selected: false});
      })
    });
  }

  function reduceLastValueTelemetryReceivedAction(state: MonitorState, payload: LastValueTelemetryReceivedPayload): MonitorState {
    return tassign(state, {
      availableVariables: state.availableVariables.map(content => {
        const filtered = payload.variables.filter(v => v.name === content.name);
        if (filtered.length !== 1) {
          return content;
        } else {
          return tassign(content, {lastValue: filtered[0].lastValue, timestamp: filtered[0].timestamp});
        }
      })
    });
  }
