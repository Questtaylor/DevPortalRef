import {Component, OnInit} from '@angular/core';
import {ObjectsService} from 'ability-api';
import {NotificationMessage, NotificationsService} from 'abb-controls';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'abb-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public dataList: any;
  formDataExample: FormGroup;
  formDataTimerangeExample: FormGroup;
  testInputControl: FormGroup;
  abbControlsInput: any;

  constructor(private objectsService: ObjectsService, private notificationsService: NotificationsService, private fb: FormBuilder) {
  }

  public showNotification(type: 'log' | 'info' | 'warning' | 'error' | 'success' = 'log') {

    const message = new NotificationMessage('message', type, true);

    this.notificationsService.send(message);
  }

  public getDeviceTypes() {

    // this.objectsService.gremlinQuery('g.V()').subscribe(data => {
    //   debugger;
    // });


    // this.apiSvc.get('ModelDefinitions/abb.ability.device/types').subscribe(res => {
    //   this.dataList = res.data;
    //   console.log(this.dataList);
    // })
  }

  public onTestFormSubmit() {
    if (this.formDataExample.valid) {
      console.log(this.formDataExample.value);
    }

    if (this.formDataTimerangeExample.valid) {
      console.log(this.formDataTimerangeExample.value);
    }

  }

  ngOnInit(): void {
    this.formDataExample = this.fb.group({
      'data': ['', []]
    });
    this.testInputControl = this.fb.group({
      'data': ['', []]
    });

    this.formDataTimerangeExample = this.fb.group({
      'data': ['', []]
    });
  }
}
