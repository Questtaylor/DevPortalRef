import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ExampleRoutingModule} from './example-routing.module';
import {HomeComponent} from './home.component';
import {DataLoaderModule, DatePickerModule, DatePickerRangeModule, InputModule} from 'abb-controls';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';


@NgModule({
  imports: [
    CommonModule,
    ExampleRoutingModule,
    DataLoaderModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    DatePickerModule,
    DatePickerRangeModule,
    InputModule
  ],
  declarations: [HomeComponent],
  bootstrap: [],
  providers: []
})

export class ExampleModule {
}
