import { Component, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { DeviceState } from '../../device-redux/device.reducers';
import { filter, map } from 'rxjs/operators';
import { Subscription, Observable } from 'rxjs';
import { Command } from './_models/command.models';

@Component({
    selector: 'abb-command',
    templateUrl: 'command.component.html',
    styleUrls: ['command.component.scss']
})

export class CommandComponent implements OnDestroy {
    private readonly subscriptions: Subscription[];
    public commands$: Observable<Command[]>;

    constructor(deviceStore: Store<DeviceState>) {
        this.commands$ = deviceStore.pipe(
            select(s => s.device.objectDefintion),
            filter(s => s != null),
            map(p => p.methods.properties.map(item => (<Command>{
                    name: item.name,
                    inputs: item.values.filter(v => v.name === 'input').map(v => this.mapInput(v)),
                    model: p.model,
                    objectId: p.objectId
                }))
            )
        );
    }


    mapInput(input: any): {name: string, dataType: string} {
        for (const property in input.value) {
            if (input.value.hasOwnProperty(property)) {
                const result = {name: property.toString(), dataType: input.value[property].dataType};
                return result;
            }
        }
    }

    ngOnDestroy(): void {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }
}
