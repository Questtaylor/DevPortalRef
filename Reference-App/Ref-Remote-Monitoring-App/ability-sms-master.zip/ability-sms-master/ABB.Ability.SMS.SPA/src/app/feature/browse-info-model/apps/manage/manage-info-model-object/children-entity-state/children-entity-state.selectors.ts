import {createFeatureSelector, createSelector} from '@ngrx/store';
import {ChildrenEntityState} from './children-entity-state.reducer';

export const selectChildrenEntityState = createFeatureSelector<ChildrenEntityState>('childrenEntity');

export const selectChildrenByObjectId = (objectId: string) => createSelector(
  selectChildrenEntityState,
  childrenState => childrenState.entities[objectId]
);
