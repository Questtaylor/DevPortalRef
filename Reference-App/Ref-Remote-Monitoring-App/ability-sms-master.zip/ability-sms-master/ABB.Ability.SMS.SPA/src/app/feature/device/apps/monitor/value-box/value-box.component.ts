import { Component, Input } from '@angular/core';

@Component({
    selector: 'abb-value-box',
    styleUrls: ['value-box.component.scss'],
    templateUrl: 'value-box.component.html'
})

export class ValueBoxComponent {

    @Input() header: string;
    @Input() label: string;
    @Input() value?: string;
    @Input() icon?: string;
    @Input() colorClass?: string;

    constructor() { }

    getClass(): string {
        return `${this.icon} ${this.colorClass}`;
    }
}
