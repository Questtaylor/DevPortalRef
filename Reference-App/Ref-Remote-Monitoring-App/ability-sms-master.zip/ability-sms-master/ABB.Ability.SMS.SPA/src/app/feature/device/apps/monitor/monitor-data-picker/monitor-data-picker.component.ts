import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { select, Store } from '@ngrx/store';
import { State } from '../monitor-redux/monitor.reducer';
import { NewSearchActionPayload, NewSearchAction } from '../monitor-redux/monitor.actions';

@Component({
    selector: 'abb-monitor-data-picker',
    templateUrl: 'monitor-data-picker.component.html',
    styleUrls: ['monitor-data-picker.component.scss']
})

export class MonitorDataPickerComponent implements OnDestroy {

    useHistoricalData: boolean;
    subscriptions: Subscription[];
    disabled: boolean;

    constructor(private store: Store<State>) {
        const mode$ = this.store.pipe(select(s => s.monitor.mode), map(mode => mode === 'historical'));
        const disabled$ = this.store.pipe(select(s => s.monitor.variableData), map(vd => vd == null));

        this.subscriptions = [
            mode$.subscribe(m => this.historicalNotification(m)),
            disabled$.subscribe(d => this.disabled = d)
        ];

    }

  private historicalNotification(historical: boolean) {
    this.useHistoricalData = historical;
  }

  ngOnDestroy(): void {
    if (this.subscriptions) {
        this.subscriptions.forEach(s => s.unsubscribe());
    }
  }

  private selectRadio(isHistoricalDataMode: boolean) {
    if (this.disabled) {
      return;
    }
    const payload = <NewSearchActionPayload>{mode : isHistoricalDataMode ? 'historical' : 'live'};
    this.store.dispatch(new NewSearchAction(payload));
  }
}
