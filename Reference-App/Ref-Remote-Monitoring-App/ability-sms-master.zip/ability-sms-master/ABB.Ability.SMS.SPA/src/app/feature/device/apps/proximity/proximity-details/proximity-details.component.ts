import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { State } from '../proximity-redux/proximity.reducer';
import { Subscription, Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { EventPoint } from '../../_models/event.model';

@Component({
    selector: 'abb-proximity-details',
    templateUrl: 'proximity-details.component.html'
})

export class ProximityDetailsComponent implements OnDestroy {
    filteredEvents: EventPoint[];
    originalEvents: EventPoint[];
    beaconName: string;
    entryEvents: number;
    exitEvents: number;

    subscriptions: Subscription[];

    constructor(store: Store<State>) {
        const selectedBeacon$ = store.pipe(select(s => s.proximity.selectedBeacon), filter(b => b != null));
        const events$ = store.pipe(select(s => s.proximity.events), filter(e => e != null));

        this.subscriptions = [
            events$.subscribe(e => {
                this.originalEvents = e;
                this.setupEvents(this.originalEvents, this.beaconName);
            }),
            selectedBeacon$.subscribe(s => {
                this.beaconName = s;
                this.setupEvents(this.originalEvents, this.beaconName);
            }),
        ];
     }

    ngOnDestroy() {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }

    setupEvents(sourceEvents: EventPoint[], beaconName: string) {
        this.filteredEvents = sourceEvents.filter(fe => fe.source === beaconName);
        this.entryEvents = this.filteredEvents.filter(e => e.name.toLowerCase().indexOf('in') !== -1).length;
        this.exitEvents = this.filteredEvents.filter(e => e.name.toLowerCase().indexOf('out') !== -1).length;
    }
}
