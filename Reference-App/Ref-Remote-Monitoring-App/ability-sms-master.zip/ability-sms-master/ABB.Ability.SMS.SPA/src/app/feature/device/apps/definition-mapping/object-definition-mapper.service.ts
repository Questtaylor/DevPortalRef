import {Injectable} from '@angular/core';
import {ObjectDefinitionDetails} from './definition-mapping.models';
import {PropertyDefinitionMapperService} from './property-definition-mapper.service';

@Injectable()
export class ObjectDefinitionMapperService {

  constructor(private propertiesMapper: PropertyDefinitionMapperService) {
  }

  public mapObjectDefinitionDetails(response: any): ObjectDefinitionDetails {
    if (!response) {
      return null;
    }

    const result: ObjectDefinitionDetails = {
      objectId: response.objectId,
      description: response.description,
      name: response.name,
      model: response.model,
      type: response.type,
      version: response.version,
      variables: this.propertiesMapper.mapToObjectPropertiesInfo(response.variables, true),
      properties: this.propertiesMapper.mapToObjectPropertiesInfo(response.properties, true),
      methods: this.propertiesMapper.mapToObjectPropertiesInfo(response.methods, false)
    };
    return result;
  }
}
