import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'abb-dashboard-status-item',
    templateUrl: 'dashboard-status-item.component.html',
    styleUrls: ['dashboard-status-item.component.scss']
})

export class DashboardStatusItemComponent implements OnInit {

    @Input() label: string;
    @Input() value: string;
    @Input() icon: string;
    @Input() fontColor: string;

    constructor() { }

    ngOnInit() { }
}
