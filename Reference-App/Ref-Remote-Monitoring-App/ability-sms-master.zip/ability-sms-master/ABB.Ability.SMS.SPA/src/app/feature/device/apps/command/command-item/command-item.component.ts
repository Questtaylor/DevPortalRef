import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Command } from '../_models/command.models';
import { CommandsService, CallMethodRequest } from 'ability-api';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable, Subscription, interval } from 'rxjs';
import { CustomPlatformEvent } from 'src/app/services/signal-r/models/custom-platform-event';
import { Store, select } from '@ngrx/store';
import { AppState } from 'src/app/redux-core/redux-core';
import { map, take } from 'rxjs/operators';

@Component({
    selector: 'abb-command-item',
    templateUrl: 'command-item.component.html',
    styleUrls: ['command-item.component.scss']
})

export class CommandItemComponent implements OnInit, OnDestroy {

    @Input() command: Command;
    form: FormGroup;
    defaultMessage = 'No messages found';
    currentMessage = this.defaultMessage;
    disabled = false;

    private platformEvents$: Observable<CustomPlatformEvent[]>;
    private platformEventSubscription: Subscription;
    private timeoutSubscription: Subscription;

    constructor(private commandsService: CommandsService,
                private store: Store<AppState>) {

        this.platformEvents$ = this.store.pipe(select((state: AppState) => state.signalR.platformEvents),
                map(events => events.filter(e =>
                    (e.eventType.indexOf('.MethodInvoked') !== -1 || e.eventType.indexOf('.Method.Invoked') !== -1)
                    && e.eventText && e.eventText.indexOf(this.command.name) !== -1
                    && e.eventObject === this.command.objectId)));

        this.platformEventSubscription = this.platformEvents$.subscribe((platformevent: CustomPlatformEvent[]) => {
            if (platformevent && platformevent.length > 0) {
                console.log('event length: ', platformevent.length);
                this.currentMessage = 'Command invoked successfully!';
                this.disabled = false;
                if (this.timeoutSubscription) {
                    this.timeoutSubscription.unsubscribe();
                }
                this.showMessageAfterXSeconds(this.defaultMessage, 5, null);
            }
        });
    }

    ngOnInit() {
        const group: any = {};
        this.command.inputs.forEach(element => {
            let control: FormControl;
            switch (element.dataType) {
                case 'boolean':
                control = new FormControl('true');
                break;

                case 'file':
                control = new FormControl('', Validators.required);
                break;

                case 'string':
                control = new FormControl('', Validators.required);
                break;
            }

            group[element.name] = control;
        });
        this.form = new FormGroup(group);
    }

    ngOnDestroy(): void {
        if (this.platformEventSubscription) {
            this.platformEventSubscription.unsubscribe();
        }
        if (this.timeoutSubscription) {
            this.timeoutSubscription.unsubscribe();
        }
    }

    onSubmit() {
        this.currentMessage = 'Sending command...';
        this.disabled = true;
        const timeout = 30;

        const request: CallMethodRequest = {
            methodName: this.command.name,
            modelId: this.command.model,
            objectId: this.command.objectId,
            payload: {
                timeout,
                input: this.form.value
            }
        };

        this.commandsService.callMethod(request).toPromise().then(m => {
            this.currentMessage = 'Command sent. Awaiting response...';
            this.timeoutSubscription = this.showMessageAfterXSeconds('Timeout expired', timeout, () => {
                this.disabled = false;
                this.showMessageAfterXSeconds(this.defaultMessage, 5, null);
            });
        }, error => {
            this.disabled = false;
            this.currentMessage = 'Call to server failed.';
        });
    }

    showMessageAfterXSeconds(message: string, seconds: number, callback: () => void): Subscription {
        return interval(seconds * 1000).pipe(take(1)).subscribe(x => {this.currentMessage = message; if (callback) { callback(); }});
    }
}
