import { Action } from '@ngrx/store';
import { EventPoint } from '../../_models/event.model';

export enum ProximityActionTypes {
    resetAction = '[Proximity View] Reset',
    initCompletedAction = '[Proximity View] Init Completed',
    eventDataReceivedAction = '[Proximity View] Event Data Received',
    beaconSelectedAction = '[Proximity View] Beacon Selected'
}

/*--------*/
export class ResetAction implements Action {
    readonly type = ProximityActionTypes.resetAction;
}

/*--------*/
export class InitCompletedAction implements Action {
    readonly type = ProximityActionTypes.initCompletedAction;
}

/*--------*/
export interface EventDataReceivedActionPayload {
    eventData: EventPoint[];
}

export class EventDataReceivedAction implements Action {
    readonly type = ProximityActionTypes.eventDataReceivedAction;

    constructor(public payload: EventDataReceivedActionPayload) {
    }
}

/*--------*/
export interface BeaconSelectedActionPayload {
    beaconName: string;
}

export class BeaconSelectedAction implements Action {
    readonly type = ProximityActionTypes.beaconSelectedAction;

    constructor(public payload: BeaconSelectedActionPayload) {
    }
}

export type ProximityActions =
  ResetAction
  | InitCompletedAction
  | EventDataReceivedAction
  | BeaconSelectedAction;
