import {Action} from '@ngrx/store';
import { ObjectDefinitionDetails } from '../apps/definition-mapping';

export enum DeviceInfoActionTypes {
    resetAction = '[Device Info] Reset',
    initCompletedAction = '[Device Info] Init Completed'
}

/*--------*/
export class ResetAction implements Action {
    readonly type = DeviceInfoActionTypes.resetAction;
}

/*--------*/
export interface InitCompletedActionPayload {
    objectDefinition: ObjectDefinitionDetails;
}

export class InitCompletedAction implements Action {
    readonly type = DeviceInfoActionTypes.initCompletedAction;

    constructor(public payload: InitCompletedActionPayload) {
    }
}

/*--------*/
export type DeviceInfoActions =
    ResetAction
    | InitCompletedAction;
