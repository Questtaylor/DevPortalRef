import { Injectable, OnDestroy, OnInit } from '@angular/core';
import { Subscription, Subject } from 'rxjs';
import { Store, select } from '@ngrx/store';

import { State } from '../dashboard-redux/dashboard.reducer';
import { Marker } from '../_models/marker.models';
import {
  UpdateMarkersAction,
  UpdateMarkersActionPayload
} from '../dashboard-redux/dashboard.actions';
import { TableDevice } from '../../../shared/models/table-device.model';

@Injectable()
export class LocationsService implements OnInit, OnDestroy {
  public data: TableDevice[];
  public newCoordinates = new Subject<{lat: number, lon: number, zoom: number, objectId?: string}>();

  private readonly subscriptions: Subscription[];
  markers: Marker[];
  boundsObject: object;

  constructor(
    private store: Store<State>
  ) {
    this.subscriptions = [
      this.store.pipe(select(s => s.dashboard.devices)).subscribe(deviceData => this.setMarkersFromDeviceData(deviceData))
    ];
    this.markers = [];
    this.boundsObject = {};
  }

  ngOnInit() {
  }

  setMarkersFromDeviceData(deviceData: TableDevice[]) {
    const newMarkers = [];

    // Only display devices that are provisioned
    this.data = deviceData ? deviceData.filter(d => d.isProvisioned) : [];

    // Set map markers
    for (let i = 0; i < this.data.length; i += 1) {
      const currentDevice = this.data[i];
      const deviceBreadcrumb = (currentDevice.name || currentDevice.objectId)
        + ' - ' + currentDevice.serialNumber;

      const currentLocation = currentDevice.latLon;

      newMarkers.push({
        lat: currentLocation.lat,
        lon: currentLocation.lon,
        link: `/device/${currentDevice.model}/${currentDevice.type}/${currentDevice.objectId}/${encodeURI(deviceBreadcrumb)}/apps`,
        name: currentDevice.serialNumber ? currentDevice.serialNumber : currentDevice.name,
        objectId: currentDevice.objectId,
        infoBoxVisible: false,
        status: currentDevice.status,
        fake: currentDevice.fake
      });
    }

    // Internal markers (full list)
    this.markers = newMarkers;

    // Vs external markers (filtered list)
    const payload: UpdateMarkersActionPayload = {
      markers: this.getMarkersWithinGeoBounds(this.boundsObject)
    };

    this.store.dispatch(
      new UpdateMarkersAction(
        payload
      )
    );
  }

  setMarkerInfoBoxVisible(objectId) {
    // Replace internal markers list
    const newMarkers = [];
    for (let i = 0; i < this.markers.length; i += 1) {
      if (this.markers[i].objectId === objectId) {
        newMarkers.push(Object.assign({}, this.markers[i], {infoBoxVisible: true}));
      } else {
        newMarkers.push(Object.assign({}, this.markers[i], {infoBoxVisible: false}));
      }
    }
    this.markers = newMarkers;

    // Propagate bounded markers (@todo: would be nice to just propagate markers list and
    // have the geo bounds object updated separately to all components that care)
    const payload: UpdateMarkersActionPayload = {
      markers: this.getMarkersWithinGeoBounds(this.boundsObject)
    };
    this.store.dispatch(
      new UpdateMarkersAction(
        payload
      )
    );
  }

  getMarkersWithinGeoBounds(boundsObject = null) {
    if (boundsObject) {
      this.boundsObject = boundsObject;
    }

    const filteredMarkers = boundsObject ? this.markers.filter(function(marker: Marker) {

      // Latitude range greater than 90? We might see some longitudal wrapping. Just show everything.
      if (boundsObject.zoom <= 2) {
        return true;
      }

      // If the max longitude and min longitude are wrapping around the globe or in negative ranges,
      // bounds need to be offset in a way that markers can be checked.
      //
      // Although it seems to be working, I would consider this temporary.
      //
      // Open support thread in official GitHub to try and get help with this logic:
      // https://github.com/infusion-code/angular-maps/issues/91
      if (boundsObject.maxLongitude - boundsObject.minLongitude > 180) {
        const temp = boundsObject.minLongitude;
        boundsObject.minLongitude = -180 - (180 - boundsObject.maxLongitude);
        boundsObject.maxLongitude = temp;
      }

      if (boundsObject.maxLatitude - boundsObject.minLatitude > 180) {
        const temp = boundsObject.maxLatitude;
        boundsObject.maxLatitude = -180 - (180 - boundsObject.minLatitude);
        boundsObject.minLatitude = temp;
      }

      if (marker.lat < boundsObject.minLatitude) {
        return false;
      }
      if (marker.lat > boundsObject.maxLatitude) {
        return false;
      }
      if (marker.lon < boundsObject.minLongitude) {
        return false;
      }
      if (marker.lon > boundsObject.maxLongitude) {
        return false;
      }
      return true;
    }) : this.markers;

    return filteredMarkers;
  }

  ngOnDestroy() {
    if (this.subscriptions) {
      this.subscriptions.forEach(s => s.unsubscribe());
    }
  }

}
