import {
    DashboardActionTypes,
    DashboardActions,
    DeviceDataReceivedActionPayload,
    UpdateMarkersActionPayload,
    DeviceLocationReceivedActionPayload,
    DeviceStatusReceivedActionPayload
} from './dashboard.actions';
import { tassign } from 'tassign';
import { AppState } from 'src/app/redux-core/redux-core';
import { ActionReducer } from '@ngrx/store/src/models';
import { Device } from '../../../shared/models/device.model';
import { Marker } from '../_models/marker.models';
import { TableDevice } from '../../../shared/models/table-device.model';

export interface State extends AppState {
    dashboard: DashboardState;
}

export const dashboardReducers: ActionReducer<DashboardState> = dashboardReducer;

interface DashboardState {
    devices: TableDevice[];
    markers: Marker[];
}

const dashboardInitState: DashboardState = {
    devices: null,
    markers: []
};

function dashboardReducer(state = dashboardInitState, action: DashboardActions): DashboardState {
    switch (action.type) {
        case DashboardActionTypes.resetAction:
            return reduceResetAction();

        case DashboardActionTypes.initCompletedAction:
            return reduceInitCompletedAction(state);

        case DashboardActionTypes.deviceDataReceivedAction:
            return reduceDeviceDataReceivedAction(state, action.payload);

        case DashboardActionTypes.updateMarkers:
            return reduceUpdateMarkersAction(state, action.payload);

        case DashboardActionTypes.deviceLocationReceivedAction:
            return reduceDeviceLocationReceivedAction(state, action.payload);

        case DashboardActionTypes.deviceStatusReceivedAction:
            return reduceDeviceStatusReceivedAction(state, action.payload);
    }

    return state;
}

function reduceResetAction(): DashboardState {
    return tassign(dashboardInitState);
}

function reduceInitCompletedAction(state: DashboardState): DashboardState {
    return tassign(state, {
        devices: null
    });
}

function reduceDeviceDataReceivedAction(state: DashboardState, payload: DeviceDataReceivedActionPayload): DashboardState {
    const modified = payload.devices.map(content => {
        const existing = state.devices ? state.devices.filter(d => d.objectId === content.objectId) : [];
        if (existing.length !== 1) {
            return content;
        } else {
            return tassign(content, {status: existing[0].status});
        }
    });

    return tassign(state, {
        devices: modified
    });
}

function reduceUpdateMarkersAction(state: DashboardState, payload: UpdateMarkersActionPayload): DashboardState {
    return tassign(state, {
        markers: payload.markers,
    });
}

function reduceDeviceLocationReceivedAction(state: DashboardState, payload: DeviceLocationReceivedActionPayload): DashboardState {
    return tassign(state, {
        devices: state.devices.map(content => {
            const location = payload.locations.filter(l => l.objectId === content.objectId);
            if (location.length !== 1) {
                return content;
            }
            return tassign(content, {locationName: location[0].location});
        })
    });
}

function reduceDeviceStatusReceivedAction(state: DashboardState, payload: DeviceStatusReceivedActionPayload): DashboardState {
    return tassign(state, {
        devices: state.devices.map(content => {
            const status = payload.statuses.filter(s => s.objectId === content.objectId);
            if (status.length !== 1) {
                return tassign(content, {status: -1});
            }
            return tassign(content, {status: status[0].status});
        })
    });
}
