import { NgModule } from '@angular/core';

import { ProvisionComponent } from './provision.component';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ProvisionTableComponent } from './provision-table/provision-table.component';
import { provisionReducers } from './provision-redux/provision.reducers';
import { SharedModule } from 'src/app/shared';
import { StoreModule } from '@ngrx/store';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';

const routes = [
    {
        path: '',
        component: ProvisionComponent,
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        SharedModule,
        StoreModule.forFeature('provision', provisionReducers),
        NgxDatatableModule
    ],
    exports: [],
    declarations: [ProvisionComponent, ProvisionTableComponent]
})
export class ProvisionModule { }
