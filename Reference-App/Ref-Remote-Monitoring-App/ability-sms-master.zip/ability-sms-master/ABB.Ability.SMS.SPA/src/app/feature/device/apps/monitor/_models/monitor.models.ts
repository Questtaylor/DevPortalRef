/*represents single variable, alarm or event occurrence*/
export class DataPoint {
    /*
    * @param name name of variable, path of alarm or source of event
    * */
    constructor(public name: string,
      public friendlyName: string,
      public timestamp: string,
      public value: any,
      public type: 'timeseries' | 'alarm' | 'event') {
    }
}

export class ValueBox {
  constructor(public title: string,
    public subTitle: string,
    public value: string) {

  }
}

export interface Variable {
  name: string;
  unitOfMeasurement: string;
  friendlyName: string;
  selected: boolean;
  lastValue: any;
  timestamp: string;
}

