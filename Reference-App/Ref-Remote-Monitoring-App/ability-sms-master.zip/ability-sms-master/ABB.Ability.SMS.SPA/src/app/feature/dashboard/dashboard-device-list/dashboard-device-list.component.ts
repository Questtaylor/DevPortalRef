import { Component, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Subscription } from 'rxjs';

import { State } from '../dashboard-redux/dashboard.reducer';
import { LocationsService } from '../_services/locations.service';
import { Marker } from '../_models/marker.models';
import { TableDevice } from '../../../shared/models/table-device.model';

@Component({
  selector: 'abb-dashboard-device-list',
  templateUrl: './dashboard-device-list.component.html',
  styleUrls: ['./dashboard-device-list.component.scss'],
})
export class DashboardDeviceListComponent implements OnInit, OnDestroy {
  public data: TableDevice[];
  public originalData: TableDevice[];
  public markers: Marker[];
  private readonly subscriptions: Subscription[];

  constructor(
    private store: Store<State>,
    private locationsService: LocationsService
  ) {
    this.subscriptions = [
      this.store.pipe(select(s => s.dashboard.devices)).subscribe(m => this.assignData(m)),
      this.store.pipe(select(s => s.dashboard.markers)).subscribe(m => this.filterDataByMarkers(m))
    ];
  }

  ngOnInit() {
  }

  assignData(data: TableDevice[]) {
    this.originalData = data;
    this.filterDataByMarkers(this.markers);
  }

  filterDataByMarkers(markers: Marker[]) {
    if (this.originalData) {
      const filteredData = markers ? this.originalData.filter(dataItem => {
        return markers.find(function(marker: Marker): boolean {
          return marker.objectId === dataItem.objectId;
        });
      }) : this.originalData;

      this.data = filteredData;
    } else {
      this.data = null;
    }
  }

  onActivate($event) {
    if ($event.type === 'click') {
      // This is definitely messy but I'm not sure how else to detect "row clicked but not internal content"
      // for the time being
      const eventClassName = 'datatable-body-cell sort-active active';
      if ($event.event.target.className === eventClassName
        || $event.event.target.parentElement.className === eventClassName) {
          this.locationsService.newCoordinates.next(
            {
              zoom: 14,
              objectId: $event.row.objectId,
              lat: $event.row.latLon.lat,
              lon: $event.row.latLon.lon
            });
      }
    }
  }

  public ngOnDestroy(): void {
    if (this.subscriptions) {
      this.subscriptions.forEach(s => s.unsubscribe());
    }
  }
}
