import {Action} from '@ngrx/store';
import { TableDevice } from 'src/app/shared/models/table-device.model';

export enum ProvisionActionTypes {
    resetAction = '[Provision View] Reset',
    deviceDataReceivedAction = '[Provision View] Device Data Received'
}


/*--------*/
export class ResetAction implements Action {
    readonly type = ProvisionActionTypes.resetAction;
}

/*--------*/
export interface DeviceDataReceivedActionPayload {
    devices: TableDevice[];
}

export class DeviceDataReceivedAction implements Action {
    readonly type = ProvisionActionTypes.deviceDataReceivedAction;

    constructor(public payload: DeviceDataReceivedActionPayload) {
    }
}

export type ProvisionActions =
  ResetAction
  | DeviceDataReceivedAction;
