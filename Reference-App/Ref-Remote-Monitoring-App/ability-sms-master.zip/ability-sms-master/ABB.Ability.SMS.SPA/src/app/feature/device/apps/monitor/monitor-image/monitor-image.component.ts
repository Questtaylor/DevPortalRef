import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { DeviceState } from '../../../device-redux/device.reducers';
import { MonitorDataLoaderService } from '../_services/monitor-data-loader.service';
import { SearchFilesRequest } from 'ability-api';
import { DownloadFileRequest } from 'projects/ability-api/src/lib/files';
import { filter } from 'rxjs/operators';
import { DomSanitizer } from '@angular/platform-browser';
import { MsalService } from 'src/app/services/msal.service';

@Component({
    selector: 'abb-monitor-image',
    templateUrl: 'monitor-image.component.html',
    styleUrls: ['monitor-image.component.scss']
})

export class MonitorImageComponent implements OnDestroy {
    private subscriptions: Subscription[];

    public image: any;
    public imageLoaded: boolean;
    public imageError: boolean;

    canDownloadObjectFiles: boolean;
    canSearchObjectFiles: boolean;

    constructor(private deviceStore: Store<DeviceState>,
                private dataLoaderService: MonitorDataLoaderService,
                private sanitizer: DomSanitizer,
                private msalService: MsalService) {

        this.checkPermissions();

        this.configureSubscriptions();
    }

    checkPermissions() {
        const permissions = this.msalService.getPermissions();
        this.canDownloadObjectFiles = permissions.indexOf('object_model_file_download') !== -1;
        this.canSearchObjectFiles = permissions.indexOf('object_model_file_search') !== -1;
    }

    configureSubscriptions() {
        const object$ = this.deviceStore.pipe(
            select(s => s.device.objectDefintion),
            filter(s => s != null)
        );

        this.subscriptions = [];

        if (!this.canSearchObjectFiles || !this.canDownloadObjectFiles) {
            return;
        }

        this.subscriptions.push(
            object$.subscribe(async object => {
                const request: SearchFilesRequest = {
                    filter: `objectId='${object.objectId}' AND path='device/image/DeviceImage.png'`
                };
                const searchSubscription = this.dataLoaderService.searchFiles(request).subscribe(async response => {
                    if (response.data.length === 0) {
                        this.imageError = true;
                        return;
                    }

                    const downloadRequest: DownloadFileRequest = {
                        model: response.data[0].model,
                        objectId: response.data[0].objectId,
                        path: response.data[0].path
                    };

                    const downloadSubscription = this.dataLoaderService.downloadFile(downloadRequest).subscribe(async downloadResponse => {
                        this.image = this.sanitizer.bypassSecurityTrustUrl(window.URL.createObjectURL(downloadResponse));
                        this.imageLoaded = true;
                    }, () => {this.imageError = true; });

                    this.subscriptions.push(downloadSubscription);
                });

                this.subscriptions.push(searchSubscription);
            })
        );
    }

    ngOnDestroy(): void {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }
}
