export interface StatusMetric {
    label: string;
    value: string;
    icon: string;
    fontColor: string;
}
