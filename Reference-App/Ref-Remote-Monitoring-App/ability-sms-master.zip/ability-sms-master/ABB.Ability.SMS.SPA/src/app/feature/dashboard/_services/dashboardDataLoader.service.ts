import { Injectable } from '@angular/core';

import {
    DataService,
    GetDataRawRequest,
    GetDataAggregatedRequest
  } from 'ability-api';
import { LastLocation } from 'src/app/shared/models/location.models';
import { Store } from '@ngrx/store';
import { State } from '../dashboard-redux/dashboard.reducer';
import { TableDevice, mapFromDevice } from '../../../shared/models/table-device.model';
import { Device } from 'src/app/shared/models/device.model';
import {
    DeviceDataReceivedActionPayload, DeviceDataReceivedAction,
    DeviceLocationReceivedActionPayload, DeviceLocationReceivedAction, DeviceStatusReceivedActionPayload, DeviceStatusReceivedAction
} from '../dashboard-redux/dashboard.actions';
import { Location } from 'src/app/shared/models/location.models';
import * as fakeDevices from 'src/assets/json/fake-devices.json';
import { AzureMapsApiService } from 'src/app/services/azureMapsApi.service';
import { environment } from 'src/environments/environment';

@Injectable()
export class DashboardDataLoaderService {

    private fakeDevices: TableDevice[];
    constructor(private dataService: DataService,
                private store: Store<State>) {
      if (environment.showFakeDevices) {
        this.fakeDevices = this.getFakeDevices();
      } else {
        this.fakeDevices = [];
      }
    }

    public async populateDeviceData(originalDevices: Device[], azureMaps: AzureMapsApiService) {
      const tableDevices = originalDevices == null ? null : originalDevices.map(d => mapFromDevice(d));

      const objectIds = tableDevices.map(d => d.objectId);
      const lastLocations = await this.getMostRecentLocation(objectIds);

      tableDevices.forEach(d => {
          const location = lastLocations.filter(ll => ll.objectId === d.objectId && ll.latLon != null);
          if (location.length === 1) {
              d.latLon = location[0].latLon;
          }
      });

      this.fakeDevices.forEach(d => {
        tableDevices.push(d);
      });

      const payload: DeviceDataReceivedActionPayload = {
          devices: tableDevices
      };
      this.store.dispatch(new DeviceDataReceivedAction(payload));

      const dx = tableDevices.filter(d => !d.fake && d.latLon != null && d.latLon.lat !== 0 && d.latLon.lon !== 0).map(d => <Location>{
            objectId: d.objectId,
            latLon: d.latLon
          });

      const locations = await azureMaps.reverseGeocodeMultiple(dx);
      const locationPayload: DeviceLocationReceivedActionPayload = {
          locations
      };

      this.store.dispatch(new DeviceLocationReceivedAction(locationPayload));

      const statuses = await this.loadDeviceStatus(objectIds);

      this.fakeDevices.map(fd => ({objectId: fd.objectId, status: <any>fd.status})).forEach(d => {
        statuses.push(d);
      });

      const deviceStatusPayload: DeviceStatusReceivedActionPayload = {
          statuses
      };
      this.store.dispatch(new DeviceStatusReceivedAction(deviceStatusPayload));
    }

    public async getMostRecentLocation(objectIds: string[])
        : Promise<LastLocation[]> {

        const from = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
        const tasks = objectIds.map(async o => {
          const request: GetDataRawRequest = {
            date: {from: from.toISOString()},
            filter: `objectId='${o}' and variable='location'`,
            limit: 1,
            orderBy: {property: 'timestamp', order: 'desc'},
            requestType: 'variables',
          };

          const task = this.dataService.getDataRaw<any>(request)
            .toPromise();
          return task;
        });
        const responses = await Promise.all(tasks);
        const data: LastLocation[] = responses.filter(m => m.data.length > 0 && typeof m.data[0].value === 'string').map(m => ({
          objectId: <string>m.data[0].objectId,
          latLon: {lat: +m.data[0].value.split(',')[1], lon: +m.data[0].value.split(',')[0]},
          timestamp: <string>m.data[0].timestamp
        }));

        return data;
    }

    public async loadDeviceStatus(objectIds: string[]): Promise<{objectId: string, status: any}[]> {

      // return objectIds.map(o => ({objectId: o, status: Math.floor(Math.random() * Math.floor(3))}));
        let tFilter = 'objectId IN [';
        objectIds.forEach((o, index) => {
          tFilter += `'${o}'`;
          if (index < objectIds.length - 1) {
            tFilter += ',';
          }
        });
        tFilter += '] AND variable=\'onBatteryPower\'';
        const to = new Date();
        const from = new Date(to);
        from.setDate(to.getDate() - 7);

        const request: GetDataAggregatedRequest = {
            date: {
                from: from.toISOString(),
                to: to.toISOString()
            },
            select: {last: 'value, timestamp'},
            requestType: 'variables',
            filter: tFilter,
            orderBy: {
                property: 'timestamp',
                order: 'desc'
            },
            groupBy: {
                properties: 'objectId, variable'
            },
            limit: objectIds.length
        };
        return await this.dataService.getDataAggregated<any>(request).toPromise().then(s => {
          return s.data ? s.data.map(d => ({objectId: d.objectId, status: +d.last.value})) : [];
        });
    }

    private getFakeDevices(): TableDevice[] {
      return (<any>fakeDevices).default;
    }
}
