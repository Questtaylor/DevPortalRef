import { Component, OnInit, OnDestroy } from '@angular/core';
import { State } from '../dashboard-redux/dashboard.reducer';
import { Store, select } from '@ngrx/store';
import { Subscription, combineLatest, Subject } from 'rxjs';
import { TableDevice, getOEE } from 'src/app/shared/models/table-device.model';
import { StatusMetric } from '../_models/status-metric.model';
import { filter, skip, map } from 'rxjs/operators';
import { DecimalPipe } from '@angular/common';
import { Marker } from '../_models/marker.models';

@Component({
    selector: 'abb-dashboard-status',
    templateUrl: 'dashboard-status.component.html',
    styleUrls: ['dashboard-status.component.scss']
})

export class DashboardStatusComponent implements OnDestroy {

    subscriptions: Subscription[];
    data: StatusMetric[];

    fleetStatusType$ = new Subject<'overall' |  'map'>();
    fleetStatusType: 'overall' | 'map';

    constructor(private store: Store<State>) {
        this.subscriptions = [
            combineLatest(
                this.store.pipe(select(s => s.dashboard.devices),
                    filter(d => d !== null),
                    skip(2),
                    map(d => d.filter(df => df.isProvisioned))
                ),
                this.store.pipe(select(s => s.dashboard.markers)),
                this.fleetStatusType$
            ).pipe(skip(1)).subscribe(m => this.assignData(m)),
            this.fleetStatusType$.subscribe(t => this.fleetStatusType = t)
        ];
        this.fleetStatusType$.next('overall');
    }

    assignData(data: [TableDevice[], Marker[], 'overall' | 'map']) {
        let devices: TableDevice[];
        if (data[2] === 'map') {
            devices = this.filterDataByMarkers(data[0], data[1]);
        } else {
            devices = data[0];
        }

        const decimalPipe = new DecimalPipe('en-US');
        const deviceCount = devices ? devices.length : 0;
        const oee = deviceCount > 0 ?
            decimalPipe.transform(devices.map(d => getOEE(d)).reduce((total, current) => total += current) / deviceCount, '1.0-0') :
            0;
        const availability = deviceCount > 0 ?
            decimalPipe.transform((devices.filter(d => d.status !== -1).length / deviceCount * 100), '1.0-0') :
            0;
        const fault = deviceCount > 0 ? devices.filter(d => d.status !== 0).length : 0;

        this.data = [
            <StatusMetric>{
                label: 'Location',
                value: deviceCount.toString(),
                fontColor: 'text-black',
                icon: 'fa-map-marker'
            },
            <StatusMetric>{
                label: 'OEE',
                value: oee.toString(),
                fontColor: 'text-black',
                icon: 'fa-line-chart'
            },
            <StatusMetric>{
                label: 'Availability (%)',
                value: availability.toString(),
                fontColor: 'text-black',
                icon: 'fa-check-circle'
            },
            <StatusMetric>{
                label: 'Fault',
                value: fault.toString(),
                fontColor: fault > 0 ? 'text-red' : 'text-black',
                icon: 'fa-warning'
            }
        ];
    }

    selectRadio(fleetStatus: 'overall' | 'map') {
        if (fleetStatus) {
            this.fleetStatusType$.next(fleetStatus);
        }
    }

    filterDataByMarkers(devices: TableDevice[], markers: Marker[]): TableDevice[] {
        if (devices) {
          const filteredData = markers ? devices.filter(dataItem => {
            return markers.find(function(marker: Marker): boolean {
              return marker.objectId === dataItem.objectId;
            });
          }) : devices;

          return filteredData;
        } else {
          return null;
        }
      }

    ngOnDestroy(): void {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
        if (this.fleetStatusType$) {
            this.fleetStatusType$.unsubscribe();
        }
    }
}
