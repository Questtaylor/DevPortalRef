/*represents single event occurrence*/
export class EventPoint {
    constructor(public name: string,
      public timestamp: string,
      public source?: string) {
    }
}
