import {Injectable, OnDestroy} from '@angular/core';
import {
  CreateSubscriptionRequest,
  CreateSubscriptionResponse,
  DeleteSubscriptionRequest,
  DataService,
  SubscriptionsService,
  FilesService
} from 'ability-api';
import {DataPoint} from '../_models/monitor.models';
import {SignalRService} from '../../../../../services/signal-r/signal-r.service';
import {environment} from '../../../../../../environments/environment';
import {Store, select} from '@ngrx/store';
import {
  VariableDataReceivedAction,
  VariableDataReceivedActionPayload,
  EventDataReceivedAction,
  EventDataReceivedActionPayload,
  LiveDataReceivedAction,
} from '../monitor-redux/monitor.actions';
import {State} from '../monitor-redux/monitor.reducer';
import {GetDataRawRequest, GetDataResponse, GetDataAggregatedRequest,
        SearchFilesRequest, SearchFilesResponse, DownloadFileRequest
      } from 'ability-api';
import { Observable, Subscription } from 'rxjs';
import { DeviceState } from '../../../device-redux/device.reducers';
import { filter } from 'rxjs/operators';
import { getFriendlyNames } from '../../definition-mapping/definition-mapping.models';
import { EventPoint } from '../../_models/event.model';

@Injectable()
export class MonitorDataLoaderService implements OnDestroy {

  private existingSubscription: CreateSubscriptionResponse;
  private existingSubscriptionRequest: CreateSubscriptionRequest;
  private deviceSubscription: Subscription;
  private friendlyNames: {name: string, friendlyName: string}[];

  constructor(private store: Store<State>,
              deviceStore: Store<DeviceState>,
              private dataService: DataService,
              private subscriptionService: SubscriptionsService,
              private signalRService: SignalRService,
              private filesService: FilesService) {

    const self = this;
    const deviceObject$ = deviceStore.pipe(
        select(s => s.device.objectDefintion),
        filter(s => s != null)
    );

    this.deviceSubscription = deviceObject$.subscribe(object => {
      self.friendlyNames = getFriendlyNames(object);
    });
  }

  public loadRawData(rawDataRequest: GetDataRawRequest): Observable<GetDataResponse<any>> {
    return this.dataService.getDataRaw<{results: any[]}>(rawDataRequest);
  }

  public loadAggregatedData(aggregatedDataRequest: GetDataAggregatedRequest): Observable<GetDataResponse<any>> {
    return this.dataService.getDataAggregated<{results: any[]}>(aggregatedDataRequest);
  }

  public async loadData(rawDataRequest: GetDataRawRequest): Promise<void> {

    const data: GetDataResponse<any> = await this.dataService.getDataRaw<{ results: any[] }>(rawDataRequest).toPromise();
    // data items should be of type TimeSeriesMessageModel | DeviceEventModel

    if (rawDataRequest.requestType === 'variables' || rawDataRequest.requestType === 'alarms') {
      const mappedData = (data.data || []).map(m => new DataPoint(
        m.variable || m.alarm,
        this.friendlyNames.filter(f => f.name === (m.variable || m.alarm))[0].friendlyName,
        m.timestamp,
        m.value,
        !!m.alarm ? 'alarm' : (!!m.event ? 'event' : 'timeseries')
      )).filter(m => m.timestamp != null);

      this.store.dispatch(new VariableDataReceivedAction(<VariableDataReceivedActionPayload>{
        variableData: mappedData
      }));
    } else if (rawDataRequest.requestType === 'events') {
      const mappedData = (data.data || []).map(m => new EventPoint(
        m.event,
        m.timestamp,
        m['eventContent.source'] ? m['eventContent.source'] : null
      )).filter(m => m.timestamp != null);
      this.store.dispatch(new EventDataReceivedAction(<EventDataReceivedActionPayload>{
        eventData: mappedData
      }));
    }
  }

  public async loadHistoricalData(request: GetDataAggregatedRequest): Promise<void> {

    const data: GetDataResponse<any> = await this.dataService.getDataAggregated<{ results: any[] }>(request).toPromise();

    const mappedData = (data.data || []).map(m => new DataPoint(
      m.variable,
      this.friendlyNames.filter(f => f.name === (m.variable || m.alarm))[0].friendlyName,
      m.timestamp,
      m.avg.value,
      'timeseries')
    ).filter(m => m.timestamp != null);

    this.store.dispatch(new VariableDataReceivedAction(<VariableDataReceivedActionPayload>{
      variableData: mappedData
    }));
  }

  public async subscribeToLiveData(request: CreateSubscriptionRequest): Promise<void> {
    await this.clearExistingResults(false);

    this.existingSubscription = await this.subscriptionService.createSubscription(request).toPromise();
    this.existingSubscriptionRequest = request;

    this.store.dispatch(new LiveDataReceivedAction(null));

    const token = '';
    await this.signalRService.invokeOpenSubscription(this.existingSubscription, request.type, token);
  }

  public downloadFile(request: DownloadFileRequest): Observable<Blob> {
    return this.filesService.downloadFile(request);
  }

  public searchFiles(request: SearchFilesRequest): Observable<SearchFilesResponse> {
    return this.filesService.searchFiles(request);
  }

  public async ngOnDestroy(): Promise<void> {
    await this.clearExistingResults(true);
    if (this.deviceSubscription) {
      this.deviceSubscription.unsubscribe();
    }
  }

  private async clearExistingResults(isHistoricalSearch: boolean): Promise<void> {
    await this.deleteExistingSubscription();
  }

  private async deleteExistingSubscription(): Promise<void> {
    if (this.existingSubscription) {
      // TODO: check payload
      // const request: DeleteSubscriptionRequest = {
      //   subscriptionId: this.existingSubscription.subscriptionId,
      //   messageType: this.existingSubscriptionRequest.subscriptionFilter.messageType
      // };

      try {
        // await this.subscriptionService.deleteSubscription(request).toPromise();
      } catch (error) {
        console.error(`Cannot kill subscription! Details: ${error.message}`);
      }
      // close other channels
      await this.signalRService.invoke('CloseSubscription', {subscriptionId: this.existingSubscription.subscriptionId});
      this.existingSubscription = null;
    }
  }
}
