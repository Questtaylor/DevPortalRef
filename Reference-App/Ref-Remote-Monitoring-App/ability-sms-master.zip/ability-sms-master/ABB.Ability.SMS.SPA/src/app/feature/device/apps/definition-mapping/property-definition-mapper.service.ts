import { Injectable } from '@angular/core';
import { ObjectPropertiesInfo } from './definition-mapping.models';

@Injectable()
export class PropertyDefinitionMapperService {

  public mapToObjectPropertiesInfo(object: any, reduceNested: boolean): ObjectPropertiesInfo {
    const properties = Object.getOwnPropertyNames(object || {})
      .reduce((reducer, itemName) => {
        return this.reduceNestedProperties(object, itemName, reducer, itemName, reduceNested);
      }, []);

    const result: ObjectPropertiesInfo = {
      properties: properties.map(m => ({
        name: m.path,
        raw: m,
        values: Object.getOwnPropertyNames(m.item || {}).map(valueKey => {
          return { name: valueKey, value: m.item[valueKey] };
        })
      }))
    };

    return result;
  }

  private reduceNestedProperties(object: any, itemName: string, reducer: any[], path: string, reduceNested: boolean): { item: any, path: string }[] {
    const item = object[itemName];
    const itemHasNestedProperties = !!Object.getOwnPropertyNames(item)
      .map(nestedProperty => Object.getPrototypeOf(item[nestedProperty]).toString())
      .filter(m => m !== '' && m !== '0' && m !== 'false')
      .length;

    if (itemHasNestedProperties && reduceNested) {
      // recurse down
      Object.getOwnPropertyNames(item).reduce((reducerA, itemNameA) => {
        return this.reduceNestedProperties(item, itemNameA, reducerA, `${path}.${itemNameA}`, reduceNested);
      }, reducer);
    } else {
      reducer.push({ item, path });
    }
    return reducer;
  }
}
