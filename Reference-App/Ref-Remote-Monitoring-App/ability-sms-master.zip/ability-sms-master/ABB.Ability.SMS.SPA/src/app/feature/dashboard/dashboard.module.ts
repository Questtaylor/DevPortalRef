import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { StoreModule } from '@ngrx/store';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';

import { DashboardComponent } from './dashboard.component';
import { DashboardStatusComponent } from './dashboard-status/dashboard-status.component';
import { DashboardDeviceListComponent } from './dashboard-device-list/dashboard-device-list.component';
import { DashboardDeviceMapComponent } from './dashboard-device-map/dashboard-device-map.component';
import { dashboardReducers } from './dashboard-redux/dashboard.reducer';
import { LocationsService } from './_services/locations.service';
import { SharedModule } from '../../shared';
import { environment } from 'src/environments/environment';
import { DashboardDataLoaderService } from './_services/dashboardDataLoader.service';
import { DashboardStatusItemComponent } from './dashboard-status-item/dashboard-status-item.component';
import { DataLoaderModule } from 'projects/abb-controls/src/public_api';

import * as atlas from 'src/azure-maps-control';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

const routes = [
    {
        path: '',
        component: DashboardComponent,
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        SharedModule,
        DataLoaderModule,
        StoreModule.forFeature('dashboard', dashboardReducers),
        NgxDatatableModule,
        FormsModule,
        NgbModule
    ],
    declarations: [DashboardComponent, DashboardDeviceListComponent, DashboardDeviceMapComponent, DashboardStatusComponent,
        DashboardStatusItemComponent],
    providers: [
        LocationsService,
        DashboardDataLoaderService
   ],
})
export class DashboardModule {
    constructor() {
        atlas.setSubscriptionKey(environment.azureMapsKey);
    }
}
