import { AppState } from 'src/app/redux-core/redux-core';
import { ActionReducer } from '@ngrx/store';
import { ProximityActions, ProximityActionTypes, EventDataReceivedActionPayload, BeaconSelectedActionPayload } from './proximity.actions';
import { tassign } from 'tassign';
import { EventPoint } from '../../_models/event.model';

export interface State extends AppState {
    proximity: ProximityState;
}

export const proximityReducers: ActionReducer<ProximityState> = proximityReducer;

interface ProximityState {
    events: EventPoint[];
    selectedBeacon: string;
}

const proximityInitState: ProximityState = {
    events: null,
    selectedBeacon: null
};

function proximityReducer(state = proximityInitState, action: ProximityActions): ProximityState {
    switch (action.type) {
        case ProximityActionTypes.resetAction:
            return reduceResetAction();

        case ProximityActionTypes.initCompletedAction:
            return reduceInitCompletedAction(state);

        case ProximityActionTypes.eventDataReceivedAction:
            return reduceEventDataReceivedAction(state, action.payload);

        case ProximityActionTypes.beaconSelectedAction:
            return reduceBeaconSelectedAction(state, action.payload);
    }

    return state;
}

function reduceResetAction(): ProximityState {
    return tassign(proximityInitState);
}

function reduceInitCompletedAction(state: ProximityState): ProximityState {
    return tassign(state, {
        events: null
    });
}

function reduceEventDataReceivedAction(state: ProximityState, payload: EventDataReceivedActionPayload): ProximityState {
    return tassign(state, {
        events: payload.eventData
    });
}

function reduceBeaconSelectedAction(state: ProximityState, payload: BeaconSelectedActionPayload): ProximityState {
    return tassign(state, {
        selectedBeacon: payload.beaconName
    });
}
