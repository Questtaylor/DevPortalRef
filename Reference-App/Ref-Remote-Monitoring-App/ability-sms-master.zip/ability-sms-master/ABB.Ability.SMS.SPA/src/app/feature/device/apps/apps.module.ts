import { NgModule } from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';
import { AuthguardService } from 'src/app/services/authguard.service';

const routes = [
    {
        path: '',
        redirectTo: 'monitor'
    },
    {
        path: 'monitor',
        loadChildren: './monitor/monitor.module#MonitorModule',
    },
    {
        path: 'proximity',
        canActivate: [AuthguardService],
        loadChildren: './proximity/proximity.module#ProximityModule',
        data: {permissions: ['event_read']}
    },
    {
        path: 'command',
        canActivate: [AuthguardService],
        loadChildren: './command/command.module#CommandModule',
        data: {permissions: ['method_invoke']}

    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes)
    ],
    declarations: [],
    providers: [],
})
export class AppsModule { }
