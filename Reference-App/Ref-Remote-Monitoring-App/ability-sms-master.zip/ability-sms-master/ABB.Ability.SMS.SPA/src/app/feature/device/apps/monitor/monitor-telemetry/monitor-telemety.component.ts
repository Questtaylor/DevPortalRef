import { Component, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { ValueBox, Variable } from '../_models/monitor.models';
import { StatusInfo, createStatusInfo} from 'src/app/shared/models/device-status.model';
import { Store, select } from '@ngrx/store';
import { State } from '../monitor-redux/monitor.reducer';
import { map } from 'rxjs/operators';
import * as moment from 'moment';
import { EventPoint } from '../../_models/event.model';
import { DecimalPipe } from '@angular/common';
import { MsalService } from 'src/app/services/msal.service';

@Component({
    selector: 'abb-monitor-telemetry',
    templateUrl: 'monitor-telemetry.component.html',
    styleUrls: ['monitor-telemetry.component.scss']
})

export class MonitorTelemetryComponent implements OnDestroy {

    public lastValue: ValueBox;
    public lastWkAvg: ValueBox;
    public statusInfo: StatusInfo;
    public eventData$: Observable<EventPoint[]>;

    canReadEvents: boolean;
    canReadVariables: boolean;

    private readonly subscriptions: Subscription[];

    constructor(store: Store<State>, private msalService: MsalService) {
      this.eventData$ = store.pipe(select(s => s.monitor.eventData));

      this.subscriptions = [
        store.pipe(select(s => s.monitor.lastValue)).subscribe(m => this.lastValue = m),
        store.pipe(select(s => s.monitor.lastWkAvg)).subscribe(m => this.lastWkAvg = m),
        store.pipe(select(s => s.monitor.availableVariables),
                   map(variables => this.mapToLastValue(variables))
                  ).subscribe(m => this.lastValue = m),
        store.pipe(select(s => s.monitor.availableVariables),
                   map(variables => this.mapToDeviceStatus(variables))
                  ).subscribe(m => this.statusInfo = m)
      ];
      this.checkPermissions();
    }

    checkPermissions() {
      const permissions = this.msalService.getPermissions();
      this.canReadEvents = permissions.indexOf('event_read') !== -1;
      this.canReadVariables = permissions.indexOf('variable_read') !== -1;
    }

    public ngOnDestroy(): void {
      if (this.subscriptions) {
        this.subscriptions.forEach(s => s.unsubscribe());
      }
    }

    private mapToLastValue(variables: Variable[]): ValueBox {
      const decimalPipe = new DecimalPipe('en-US');
      if (variables == null) {
        return null;
      }

      const temp = variables.filter(v => v.name === 'temperature');
      if (temp.length !== 1) {
        return null;
      }

      return <ValueBox> {
        subTitle: temp[0].timestamp != null ? moment(temp[0].timestamp).format('MM[-]DD[-]YY, h:mm:ss a') : null,
        value: temp[0].lastValue ? decimalPipe.transform(temp[0].lastValue, '1.0-2') : '',
        title: temp[0].unitOfMeasurement ? `${temp[0].friendlyName} (${temp[0].unitOfMeasurement})` : temp[0].friendlyName
      };

    }

    private mapToDeviceStatus(variables: Variable[]): StatusInfo {
      if (variables == null) {
        return null;
      }

      const temp = variables.filter(v => v.name === 'onBatteryPower');
      if (temp.length !== 1) {
        return null;
      }

      const status = +temp[0].lastValue;
      return createStatusInfo(status);
    }
}
