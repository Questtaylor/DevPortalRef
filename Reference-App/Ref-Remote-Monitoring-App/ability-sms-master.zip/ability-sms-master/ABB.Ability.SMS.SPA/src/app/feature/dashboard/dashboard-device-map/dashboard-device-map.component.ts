import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import {
  UpdateMarkersAction,
  UpdateMarkersActionPayload
} from '../dashboard-redux/dashboard.actions';
import { State } from '../dashboard-redux/dashboard.reducer';

import { Marker } from '../_models/marker.models';
import { LocationsService } from '../_services/locations.service';
import { Router } from '@angular/router';
import * as atlas from 'src/azure-maps-control';
import {HtmlMarkerLayer, HtmlMarker} from '../_models/htmlmarkerlayer.models';
import {PieChartMarker} from '../_models/piechartmarker.models';

@Component({
  selector: 'abb-dashboard-device-map',
  templateUrl: './dashboard-device-map.component.html',
  styleUrls: ['./dashboard-device-map.component.scss']
})
export class DashboardDeviceMapComponent implements OnInit, OnDestroy {
  public boundsObject: {};
  public markers: Marker[];

  private newCoordinatesSubscription: Subscription;
  private openWindowSubscription: Subscription;
  private markersSubscription: Subscription;

  map: atlas.Map;
  popupTemplate = '<div class="customInfobox" style="padding: 10px"><div class="name">{name}</div></div>';
  popupTemplateLink = '<div class="customInfobox" style="padding: 10px"><div class="name">{name}</div><hr/><a href="{link}">Go to device</a></div>';

  private entityTypes = [-1, 0, 1, 2];
  private entityTypeColors = ['#8C8C8C', '#79DA4C', '#FAFF00', '#FF0000'];

  constructor(
    private router: Router,
    private locationsService: LocationsService,
    private store: Store<State>
  ) {}

  ngOnInit() {
    const self = this;
    this.map = this.mapInit();

    this.map.events.addOnce('ready', (ready: atlas.MapEvent) => {

      const popup = new atlas.Popup({
        position: [0, 0],
        pixelOffset: [0, -18]
      });

      this.propagateNewGeoBoundaries(this.map.getCamera());
      const source = new atlas.source.DataSource('markers', {
        cluster: true,
        clusterRadius: 40,
        clusterMaxZoom: 13
      });

      const markerLayer = new HtmlMarkerLayer(source, null, {
        source: source,
        markerRenderCallback: (id, position, properties) => {
          const marker = new HtmlMarker({
            position: position,
            color: self.entityTypeColors[properties.status + 1]
          });
          self.addEvent('click', marker, (eventType, marker1) => self.markerClicked(eventType, marker1, source, popup));

          return marker;
        },
        clusterRenderCallback: (id, position, properties) => {
          let radius = 20;
          if (properties.point_count > 1000) {
              radius = 50;
          } else if (properties.point_count > 100) {
              radius = 40;
          } else if (properties.point_count > 10) {
              radius = 30;
          }
          const cluster = new PieChartMarker({
              position: position,
              values: [0, 0, 0, 0],
              colors: self.entityTypeColors,
              radius: radius,
              strokeThickness: 1,
              strokeColor: 'white',
              innerRadius: radius * 0.5,
              text: properties.point_count_abbreviated,
              visible: false // Hide the cluster until the pie chart values have been calculated.
          }, (marker, sliceIdx) => {
            const value = marker.getSliceValue(sliceIdx);
            const percent = marker.getSlicePercentage(sliceIdx);
            const text = `${value} (${percent}%)`;
            return text;
          });
          // Count for each EntityType in cluster [Gas Station, Grocery Store, Restaurant, School]
          // Get all the child point objects of a cluster then aggregage the count of each EntityType in the cluster.
          source.getClusterLeaves(properties.cluster_id, Infinity, 0).then(children => {
              const values = [0, 0, 0, 0];
              for (let i = 0; i < children.length; i++) {
                const status = (<any>children[i]).properties.status;
                values[self.entityTypes.indexOf(status)]++;
              }
              cluster.setOptions({
                  values: values,
                  visible: true,
                  innerRadius: 0
              });
          });

          self.addEvent('click', cluster, (eventType, marker1) => self.markerClicked(eventType, marker1, source, popup));
          return cluster;
        }
      });

      this.map.sources.add(source);

      this.map.layers.add(markerLayer);

      this.map.events.add('moveend', (e: atlas.MapEvent) => {
        this.propagateNewGeoBoundaries(e.map.getCamera());
      });

      this.map.controls.add(new atlas.control.ZoomControl(), { position: atlas.ControlPosition.BottomRight });

      // this.map.controls.add(new atlas.control.PitchControl(), { position: atlas.ControlPosition.BottomRight });

      // this.map.controls.add(new atlas.control.CompassControl(), { position: atlas.ControlPosition.BottomLeft });

      this.map.controls.add(new atlas.control.StyleControl(), { position: atlas.ControlPosition.TopRight });

      // Refresh map markers if ex: device list gets updated
      this.markersSubscription = this.store.pipe(select(s => s.dashboard.markers)).subscribe(markers => {
        this.markers = markers;

        const shapes = this.markers.map(m => {
          return new atlas.data.Feature(new atlas.data.Point([m.lon, m.lat]), {
            name: m.name,
            status: m.status,
            link: m.link,
            fake: m.fake,
            objectId: m.objectId
          });
        });

        source.setShapes(shapes);
      });

      // this.setCurrentPosition();

      // Zoom to new location after search
      this.newCoordinatesSubscription = this.locationsService.newCoordinates.subscribe(
        (coords) => {
          if (coords) {
            this.map.setCamera({
                center: [coords.lon, coords.lat],
                zoom: coords.zoom,
                type: 'ease',
                duration: 1000
            });
            if (coords.objectId) {
              const marker = this.markers.filter(m => m.objectId === coords.objectId)[0];
              const content = this.setPopupContent(marker);
              const coordinate = [coords.lon, coords.lat];

              popup.setOptions({
                // Update the content of the popup.
                content: content,
                // Update the position of the popup with the symbols coordinate.
                position: coordinate
              });
              popup.open(this.map);
            }
          }
        }
      );
    });
  }

  mapInit(): atlas.Map {
    const atlasMap = new atlas.Map('map', {
      zoom: 3,
      center: [-97.118042, 39.978371]
    });

    return atlasMap;
  }

  clickedMarkerNavigate(link: string): any {
    return this.router.navigateByUrl(link);
  }

  propagateNewGeoBoundaries(camera: atlas.CameraOptions & atlas.CameraBoundsOptions) {
    const bounds = camera.bounds;
    const newBounds = {
      minLatitude: bounds[1],
      minLongitude: bounds[0],
      maxLongitude: bounds[2],
      maxLatitude: bounds[3],
      zoom: camera.zoom
    };

    this.boundsObject = Object.assign({}, this.boundsObject, newBounds);

    const payload: UpdateMarkersActionPayload = {
      markers: this.locationsService.getMarkersWithinGeoBounds(this.boundsObject)
    };

    this.store.dispatch(
      new UpdateMarkersAction(
        payload
      )
    );
  }

  // When app is open for the first time, check if browser has geolocate ability, then set position.
  private setCurrentPosition() {
    if ('geolocation' in navigator) {
      // Browsers asks for permission to track before this function gets invoked.
      navigator.geolocation.getCurrentPosition((position) => {
        this.locationsService.newCoordinates.next({
          lat: position.coords.latitude,
          lon: position.coords.longitude,
          zoom: 3
        });
      });
    }
  }

  addEvent(eventType: any, marker: any, handler: any) {
    if (eventType && marker && handler) {
      const options = marker.getOptions();
      const html = options.htmlContent;
      let elm = html;
      if (typeof html === 'string') {
          elm = document.createElement('div');
          elm.innerHTML = html.replace(/{color}/g, options.color || '')
              .replace(/{text}/g, options.text || '');
          marker.setOptions({ htmlContent: elm });
      }
      elm.style.cursor = 'pointer';
      elm['on' + eventType] = function () {
          handler(eventType, marker);
      };
    }
  }

  markerClicked(eventType: any, marker: HtmlMarker, source: atlas.source.DataSource, popup: atlas.Popup) {
    const self = this;
    if (marker.properties.cluster) {
          // Get the cluster expansion zoom level. This is the zoom level at which the cluster starts to break apart.
          source.getClusterExpansionZoom(marker.properties.cluster_id).then(function (zoom) {
            // Update the map camera to be centered over the cluster.
            self.map.setCamera({
                center: marker.getOptions().position,
                zoom: zoom,
                type: 'ease',
                duration: 1000
            });
          });
    } else {
      const content = this.setPopupContent(marker.properties);

      popup.setOptions({
          content: content,
          position: marker.getOptions().position
      });
      popup.open(self.map);
    }
  }

  setPopupContent(data: any) {
    if (data.fake) {
      return this.popupTemplate.replace(/{name}/g, data.name);
    } else {
      return this.popupTemplateLink.replace(/{name}/g, data.name).replace(/{link}/g, data.link);
    }
  }

  ngOnDestroy() {
    if (this.newCoordinatesSubscription) {
      this.newCoordinatesSubscription.unsubscribe();
    }
    if (this.openWindowSubscription) {
      this.openWindowSubscription.unsubscribe();

    }
    if (this.markersSubscription) {
      this.markersSubscription.unsubscribe();
    }
    if (this.map) {
      this.map.dispose();
      this.map = null;
    }
  }
}
