import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router, NavigationEnd} from '@angular/router';
import { ObjectsService, GetObjectRequest} from 'ability-api';
import { NotificationMessage, NotificationsService} from 'abb-controls';
import { ObjectDefinitionMapperService } from './apps/definition-mapping';
import { Store } from '@ngrx/store';
import { DeviceState } from './device-redux/device.reducers';
import { InitCompletedActionPayload, InitCompletedAction, ResetAction } from './device-redux/device.actions';
import { MsalService } from 'src/app/services/msal.service';

@Component({
    selector: 'abb-device',
    templateUrl: 'device.component.html',
    styleUrls: ['./device.component.scss']
})

export class DeviceComponent implements OnDestroy {

    private readonly subscriptions: Subscription[];
    private objectId: string;
    private modelId: string;
    private breadcrumb: string;
    private links: any[];
    private canInvokeMethods: boolean;
    private canReadEvents: boolean;

    constructor(private store: Store<DeviceState>,
                private notificationsService: NotificationsService,
                private objectsService: ObjectsService,
                private objectMapperService: ObjectDefinitionMapperService,
                private activatedRoute: ActivatedRoute,
                private router: Router,
                private msalService: MsalService) {

        this.checkPermissions();

        this.links =  [
            {name: 'monitor', active: false, visible: true},
            {name: 'command', active: false, visible: this.canInvokeMethods},
            {name: 'proximity', active: false, visible: this.canReadEvents}
        ];

        this.subscriptions = [
            activatedRoute.params.subscribe(async params => {
                this.objectId = params['objectId'];
                this.modelId = params['modelId'];
                this.breadcrumb = params['breadcrumb'];

                await this.init(this.objectId, this.modelId);
            }),
            router.events.subscribe(val => {
                if (val instanceof NavigationEnd) {
                    const segments = val.urlAfterRedirects.split('/');
                    const app = segments[segments.length - 1];
                    this.links.forEach(link => {
                        if (app === link.name) {
                            link.active = true;
                        } else {
                            link.active = false;
                        }
                    });
                }
            })
        ];
    }

    checkPermissions() {
        const permissions = this.msalService.getPermissions();
        this.canInvokeMethods = permissions.indexOf('method_invoke') !== -1;
        this.canReadEvents = permissions.indexOf('event_read') !== -1;
    }

    public ngOnDestroy(): void {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }

    private async init(objectId: string, modelId: string): Promise<void> {
        this.store.dispatch(new ResetAction());

        await this.getObjectDefinition(objectId, modelId);
    }

    private async getObjectDefinition(objectId: string, modelId: string): Promise<void> {
        try {

          const request: GetObjectRequest = {
            modelId,
            objectId,
            isHolistic: true
          };

          const objectDefinitionResponse = await this.objectsService.getObject<any>(request).toPromise();
          const objectDefinition = this.objectMapperService.mapObjectDefinitionDetails(objectDefinitionResponse);

          const payload: InitCompletedActionPayload = {
            objectDefinition
          };

          this.store.dispatch(new InitCompletedAction(payload));
        } catch (ex) {
            this.notificationsService.send(
                new NotificationMessage('Failed to load object definition', 'error', true),
                new NotificationMessage(ex, 'error')
            );
        }
    }

    public navigate(component: string) {
        const relativeUrl = ['../' + this.breadcrumb + '/apps/' + component];
        this.router.navigate(relativeUrl, {relativeTo: this.activatedRoute});
    }
}
