import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'abb-analytics',
    templateUrl: 'analytics.component.html'
})

export class AnalyticsComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}
