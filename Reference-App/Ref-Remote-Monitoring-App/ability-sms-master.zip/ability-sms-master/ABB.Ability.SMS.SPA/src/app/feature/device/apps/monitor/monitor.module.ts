import { NgModule } from '@angular/core';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgSelectModule } from '@ng-select/ng-select';
import { ChartsModule } from 'ng2-charts';
import { StoreModule } from '@ngrx/store';
import { DataLoaderModule, FormControlContainerModule } from 'abb-controls';
import { EffectsModule } from '@ngrx/effects';
import { MomentModule } from 'ngx-moment';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { MonitorImageComponent } from './monitor-image/monitor-image.component';
import { MonitorDataChartComponent } from './monitor-data-chart/monitor-data-chart.component';
import { MonitorEventTableComponent } from './monitor-event-table/monitor-event-table.component';
import { MonitorTelemetryComponent } from './monitor-telemetry/monitor-telemety.component';
import { MonitorDataPickerComponent } from './monitor-data-picker/monitor-data-picker.component';
import { MonitorVariablePickerComponent } from './monitor-variable-picker/monitor-variable-picker.component';
import { MonitorComponent } from './monitor.component';
import { ValueBoxComponent } from './value-box/value-box.component';
import { GaMigrationModule } from '../../../../ga-migration/ga-migration.module';
import { monitorReducers } from './monitor-redux/monitor.reducer';
import { MonitorLiveDataEffects } from './monitor-redux/monitor.effects';

const routes = [
    {
        path: '',
        component: MonitorComponent
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ChartsModule,
        NgSelectModule,
        NgxDatatableModule,
        DataLoaderModule,
        MomentModule,
        StoreModule.forFeature('monitor', monitorReducers),
        EffectsModule.forFeature([MonitorLiveDataEffects]),
        GaMigrationModule,
        NgbModule,
        FormsModule,
        ReactiveFormsModule,
        FormControlContainerModule
    ],
    exports: [],
    declarations: [
        MonitorComponent, MonitorDataChartComponent, MonitorEventTableComponent,
        ValueBoxComponent, MonitorTelemetryComponent, MonitorDataPickerComponent,
        MonitorVariablePickerComponent, MonitorImageComponent
    ],
    providers: [],
})
export class MonitorModule { }
