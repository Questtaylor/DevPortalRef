import { NgModule } from '@angular/core';

import { AnalyticsComponent } from './analytics.component';
import { RouterModule } from '@angular/router';

const routes = [
    {
        path: '',
        component: AnalyticsComponent,
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [],
    declarations: [AnalyticsComponent],
    providers: [],
})
export class AnalyticsModule { }
