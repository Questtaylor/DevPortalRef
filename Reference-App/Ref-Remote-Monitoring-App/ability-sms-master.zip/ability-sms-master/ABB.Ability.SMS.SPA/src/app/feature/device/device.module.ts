import { NgModule } from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';

import { DeviceComponent } from './device.component';
import { StoreModule } from '@ngrx/store';
import { deviceReducers } from './device-redux/device.reducers';
import { DefinitionMappingModule } from './apps/definition-mapping/definition-mapping.module';
// import { BreadcrumbsModule } from 'ng6-breadcrumbs';

const routes = [
    {
        path: ':modelId/:typeId/:objectId/:breadcrumb',
        component: DeviceComponent,
        children: [
            {
                path: 'apps',
                loadChildren: './apps/apps.module#AppsModule',
            },
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'apps'
            }
        ]
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        StoreModule.forFeature('device', deviceReducers),
        DefinitionMappingModule,
        // BreadcrumbsModule
    ],
    exports: [],
    declarations: [DeviceComponent]
})
export class DeviceModule { }
