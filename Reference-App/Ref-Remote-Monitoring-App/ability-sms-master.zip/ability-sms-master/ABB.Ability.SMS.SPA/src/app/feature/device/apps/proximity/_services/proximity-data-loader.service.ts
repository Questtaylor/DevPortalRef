import { Injectable } from '@angular/core';
import { DataService, GetDataRawRequest, GetDataResponse } from 'ability-api';
import { EventPoint } from '../../_models/event.model';
import { Store } from '@ngrx/store';
import { State } from '../proximity-redux/proximity.reducer';
import { EventDataReceivedAction } from '../proximity-redux/proximity.actions';
import { EventDataReceivedActionPayload } from '../../monitor/monitor-redux/monitor.actions';
import { AggregateEvent } from '../_models/aggregateEvent.model';
import { distinct } from 'src/app/shared/functions/distinct.function';

@Injectable()
export class ProximityDataLoaderService {

  constructor(private store: Store<State>,
      private dataService: DataService) { }

  public async loadData(rawDataRequest: GetDataRawRequest): Promise<void> {

    const data: GetDataResponse<any> = await this.dataService.getDataRaw<{ results: any[] }>(rawDataRequest).toPromise();

    if (rawDataRequest.requestType === 'events') {
      const mappedData = (data.data || []).map(m => new EventPoint(
        m.event,
        m.timestamp,
        m['eventContent.source'] ? m['eventContent.source'] : null
      )).filter(m => m.timestamp != null);
      this.store.dispatch(new EventDataReceivedAction(<EventDataReceivedActionPayload>{
        eventData: mappedData
      }));
    }
  }
}
