import { Component, OnInit, OnDestroy } from '@angular/core';
import { ObjectsService } from 'ability-api';
import { Subscription, interval } from 'rxjs';
import { startWith } from 'rxjs/operators';
import { DeviceDataReceivedActionPayload, DeviceDataReceivedAction, ResetAction } from './provision-redux/provision.actions';
import { Store } from '@ngrx/store';
import { State } from './provision-redux/provision.reducers';
import { Device } from 'src/app/shared/models/device.model';
import { mapFromDevice } from 'src/app/shared/models/table-device.model';

@Component({
    selector: 'abb-provision',
    templateUrl: 'provision.component.html'
})

export class ProvisionComponent implements OnInit, OnDestroy {
    private subscriptions: Subscription[];

    constructor(private objectsService: ObjectsService,
                private store: Store<State>) { }

    ngOnInit() {
        const self = this;
        this.store.dispatch(new ResetAction());

        this.subscriptions = [
            interval(30000).pipe(startWith(0)).subscribe(() => {
                this.loadObjects().then(function(data) {
                    const payload: DeviceDataReceivedActionPayload = {
                        devices: data.map(d => mapFromDevice(d))
                    };
                    self.store.dispatch(new DeviceDataReceivedAction(payload));
                });
            })
        ];
    }

    ngOnDestroy(): void {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }

    private async loadObjects(): Promise<Device[]> {
        const result = await this.objectsService.getAllObjects<Device>().toPromise();

        return result.data;
    }
}
