import {Injectable} from '@angular/core';
import {TypeDefinitionDetails} from './definition-mapping.models';
import {PropertyDefinitionMapperService} from './property-definition-mapper.service';
import {BasicTypeDefinition} from 'ability-api';

@Injectable()
export class TypeDefinitionMapperService {

  constructor(private propertiesMapper: PropertyDefinitionMapperService) {
  }

  public mapTypeDefinitionDetails(response: BasicTypeDefinition): TypeDefinitionDetails {
    if (!response) {
      return null;
    }

    const result: TypeDefinitionDetails = {
      name: response.name,
      model: response.model,
      version: response.version,
      typeId: response.typeId,

      variables: this.propertiesMapper.mapToObjectPropertiesInfo(response.variables, true),
      properties: this.propertiesMapper.mapToObjectPropertiesInfo(response.properties, true),
      methods: this.propertiesMapper.mapToObjectPropertiesInfo(response.methods, false)
    };
    return result;
  }

}
