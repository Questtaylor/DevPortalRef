import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, Observable} from 'rxjs';
import { Store, select } from '@ngrx/store';
import { DeviceState } from '../../../device-redux/device.reducers';
import { VariableAddedAction, VariableAddedActionPayload,
    VariableRemovedActionPayload, VariableRemovedAction } from '../monitor-redux/monitor.actions';
import { Variable } from '../_models/monitor.models';
import { map, filter } from 'rxjs/operators';
import { State } from '../monitor-redux/monitor.reducer';

@Component({
    selector: 'abb-monitor-variable-picker',
    templateUrl: 'monitor-variable-picker.component.html',
    styleUrls: ['monitor-variable-picker.component.scss']
})

export class MonitorVariablePickerComponent implements OnDestroy {

    public variables$: Observable<Variable[]>;
    public disableSelection: boolean;

    private readonly subscriptions: Subscription[];

    constructor(private store: Store<State>) {

        this.variables$ = this.store.pipe(select(s => s.monitor.availableVariables));

        this.subscriptions = [
            this.variables$.subscribe(v => {
                this.disableSelection = v === null ? true : v.filter(sel => sel.selected).length >= 3;
            })
        ];
    }

    selectVariable(variableName: string, selected: boolean) {
        if (!selected) {
            const payload: VariableAddedActionPayload = {
                variableName
            };
            this.store.dispatch(new VariableAddedAction(payload));
        } else {
            const payload: VariableRemovedActionPayload = {
                variableName
            };
            this.store.dispatch(new VariableRemovedAction(payload));
        }

    }

    ngOnDestroy() {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }
}
