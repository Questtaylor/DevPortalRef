import { NgModule } from '@angular/core';

import { ProximityComponent } from './proximity.component';
import { RouterModule } from '@angular/router';
import { ProximityTableComponent } from './proximity-table/proximity-table.component';
import { CommonModule } from '@angular/common';
import { proximityReducers } from './proximity-redux/proximity.reducer';
import { StoreModule } from '@ngrx/store';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MomentModule } from 'ngx-moment';
import { DataLoaderModule } from 'abb-controls';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProximityAggregationService } from './_services/proximity-aggregation.service';
import { ProximityDetailsComponent } from './proximity-details/proximity-details.component';


const routes = [
    {
        path: '',
        component: ProximityComponent
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        StoreModule.forFeature('proximity', proximityReducers),
        DataLoaderModule,
        NgxDatatableModule,
        MomentModule,
        NgbModule
    ],
    exports: [],
    declarations: [ProximityComponent, ProximityTableComponent, ProximityDetailsComponent],
    providers: [ProximityAggregationService],
})
export class ProximityModule { }
