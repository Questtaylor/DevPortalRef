export interface Marker {
    lat: number;
    lon: number;
    link: string;
    name?: string;
    objectId: string;
    infoBoxVisible: boolean;
    status: number;
    fake: boolean;
}
