import {AppState} from 'src/app/redux-core/redux-core';
import {ActionReducer} from '@ngrx/store/src/models';
import {tassign} from 'tassign';
import { DeviceInfoActions, DeviceInfoActionTypes, InitCompletedActionPayload } from './device.actions';
import { ObjectDefinitionDetails } from '../apps/definition-mapping';


export interface DeviceState extends AppState {
    device: DeviceInfoState;
}

export const deviceReducers: ActionReducer<DeviceInfoState> = deviceInfoReducer;

interface DeviceInfoState {
    objectDefintion: ObjectDefinitionDetails;
}

const deviceInfoInitialState: DeviceInfoState = {
    objectDefintion: null
};

function deviceInfoReducer(state = deviceInfoInitialState, action: DeviceInfoActions): DeviceInfoState {
    switch (action.type) {
        case DeviceInfoActionTypes.resetAction:
            return reduceResetAction();
        case DeviceInfoActionTypes.initCompletedAction:
            return reduceInitCompletedAction(state, action.payload);
    }

    return state;
}

function reduceResetAction(): DeviceInfoState {
    return tassign(deviceInfoInitialState);
}

function reduceInitCompletedAction(state: DeviceInfoState, payload: InitCompletedActionPayload): DeviceInfoState {
    return tassign(state, {
        objectDefintion: payload.objectDefinition
      });
}
