import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { State } from '../provision-redux/provision.reducers';
import { Subscription, interval } from 'rxjs';
import { filter, map, take } from 'rxjs/operators';
import { TableDevice } from 'src/app/shared/models/table-device.model';
import { ProvisionService } from '../../../services/provision.service';
import { NotificationsService, NotificationMessage } from 'abb-controls';
import { HttpResponse } from '@angular/common/http';

@Component({
    selector: 'abb-provision-table',
    templateUrl: 'provision-table.component.html',
    styleUrls: ['provision-table.component.scss']
})

export class ProvisionTableComponent implements OnInit, OnDestroy {

    public data: TableDevice[];

    private readonly subscriptions: Subscription[];

    disableButtons: boolean;

    constructor(private store: Store<State>,
                private provisionService: ProvisionService) {
        this.subscriptions = [
            this.store.pipe(
                select(s => s.provision.devices),
                map(d => d ? d.filter(df => this.filterContent(df)) : [])
            ).subscribe(m => this.assignData(m))
        ];
     }

    private filterContent(device: TableDevice): boolean {
        return !device.isProvisioned && device.isProvisionedPending;
    }

    ngOnInit() { }

    ngOnDestroy(): void {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }

    assignData(devices: TableDevice[]) {
        this.data = devices;
    }

    async provision(row: TableDevice) {
        this.disableButtons = true;

        await this.provisionService.updateProvisionStatus(row.objectId, true, true).then(() => {
            this.data = this.data.filter(d => d.objectId !== row.objectId);
            this.disableButtons = false;
        }, error => {
            this.disableButtons = false;
        });
    }
}
