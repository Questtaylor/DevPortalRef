import {Component, OnDestroy} from '@angular/core';
import {LoggingService} from 'ability-api';
import {NotificationsService, NotificationMessage} from 'abb-controls';
import {Subscription} from 'rxjs';
import {environment} from '../../../environments/environment';

@Component({
  selector: 'abb-logging',
  template: ''
})
export class LoggingComponent implements OnDestroy {

  private subscription: Subscription;

  constructor(private loggingService: LoggingService, private notificationsService: NotificationsService) {
    this.subscription = notificationsService.onNotification.subscribe(msg => this.logMessage(msg));
  }

  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  private logMessage(msg: NotificationMessage): void {

    if (!msg || !msg.saveToLogs) {
      return;
    }

    let logLevel: 'trace' | 'debug' | 'info' | 'warn' | 'error' | 'fatal';

    switch (msg.type) {
      case 'log':
        logLevel = 'debug';
        break;

      case 'info':
      case 'success':
        logLevel = 'info';
        break;

      case 'warning':
        logLevel = 'warn';
        break;

      case 'error':
        logLevel = 'error';
        console.error(msg);
        break;
    }

    const loggerName = `reference-ui-${environment.production ? 'prod' : 'dev'}`;

    // do not await
    // this.loggingService.log(loggerName, msg.message, logLevel)
    //   .catch(reason => console.error(`Error during log sending: ${reason}`));
  }
}
