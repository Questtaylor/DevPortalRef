import {Action} from '@ngrx/store';
import { Marker } from '../_models/marker.models';
import { TableDevice } from '../../../shared/models/table-device.model';
import { StatusInfo } from 'src/app/shared/models/device-status.model';

export enum DashboardActionTypes {
    resetAction = '[Dashboard View] Reset',
    initCompletedAction = '[Dashboard View] Init Completed',
    deviceDataReceivedAction = '[Dashboard Service] Device Data Received',
    updateMarkers = '[Dashboard Device List] Update Markers',
    deviceLocationReceivedAction = '[Dashboard Service] Device Location Received',
    deviceStatusReceivedAction = '[Dashboard Service] Device Status Received',
}

/*--------*/
export class ResetAction implements Action {
    readonly type = DashboardActionTypes.resetAction;
}

/*--------*/
export class InitCompletedAction implements Action {
    readonly type = DashboardActionTypes.initCompletedAction;
}

/*--------*/
export interface DeviceDataReceivedActionPayload {
    devices: TableDevice[];
}

export class DeviceDataReceivedAction implements Action {
    readonly type = DashboardActionTypes.deviceDataReceivedAction;

    constructor(public payload: DeviceDataReceivedActionPayload) {
    }
}

/*--------*/
export interface UpdateMarkersActionPayload {
    markers: Marker[];
}

export class UpdateMarkersAction implements Action {
    readonly type = DashboardActionTypes.updateMarkers;

    constructor(public payload: UpdateMarkersActionPayload) {
    }
}

/*--------*/
export interface DeviceLocationReceivedActionPayload {
    locations: {objectId: string, location: string}[];
}

export class DeviceLocationReceivedAction implements Action {
    readonly type = DashboardActionTypes.deviceLocationReceivedAction;

    constructor(public payload: DeviceLocationReceivedActionPayload) {
    }
}

/*--------*/
export interface DeviceStatusReceivedActionPayload {
    statuses: {objectId: string, status: number}[];
}

export class DeviceStatusReceivedAction implements Action {
    readonly type = DashboardActionTypes.deviceStatusReceivedAction;

    constructor(public payload: DeviceStatusReceivedActionPayload) {
    }
}

export type DashboardActions =
  ResetAction
  | InitCompletedAction
  | DeviceDataReceivedAction
  | UpdateMarkersAction
  | DeviceLocationReceivedAction
  | DeviceStatusReceivedAction;
