import { Injectable } from '@angular/core';
import { EventPoint } from '../../_models/event.model';
import { AggregateEvent } from '../_models/aggregateEvent.model';
import { distinct } from 'src/app/shared/functions/distinct.function';

@Injectable()
export class ProximityAggregationService {

    constructor() { }

    public aggregateProximityEvents(events: EventPoint[]): AggregateEvent[] {
        const beacons = distinct(events.map(e => e.source)).map(b => <AggregateEvent>({name: b}));
        beacons.forEach(beacon => {
            const beaconEvents =  events.filter(e => e.source === beacon.name);

            const sorted = beaconEvents.sort((a, b) => {
                if (a < b) {
                    return 1;
                } else if (a > b) {
                    return -1;
                } else {
                    return 0;
                }
            });

            let dwellTime = 0;
            let previousState: 'enter' | 'exit';
            let previousTimestamp: string;
            sorted.forEach(s => {
                if (previousState == null && s.name.toLowerCase().indexOf('in') !== -1) {
                    previousState = 'enter';
                    previousTimestamp = s.timestamp;
                } else if (previousState === 'enter' && s.name.toLowerCase().indexOf('out') !== -1) {
                    // Get 1 minute in milliseconds
                    const one_minute = 1000 * 60;

                    // Convert both dates to milliseconds
                    const date1_ms = new Date(previousTimestamp).getTime();
                    const date2_ms = new Date(s.timestamp).getTime();

                    // Calculate the difference in milliseconds
                    const difference_ms = date2_ms - date1_ms;

                    // Convert back to days and return
                    const time =  difference_ms / one_minute;
                    dwellTime += time;

                    previousState = 'exit';
                    previousTimestamp = null;
                } else if (previousState === 'exit' && s.name.toLowerCase().indexOf('in') !== -1) {
                    previousState = 'enter';
                    previousTimestamp = s.timestamp;
                }
            });

            beacon.totalEvents = beaconEvents.length;
            beacon.dwellTime = Math.round(dwellTime);
        });

        return beacons;
    }
}
