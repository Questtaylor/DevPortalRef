import { Component, OnInit, OnDestroy } from '@angular/core';
import { ObjectsService} from 'ability-api';
import { Subscription, interval } from 'rxjs';
import { startWith } from 'rxjs/operators';
import { DashboardDataLoaderService } from './_services/dashboardDataLoader.service';
import { Device } from 'src/app/shared/models/device.model';
import { AzureMapsApiService } from 'src/app/services/azureMapsApi.service';

@Component({
    selector: 'abb-dashboard',
    templateUrl: 'dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
})

export class DashboardComponent implements OnInit, OnDestroy {

    private subscriptions: Subscription[];

    constructor(private objectsService: ObjectsService,
                private dataLoader: DashboardDataLoaderService,
                private azureMaps: AzureMapsApiService) {
    }

    ngOnInit() {
        const self = this;
        this.subscriptions = [
            interval(30000).pipe(startWith(0)).subscribe(() => {
                self.loadObjects().then(async function(data) {
                    await self.dataLoader.populateDeviceData(data, self.azureMaps);
                });
            })
        ];
    }

    ngOnDestroy(): void {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }

    private async loadObjects(): Promise<Device[]> {
        const result = await this.objectsService.getAllObjects<Device>().toPromise();

        return result.data;
    }
}
