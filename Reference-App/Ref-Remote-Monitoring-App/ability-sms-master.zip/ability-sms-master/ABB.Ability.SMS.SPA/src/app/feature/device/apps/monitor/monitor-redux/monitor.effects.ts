
import { Injectable } from '@angular/core';
import { LiveDataReceivedAction } from './monitor.actions';
import { Observable } from 'rxjs';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { SignalRActionTypes, DeviceTimeSeriesEvent, DeviceEvent, DeviceAlarm } from 'src/app/services/signal-r/signal-r.actions';
import { map, tap } from 'rxjs/operators';
import { DataPoint } from '../_models/monitor.models';
import { TimeSeriesMessageModel, DeviceEventModel } from 'src/app/services/signal-r/models/events-alarms-model';

@Injectable()
export class MonitorLiveDataEffects {

    @Effect()
    mapLiveDeviceData: Observable<LiveDataReceivedAction> = this.actions
        .pipe(
            ofType(SignalRActionTypes.DeviceTimeSeriesAction),
            // tap(_ => console.log(`Mapping time series`)),
            map((action: DeviceTimeSeriesEvent) => action.payload.timeseries),
            map((data: TimeSeriesMessageModel) => new DataPoint(data.variable, data.variable, data.timestamp, data.value, 'timeseries')),
            map(input => new LiveDataReceivedAction({ data: [input] }))
        );

    @Effect()
    mapLiveEventData: Observable<LiveDataReceivedAction> = this.actions
        .pipe(
            ofType(SignalRActionTypes.DeviceEventAction),
            // tap(_ => console.log(`Mapping event`)),
            map((action: DeviceEvent) => action.payload.event),
            map((data: DeviceEventModel) => new DataPoint(data.event, data.event, data.timestamp, data.value, 'event')),
            map(input => new LiveDataReceivedAction({ data: [input] }))
        );

    @Effect()
    mapLiveAlarmData: Observable<LiveDataReceivedAction> = this.actions
        .pipe(
            ofType(SignalRActionTypes.DeviceAlarmAction),
            // tap(_ => console.log(`Mapping alarm`)),
            map((action: DeviceAlarm) => action.payload.alarm),
            map((data: DeviceEventModel) => new DataPoint(data.alarm, data.alarm, data.timestamp, data.value, 'alarm')),
            map(input => new LiveDataReceivedAction({ data: [input] }))
        );
    constructor(private actions: Actions) {
    }

}
