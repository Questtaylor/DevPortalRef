import { Component, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { State } from '../proximity-redux/proximity.reducer';
import { Subscription } from 'rxjs';
import { EventPoint } from '../../_models/event.model';
import { AggregateEvent } from '../_models/aggregateEvent.model';
import { filter } from 'rxjs/operators';
import { ProximityAggregationService } from '../_services/proximity-aggregation.service';
import { BeaconSelectedAction, BeaconSelectedActionPayload } from '../proximity-redux/proximity.actions';

@Component({
    selector: 'abb-proximity-table',
    templateUrl: 'proximity-table.component.html',
    styleUrls: ['proximity-table.component.scss']
})

export class ProximityTableComponent implements OnDestroy {

    public aggregateEvents: AggregateEvent[];
    subscriptions: Subscription[];

    constructor(private store: Store<State>,
                aggregatorService: ProximityAggregationService) {

        const events$ = store.pipe(select(s => s.proximity.events), filter(e => e != null));

        this.subscriptions = [
            events$.subscribe(events => {
                const aggregateData = aggregatorService.aggregateProximityEvents(events);

                this.aggregateEvents = aggregateData;
            })
        ];
    }

    onActivate($event) {
        if ($event.type === 'click') {
            const payload: BeaconSelectedActionPayload = {
                beaconName: $event.row.name
            };
            this.store.dispatch(new BeaconSelectedAction(payload));
        }
    }

     ngOnDestroy(): void {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }
}
