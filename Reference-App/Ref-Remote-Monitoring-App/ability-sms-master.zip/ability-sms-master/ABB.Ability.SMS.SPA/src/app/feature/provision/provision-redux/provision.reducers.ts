import {
    ProvisionActionTypes,
    ProvisionActions,
    DeviceDataReceivedActionPayload
} from './provision.actions';

import {AppState} from 'src/app/redux-core/redux-core';
import {ActionReducer} from '@ngrx/store/src/models';
import {tassign} from 'tassign';
import { TableDevice } from '../../../shared/models/table-device.model';


export interface State extends AppState {
    provision: ProvisionState;
}

export const provisionReducers: ActionReducer<ProvisionState> = provisionReducer;

interface ProvisionState {
    devices: TableDevice[];
}

const provisionInitState: ProvisionState = {
    devices: null
};


function provisionReducer(state = provisionInitState, action: ProvisionActions): ProvisionState {
    switch (action.type) {
        case ProvisionActionTypes.resetAction:
            return reduceResetAction();
        case ProvisionActionTypes.deviceDataReceivedAction:
            return reduceDeviceDataReceivedAction(state, action.payload);
    }

    return state;
}


function reduceResetAction(): ProvisionState {
    return tassign(provisionInitState);
}

function reduceDeviceDataReceivedAction(state: ProvisionState, payload: DeviceDataReceivedActionPayload): ProvisionState {
    return tassign(state, {
        devices: payload.devices
    });
}
