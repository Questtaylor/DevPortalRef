export interface AggregateEvent {
    name: string;
    dwellTime: number;
    totalEvents: number;
}
