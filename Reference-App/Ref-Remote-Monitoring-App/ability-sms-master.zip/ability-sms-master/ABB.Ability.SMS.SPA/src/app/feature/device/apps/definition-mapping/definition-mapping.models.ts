// mapped
export interface TypeDefinitionDetails {
  model: string;
  typeId: string;
  version: string;
  name?: string;
  description?: string;
  tags?: string[];
  unique?: string[];
  isExtensible?: boolean;
  baseTypes?: string[];

  variables: ObjectPropertiesInfo;
  properties: ObjectPropertiesInfo;
  methods: ObjectPropertiesInfo;
}

// mapped
export interface ObjectDefinitionDetails {
  objectId: string;
  name: string;
  description: string;
  model: string;
  type: string;
  version?: string;
  variables: ObjectPropertiesInfo;
  properties: ObjectPropertiesInfo;
  methods: ObjectPropertiesInfo;
}

export interface ObjectPropertiesInfo {
  properties: ObjectProperty[];
}

export interface ObjectProperty {
  name: string;
  values: ObjectPropertyValue[];

  /*
  * To ease debugging */
  raw: any;
}

export interface ObjectPropertyValue {
  name: string;
  value: any;
}

export function findObjectPropertyValue(propertyData: ObjectProperty, internalValueName: string): any {
  if (propertyData && propertyData.values) {
    const internalValue = propertyData.values.find(m => m.name === internalValueName);
    return internalValue ? internalValue.value : null;
  }
  return null;
}

export function getFriendlyNames(object: ObjectDefinitionDetails): {name: string, friendlyName: string}[] {
  return object.variables.properties.map(p => ({name: p.name, friendlyName: getFriendlyName(p.name, p.values)}));
}

export function getMeasurementUnits(object: ObjectDefinitionDetails): {name: string, unit: string}[] {
  return object.variables.properties.map(p => ({name: p.name, unit: getMeasurementUnit(p.values)}));
}

function getFriendlyName(name: string, values: {name: string, value: string}[]): string {
    const friendlyName = values.filter(p => p.name === 'friendlyName');
    if (friendlyName == null || friendlyName.length !== 1) {
      return name;
    }

    return friendlyName[0].value;
}

function getMeasurementUnit(values: {name: string, value: string}[]): string {
  const unit = values.filter(p => p.name === 'unit');
  if (unit == null || unit.length !== 1) {
    return null;
  }

  return unit[0].value;
}
