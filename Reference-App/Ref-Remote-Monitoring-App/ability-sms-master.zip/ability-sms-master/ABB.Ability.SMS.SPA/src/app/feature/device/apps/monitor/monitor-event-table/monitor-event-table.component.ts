import { Component, OnDestroy } from '@angular/core';
import { Subscription} from 'rxjs';
import { Store, select } from '@ngrx/store';
import { State } from '../monitor-redux/monitor.reducer';
import { EventPoint } from '../../_models/event.model';

@Component({
  selector: 'abb-monitor-event-table',
  templateUrl: './monitor-event-table.component.html',
  styleUrls: ['./monitor-event-table.component.scss']
})
export class MonitorEventTableComponent implements OnDestroy {
  public data: EventPoint[];
  private readonly subscriptions: Subscription[];

  constructor(store: Store<State>) {
    this.subscriptions = [
      store.pipe(select(s => s.monitor.eventData)).subscribe(events =>
         this.data = events ? events.filter(e => e.name.toLowerCase().indexOf('range') === -1) : events
         ),
    ];
  }

  public ngOnDestroy(): void {
    if (this.subscriptions) {
      this.subscriptions.forEach(s => s.unsubscribe());
    }
  }
}
