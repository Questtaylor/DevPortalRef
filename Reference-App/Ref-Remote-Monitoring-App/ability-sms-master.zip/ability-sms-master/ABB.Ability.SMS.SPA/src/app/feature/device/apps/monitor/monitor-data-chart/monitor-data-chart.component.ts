import {Component, OnDestroy, NgZone, AfterViewChecked} from '@angular/core';
import {Subscription} from 'rxjs';
import 'chartjs-plugin-streaming';
import {select, Store} from '@ngrx/store';
import {map} from 'rxjs/operators';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import am4themes_animated from '@amcharts/amcharts4/themes/amcharts';

am4core.useTheme(am4themes_animated);

import {DataPoint} from '../_models/monitor.models';
import {State} from '../monitor-redux/monitor.reducer';
import {distinct} from 'src/app/shared/functions/distinct.function';
import { DeviceState } from '../../../device-redux/device.reducers';
import { ObjectPropertiesInfo } from '../../definition-mapping';

@Component({
  selector: 'abb-monitor-data-chart',
  templateUrl: './monitor-data-chart.component.html',
  styleUrls: ['./monitor-data-chart.component.scss']
})
export class MonitorDataChartComponent implements OnDestroy, AfterViewChecked {

  public showChart = false;
  public lineChartColors: Map<number, string> = new Map([
    [0, '#9E842F'],
    [1, '#196D6F'],
    [2, '#553786'],
  ]);

  private readonly subscriptions: Subscription[];

  private chart: am4charts.XYChart;
  private useHistoricalData: boolean;
  private chartData: DataPoint[];

  private variables: ObjectPropertiesInfo;

  constructor(store: Store<State>,
              deviceStore: Store<DeviceState>,
              private zone: NgZone) {

    const isHistoricalData$ = store.pipe(
      select(s => s.monitor.mode),
      map(mode => mode === 'historical')
    );

    const data$ = store.pipe(select(s => s.monitor.variableData));
    const objectVariables$ = deviceStore.pipe(select(s => s.device.objectDefintion.variables));

    this.subscriptions = [
      isHistoricalData$.subscribe(m => this.changeMode(m)),
      data$.subscribe(m => this.dataReceived(m)),
      objectVariables$.subscribe((v) => this.variables = v)
    ];
  }

  ngAfterViewChecked(): void {
      if (this.showChart && !this.chart && document.getElementById('chartdiv')) {
        this.chartInit();
        this.updateChart(this.chartData);
        if (this.useHistoricalData) {
          const scrollbarX = new am4charts.XYChartScrollbar();
          this.chart.series.values.forEach(s => {
            scrollbarX.series.push(s);
          });
          this.chart.scrollbarX = scrollbarX;
          this.chart.scrollbarX.parent = this.chart.bottomAxesContainer;
        }
      }
  }

  public ngOnDestroy(): void {
    if (this.subscriptions) {
      this.subscriptions.forEach(sub => sub.unsubscribe());
    }
    if (this.chart) {
      this.zone.runOutsideAngular(() => {
        this.chart.dispose();
      });
    }
  }

  private chartInit() {
    this.zone.runOutsideAngular(() => {

      const chart = am4core.create('chartdiv', am4charts.XYChart);
      chart.paddingRight = 20;

      const dateAxis = chart.xAxes.push(new am4charts.DateAxis());

      dateAxis.baseInterval = {
        'timeUnit': 'second',
        'count': 1
      };

      dateAxis.markUnitChange = false;
      dateAxis.dateFormats.setKey('hour', 'h a');
      dateAxis.dateFormats.setKey('minute', 'h:mm a');
      dateAxis.dateFormats.setKey('second', 'h:mm:ss a');

      dateAxis.tooltipDateFormat = '[bold]MM-dd-yy, h:mm:ss a[/]';
      dateAxis.renderer.grid.template.location = 0;

      chart.cursor = new am4charts.XYCursor();
      chart.legend = new am4charts.Legend();

      this.chart = chart;
    });
  }

  private changeMode(isHistoricalDataMode: boolean) {
    this.useHistoricalData = isHistoricalDataMode;
    this.showChart = false;
  }

  private dataReceived(data: DataPoint[]) {
    this.chartData = !!data ? data.filter(d => d.type === 'timeseries') : null;
    if (!this.chartData || this.chartData.length === 0) {
      this.showChart = false;
      return;
    }

    this.showChart = true;
    this.updateChart(this.chartData);
  }

  private updateChart(data: DataPoint[]): void {
    if (this.chart) {
      this.zone.runOutsideAngular(() => {
        while (this.chart.series.length > 0) {
          this.chart.series.removeIndex(0).dispose();
        }

        while (this.chart.yAxes.length > 0) {
          this.chart.yAxes.removeIndex(0).dispose();
        }

        const distinctVariables = distinct(data.map(m => m.name))
        .sort((a, b) => {
          if (a < b) {
            return 1;
          } else if (a > b) {
           return -1;
          } else {
            return 0;
          }
        });

        distinctVariables.forEach((name, index) => {
          if (index > this.lineChartColors.size) {
            return;
          }

          const yAxis = this.chart.yAxes.push(new am4charts.ValueAxis());
          const series = this.chart.series.push(new am4charts.LineSeries());

          series.yAxis = yAxis;
          series.numberFormatter.numberFormat = '#.##';
          const filteredByName = data.filter(d => d.name === name);
          if (filteredByName.length >= 1) {
            series.name = filteredByName[0].friendlyName;

          } else {
            series.name = name;
          }
          series.dataFields.dateX = 'date';
          series.dataFields.valueY = 'value';
          series.data = data.filter(d => d.name === name).map( d => {
              return {date: new Date(d.timestamp), value: d.value};
          });

          const filteredProperties = this.variables.properties.filter(p => p.name === name);
          if (filteredProperties.length === 1) {
            filteredProperties[0].values.forEach(v => {
              if (v.name === 'min') {
                (yAxis as am4charts.ValueAxis).strictMinMax = true;
                (yAxis as am4charts.ValueAxis).min = v.value;
              } else if (v.name === 'max') {
                (yAxis as am4charts.ValueAxis).strictMinMax = true;
                (yAxis as am4charts.ValueAxis).max = v.value;
              }
            });
          }
          const lineChartColor = this.lineChartColors.get(index % 3);
          series.stroke = am4core.color(lineChartColor);

          series.tooltip.getFillFromObject = false;
          series.tooltip.background.fill = series.stroke;
          series.tooltipText = '{name}: [bold]{valueY}[/]';

          const opposite = index % 2 === 0;

          yAxis.cursorTooltipEnabled = false;
          yAxis.renderer.line.strokeOpacity = 1;
          yAxis.renderer.line.strokeWidth = 2;
          yAxis.renderer.line.stroke = series.stroke;
          yAxis.renderer.labels.template.fill = series.stroke;
          yAxis.renderer.opposite = opposite;
          yAxis.renderer.grid.template.disabled = true;

          if (!this.useHistoricalData) {
            const bullet = series.bullets.push(new am4charts.CircleBullet());
            bullet.width = 5;
            bullet.height = 5;
            bullet.fill = series.stroke;
          }

        });
        this.chart.validateData();
      });
    }
  }
}
