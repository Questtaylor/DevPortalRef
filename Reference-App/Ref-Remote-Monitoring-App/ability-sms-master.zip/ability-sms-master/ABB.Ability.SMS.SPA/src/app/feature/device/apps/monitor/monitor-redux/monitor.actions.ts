import {Action} from '@ngrx/store';
import { DataPoint, ValueBox, Variable } from '../_models/monitor.models';
import { EventPoint } from '../../_models/event.model';

/*--------*/
export enum MonitorActionTypes {
  resetAction = '[Monitor View] Reset',
  newSearchAction = '[Monitor View] New Search',
  eventDataReceivedAction = '[Monitor Data Loader Service] Event Data Received',
  variableDataReceivedAction = '[Monitor Data Loader Service] Variable Data Received',
  liveDataReceivedAction = '[Monitor Data Loader Service] Live Data Received',
  lastValueDataReceivedAction = '[GA Last State Service] Last Value Data Received',
  lastWkAvgDataReceivedAction = '[Monitor Data Loader Service] Last Wk Avg Data Received',
  availableVariablesReceivedAction = '[Monitor View] Available Variables Received',
  variableAddedAction = '[Monitor View] Variable Added',
  variableRemovedAction = '[Monitor View] Variable Removed',
  lastValueTelemetryReceivedAction = '[Monitor View] Last Value Telemetry Received'
}

/*--------*/
export class ResetAction implements Action {
  readonly type = MonitorActionTypes.resetAction;
}

/*--------*/
export interface NewSearchActionPayload {
  mode: 'live' | 'historical';
}

export class NewSearchAction implements Action {
  readonly type = MonitorActionTypes.newSearchAction;

  constructor(public payload: NewSearchActionPayload) {

  }
}

/*--------*/
export interface EventDataReceivedActionPayload {
  eventData: EventPoint[];
}

export class EventDataReceivedAction implements Action {
  readonly type = MonitorActionTypes.eventDataReceivedAction;

  constructor(public payload: EventDataReceivedActionPayload) {
  }
}

/*--------*/
export interface VariableDataReceivedActionPayload {
  variableData: DataPoint[];
}

export class VariableDataReceivedAction implements Action {
  readonly type = MonitorActionTypes.variableDataReceivedAction;

  constructor(public payload: VariableDataReceivedActionPayload) {

  }
}

/*--------*/
export interface LiveDataReceivedActionPayload {
  data: DataPoint[];
}

export class LiveDataReceivedAction implements Action {
  readonly type = MonitorActionTypes.liveDataReceivedAction;

  constructor(public payload: LiveDataReceivedActionPayload) {
  }
}

/*--------*/
export interface LastValueDataReceivedActionPayload {
  lastValue: ValueBox;
}

export class LastValueDataReceivedAction implements Action {
  readonly type = MonitorActionTypes.lastValueDataReceivedAction;

  constructor(public payload: LastValueDataReceivedActionPayload) {
  }
}

/*--------*/
export interface LastWkAvgDataReceivedActionPayload {
  lastWkAvg: ValueBox;
}

export class LastWkAvgDataReceivedAction implements Action {
  readonly type = MonitorActionTypes.lastWkAvgDataReceivedAction;

  constructor(public payload: LastWkAvgDataReceivedActionPayload) {
  }
}

/*--------*/
export interface AvailableVariablesReceivedActionPayload {
  variables: Variable[];
}

export class AvailableVariablesReceivedAction implements Action {
  readonly type = MonitorActionTypes.availableVariablesReceivedAction;

  constructor(public payload: AvailableVariablesReceivedActionPayload) {
  }
}

/*--------*/
export interface VariableAddedActionPayload {
  variableName: string;
}

export class VariableAddedAction implements Action {
  readonly type = MonitorActionTypes.variableAddedAction;

  constructor(public payload: VariableAddedActionPayload) {
  }
}

/*--------*/
export interface VariableRemovedActionPayload {
  variableName: string;
}

export class VariableRemovedAction implements Action {
  readonly type = MonitorActionTypes.variableRemovedAction;

  constructor(public payload: VariableRemovedActionPayload) {
  }
}

/*--------*/
export interface LastValueTelemetryReceivedPayload {
  variables: Variable[];
}

export class LastValueTelemetryReceivedAction implements Action {
  readonly type = MonitorActionTypes.lastValueTelemetryReceivedAction;

  constructor(public payload: LastValueTelemetryReceivedPayload) {
  }
}

export type MonitorActions =
  ResetAction
  | NewSearchAction
  | EventDataReceivedAction
  | VariableDataReceivedAction
  | LiveDataReceivedAction
  | LastValueDataReceivedAction
  | LastWkAvgDataReceivedAction
  | AvailableVariablesReceivedAction
  | VariableAddedAction
  | VariableRemovedAction
  | LastValueTelemetryReceivedAction;
