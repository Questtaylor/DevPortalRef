import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { State } from './proximity-redux/proximity.reducer';
import { Subscription, interval, Observable } from 'rxjs';
import { startWith, filter } from 'rxjs/operators';
import { ProximityDataLoaderService } from './_services/proximity-data-loader.service';
import { DeviceState } from '../../device-redux/device.reducers';
import { ResetAction } from './proximity-redux/proximity.actions';
import { GetDataRawRequest } from 'ability-api';
import { EventPoint } from '../_models/event.model';
import { MsalService } from 'src/app/services/msal.service';

@Component({
    selector: 'abb-proximity',
    templateUrl: 'proximity.component.html',
    styleUrls: ['proximity.component.scss'],
    providers: [
        ProximityDataLoaderService
    ]
})

export class ProximityComponent implements OnDestroy {

    public events$: Observable<EventPoint[]>;
    private subscriptions: Subscription[];

    canReadEvents: boolean;

    constructor(private store: Store<State>,
                deviceStore: Store<DeviceState>,
                private dataLoaderService: ProximityDataLoaderService,
                private msalService: MsalService) {
        this.events$ = store.pipe(select(s => s.proximity.events));

        this.store.dispatch(new ResetAction());

        this.checkPermissions();

        const deviceObject$ = deviceStore.pipe(
            select(s => s.device.objectDefintion),
            filter(s => s != null)
        );

        this.subscriptions = [];
        this.subscriptions.push(deviceObject$.subscribe(async object => {
            const objectId = object.objectId;
            this.subscriptions.push(interval(10000).pipe(startWith(0)).subscribe(async () => {
                if (this.canReadEvents) {
                    await this.getData(objectId);
                }
            }));
        }));
    }

    checkPermissions() {
        const permissions = this.msalService.getPermissions();
        this.canReadEvents = permissions.indexOf('event_read') !== -1;
    }

    private async getData(objectId: string): Promise<void> {
        const dataType = 'events';
        const tFilter = this.createTelemetryRequestFilter(objectId);
        const to = new Date();
        const from = new Date(to);

        from.setHours(from.getHours() - 24);
        const selectS = {
            properties: 'event,timestamp,eventContent.source'
        };

        const request: GetDataRawRequest = {
            date: {
                from: from.toISOString(),
                to: to.toISOString(),
            },
            requestType: <any> dataType.toLowerCase(),
            filter: tFilter,
            limit: 10000
        };

        request.select = selectS;

        await this.dataLoaderService.loadData(request);
    }

    private createTelemetryRequestFilter(objectId, ) {
        const tFilter = `objectId='${objectId}' AND event HAS 'range'`;
        return tFilter;
      }

    ngOnDestroy(): void {
        if (this.subscriptions) {
            this.subscriptions.forEach(s => s.unsubscribe());
        }
    }
}
