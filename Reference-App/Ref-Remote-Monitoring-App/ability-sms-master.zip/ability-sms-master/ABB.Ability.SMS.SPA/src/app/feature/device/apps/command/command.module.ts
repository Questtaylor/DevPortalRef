import { NgModule } from '@angular/core';

import { CommandComponent } from './command.component';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CommandItemComponent } from './command-item/command-item.component';
import { ReactiveFormsModule } from '@angular/forms';

const routes = [
    {
        path: '',
        component: CommandComponent
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ReactiveFormsModule
    ],
    exports: [],
    declarations: [CommandComponent, CommandItemComponent],
    providers: [],
})
export class CommandModule { }
