import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ObjectDefinitionMapperService } from './object-definition-mapper.service';
import { TypeDefinitionMapperService } from './type-definition-mapper.service';
import { PropertyDefinitionMapperService } from './property-definition-mapper.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [
    ObjectDefinitionMapperService,
    TypeDefinitionMapperService,
    PropertyDefinitionMapperService
  ]
})
export class DefinitionMappingModule { }
