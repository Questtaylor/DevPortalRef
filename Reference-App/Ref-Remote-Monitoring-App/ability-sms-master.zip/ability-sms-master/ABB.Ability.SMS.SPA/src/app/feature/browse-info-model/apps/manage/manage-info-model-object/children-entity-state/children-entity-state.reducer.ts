import {createEntityAdapter, EntityState} from '@ngrx/entity';
import {createFeatureSelector} from '@ngrx/store';
import {ChildrenEntityActions, ChildrenEntityActionTypes} from './children-entity-state.actions';


export const childrenEntityAdapter = createEntityAdapter<any>({
  selectId: (children: any) => children.id,
});

export interface ChildrenEntityState extends EntityState<any> {
}

export const initialState: ChildrenEntityState = childrenEntityAdapter.getInitialState();

export function childrenEntityReducer(
  state: ChildrenEntityState = initialState,
  action: ChildrenEntityActions) {

  switch (action.type) {

    case ChildrenEntityActionTypes.CHILDREN_LOADED:
      // console.log(action.payload.entity);
      return childrenEntityAdapter.addOne(action.payload.entity, state);
    default:
      return state;
  }

}

export const getParentEntityState = createFeatureSelector<ChildrenEntityState>('childrenEntity');

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal,
} = childrenEntityAdapter.getSelectors(getParentEntityState);

