import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {GaLastStateService} from './ga-last-state.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [
    GaLastStateService
  ]
})
export class GaMigrationModule {
}
