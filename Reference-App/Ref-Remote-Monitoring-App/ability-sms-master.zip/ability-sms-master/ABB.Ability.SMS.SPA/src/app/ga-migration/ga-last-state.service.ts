import {Injectable} from '@angular/core';
import {DataService, GetDataAggregatedRequest} from 'ability-api';

export interface LastStateDataItem {
  objectId: string;
  event: string;
  alarm: string;
  variable: string;
  value: any;
  timestamp: string;
}

@Injectable()
export class GaLastStateService {

  constructor(private dataService: DataService) {
  }

  public async getLastStateForObjects(objectIds: string[], variable: string): Promise<LastStateDataItem[]> {
    const from = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
    const tasks = objectIds.map(async o => {
      const request: GetDataAggregatedRequest = {
        date: {from: from.toISOString()},
        filter: `objectId='${o}' and variable='${variable}'`,
        limit: 1,
        orderBy: {property: 'timestamp', order: 'desc'},
        requestType: 'variables',
        select: {last: 'value,timestamp'}
      };

      const task = this.dataService.getDataAggregated<{ last: any, timestamp: string }>(request).toPromise().then(response => ({
        response,
        objectId: o
      }));
      return task;
    });
    const responses = await Promise.all(tasks);
    const data: LastStateDataItem[] = responses.map(m => ({
      objectId: m.objectId,
      value: m.response.data[0].last.value,
      variable,
      event: null,
      alarm: null,
      timestamp: m.response.data[0].last.timestamp
    }));

    return data;
  }

  public async getLastStateForObject(objectId: string, variables: string[]): Promise<LastStateDataItem[]> {
    const from = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
    const tasks = variables.map(async v => {
      const request: GetDataAggregatedRequest = {
        date: {from: from.toISOString()},
        filter: `objectId='${objectId}' and variable='${v}'`,
        limit: 1,
        orderBy: {property: 'timestamp', order: 'desc'},
        requestType: 'variables',
        select: {last: 'value,timestamp'}
      };

      const task = this.dataService.getDataAggregated<{ last: any, timestamp: string }>(request).toPromise().then(response => ({
        response,
        variable: v
      }));
      return task;
    });
    const responses = await Promise.all(tasks);
    const data: LastStateDataItem[] = responses.map(m => ({
      objectId,
      value: m.response.data[0].last.value,
      variable: m.variable,
      event: null,
      alarm: null,
      timestamp: m.response.data[0].last.timestamp
    }));

    return data;
  }
}
