import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { AuthguardService } from './services/authguard.service';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'dashboard'
  },
  {
    path: 'dashboard',
    canActivate: [AuthguardService],
    loadChildren: './feature/dashboard/dashboard.module#DashboardModule'
  },
  {
    path: 'device',
    canActivate: [AuthguardService],
    loadChildren: './feature/device/device.module#DeviceModule',
  },
  {
    path: 'provision',
    canActivate: [AuthguardService],
    loadChildren: './feature/provision/provision.module#ProvisionModule'
  },
  {
      path: 'analytics',
      canActivate: [AuthguardService],
      loadChildren: './feature/analytics/analytics.module#AnalyticsModule'
  },
  {
    path: '**',
    pathMatch: 'full',
    redirectTo: 'dashboard'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    // preload all modules
    // preloadingStrategy: PreloadAllModules,
    enableTracing: false
    // useHash: true
  })],
  providers: [AuthguardService],
  exports: [RouterModule]
})
export class AppRoutingModule { }
