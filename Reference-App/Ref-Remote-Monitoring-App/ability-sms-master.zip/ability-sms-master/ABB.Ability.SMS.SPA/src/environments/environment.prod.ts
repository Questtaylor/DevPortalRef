// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  verbose: true,
  showFakeDevices: true,
  referenceUiApi: 'https://abismsmtapieundev.azurewebsites.net',
  azureMapsKey: 'L8U31Mcxah7Ep8DKdEcRjLoFYcUTx1XOkzU9IHuuTkg',
  provisionUrl: 'https://abismsmtprovproceuwdev.azurewebsites.net/api/deviceids',
  telemetryHubName: 'teleHub',
  apiUrl: 'https://abiapiapmmt01euwdev.azure-api.net/v1',
  msal: {
    tenant: 'abilityplatform',
    clientID: '8d7e9f7c-d528-42b9-a4e0-e2a360eb7469',
    policyPrefix: 'B2C_1A_',
    policySuffix: '_RP',
    solutionNamespace: 'sms',
    redirectUri: 'https://abilitymtpocsmsui.azurewebsites.net',
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
