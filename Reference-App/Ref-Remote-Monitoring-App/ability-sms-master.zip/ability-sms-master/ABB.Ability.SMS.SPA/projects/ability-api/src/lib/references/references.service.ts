import {Inject, Injectable} from '@angular/core';
import {InfoModelApiBaseUrl} from '../urlTokens';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {throwApiClientError} from '../common';
import {CreateReferenceRequest, CreateReferenceResponse, GetReferenceRequest, GetReferenceResponse, GetReferencesOfObjectRequest} from './references.models';

@Injectable()
export class ReferencesService {

  constructor(@Inject(InfoModelApiBaseUrl) private baseUrl: string, private http: HttpClient) {
  }

  public getReferencesOfObject(request: GetReferencesOfObjectRequest): Observable<GetReferenceResponse[]> {
    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.objectId) {
      return throwApiClientError('objectId required');
    }

    if (!request.modelId) {
      return throwApiClientError('modelId required');
    }

    const apiUrl = `${this.baseUrl}/objects/${request.objectId}/models/${request.modelId}/references`;

    return this.http.get<GetReferenceResponse[]>(apiUrl);
  }

  public getReferencesById(request: GetReferenceRequest): Observable<GetReferenceResponse> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.referenceId) {
      return throwApiClientError('referenceId required');
    }

    const apiUrl = `${this.baseUrl}/references/${request.referenceId}`;

    return this.http.get<GetReferenceResponse>(apiUrl);
  }

  public createReference(request: CreateReferenceRequest): Observable<CreateReferenceResponse[]> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.parentObjectId) {
      return throwApiClientError('parentObjectId required');
    }

    if (!request.parentModelId) {
      return throwApiClientError('parentModelId required');
    }

    if (!request.reference) {
      return throwApiClientError('reference required');
    }

    if (!request.reference.name) {
      return throwApiClientError('reference.name required');
    }

    if (!request.reference.to) {
      return throwApiClientError('reference.to required');
    }

    if (!request.reference.to.model) {
      return throwApiClientError('reference.to.model required');
    }

    if (!request.reference.to.objectId) {
      return throwApiClientError('reference.to.objectId required');
    }

    const apiUrl = `${this.baseUrl}/Objects/${request.parentObjectId}/models/${request.parentModelId}/references/out`;
    const payload = [request.reference]; //array intentional
    return this.http.post<CreateReferenceResponse[]>(apiUrl, payload);

  }

}
