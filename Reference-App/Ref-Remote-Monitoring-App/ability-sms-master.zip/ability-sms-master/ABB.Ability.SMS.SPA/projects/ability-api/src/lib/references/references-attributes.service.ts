import {Inject, Injectable} from '@angular/core';
import {InfoModelApiBaseUrl} from '../urlTokens';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {throwApiClientError} from '../common';
import {
  SetReferenceAttributeRequest,
  GetReferenceRequest,
  GetReferenceResponse,
  SetReferenceAttributesRequest,
  GetReferenceAttributeRequest,
  GetReferenceAttributeResponse,
  GetReferenceAttributesRequest, DeleteReferenceAttributeRequest
} from './references.models';

@Injectable()
export class ReferencesAttributesService {

  constructor(@Inject(InfoModelApiBaseUrl) private baseUrl: string, private http: HttpClient) {
  }

  public getReferenceAttributes<T>(request: GetReferenceAttributesRequest): Observable<T> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.referenceId) {
      return throwApiClientError('referenceId required');
    }

    const apiUrl = `${this.baseUrl}/references/${request.referenceId}/attributes`;

    return this.http.get<T>(apiUrl);
  }

  public getReferenceAttribute(request: GetReferenceAttributeRequest): Observable<GetReferenceAttributeResponse> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.referenceId) {
      return throwApiClientError('referenceId required');
    }

    if (!request.attributeName) {
      return throwApiClientError('attributeName required');
    }

    const apiUrl = `${this.baseUrl}/references/${request.referenceId}/attributes/${request.attributeName}`;
    return this.http.get<GetReferenceAttributeResponse>(apiUrl);
  }

  public deleteReferenceAttribute(request: DeleteReferenceAttributeRequest): Observable<void> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.referenceId) {
      return throwApiClientError('referenceId required');
    }

    if (!request.attributeName) {
      return throwApiClientError('attributeName required');
    }

    const apiUrl = `${this.baseUrl}/references/${request.referenceId}/attributes/${request.attributeName}`;
    return this.http.delete(apiUrl);
  }

  public setReferenceAttribute(request: SetReferenceAttributeRequest): Observable<void> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.referenceId) {
      return throwApiClientError('referenceId required');
    }

    if (!request.attributeName) {
      return throwApiClientError('attributeName required');
    }

    if (!request.attributeValue) {
      return throwApiClientError('attributeValue required');
    }

    const apiUrl = `${this.baseUrl}/references/${request.referenceId}/attributes/${request.attributeName}`;
    const payload = {value: request.attributeValue};
    return this.http.put<void>(apiUrl, payload);
  }

  public setReferenceAttributes(request: SetReferenceAttributesRequest): Observable<void> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.referenceId) {
      return throwApiClientError('referenceId required');
    }

    if (!request.attributes) {
      return throwApiClientError('attributes required');
    }

    const apiUrl = `${this.baseUrl}/references/${request.referenceId}/attributes`;
    const payload = request.attributes;
    return this.http.put<void>(apiUrl, payload);
  }
}
