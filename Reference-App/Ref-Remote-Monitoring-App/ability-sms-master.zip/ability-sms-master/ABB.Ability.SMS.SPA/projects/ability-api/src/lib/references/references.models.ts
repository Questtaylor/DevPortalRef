export interface GetReferenceRequest {
  referenceId: string;
}

export interface GetReferenceResponse {
  referenceId: string;
  name: string;
  from: {
    objectId: string;
    model: string;
  };
  to: {
    objectId: string;
    model: string;
  };
  attributes: {};
}

export interface CreateReferenceRequest {
  parentObjectId: string;
  parentModelId: string;
  reference: {
    name: string;
    to: {
      model: string;
      objectId: string;
    };
  };
}

export interface CreateReferenceResponse {
  referenceId: string;
}

export interface GetReferencesOfObjectRequest {
  objectId: string;
  modelId: string;
}

/*----------*/
export interface GetReferenceAttributesRequest {
  referenceId: string;
}

export interface SetReferenceAttributeRequest {
  referenceId: string;
  attributeName: string;
  attributeValue: any;
}

export interface SetReferenceAttributesRequest {
  referenceId: string;
  attributes: {
    [key: string]: string;
  };
}

export interface GetReferenceAttributeRequest {
  referenceId: string;
  attributeName: string;
}

export interface GetReferenceAttributeResponse {
  value: any;
}

export interface DeleteReferenceAttributeRequest {
  referenceId: string;
  attributeName: string;
}
