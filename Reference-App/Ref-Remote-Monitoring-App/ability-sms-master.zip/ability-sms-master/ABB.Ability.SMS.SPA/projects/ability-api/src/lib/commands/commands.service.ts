import {Inject, Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {DataAccessApiBaseUrl} from '../urlTokens';
import {CallMethodRequest} from './commands.models';
import {throwApiClientError} from '../common';

@Injectable()
export class CommandsService {

  constructor(@Inject(DataAccessApiBaseUrl) private baseUrl: string, private http: HttpClient) {
  }

  public callMethod(request: CallMethodRequest): Observable<void> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.objectId) {
      return throwApiClientError('objectId required');
    }

    if (!request.modelId) {
      return throwApiClientError('modelId required');
    }

    if (!request.methodName) {
      return throwApiClientError('methodName required');
    }

    const apiUrl = `${this.baseUrl}/Objects/${request.objectId}/models/${request.modelId}/methods/${request.methodName}`;

    return this.http.post<void>(apiUrl, request.payload || {});
  }

}
