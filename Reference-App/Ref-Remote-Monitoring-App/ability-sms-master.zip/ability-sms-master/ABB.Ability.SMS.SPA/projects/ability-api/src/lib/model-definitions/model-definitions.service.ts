import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {TypeDefinitionApiBaseUrl} from '../urlTokens';
import {GetModelDefinitionDetailsRequest, GetModelDefinitionsRequest, ModelDefinition} from './model-definitions.models';
import {throwApiClientError} from '../common';
import {map} from 'rxjs/operators';

@Injectable()
export class ModelDefinitionsService {

  constructor(@Inject(TypeDefinitionApiBaseUrl) private baseUrl: string, private http: HttpClient) {
  }

  public getModelDefinitions(request: GetModelDefinitionsRequest): Observable<ModelDefinition[]> {
    if (!request) {
      return throwApiClientError('request required');
    }

    const limit = request.limit || 100;

    const apiUrl = `${this.baseUrl}/ModelDefinitions?limit=${limit}`;
    return this.http.get<{ data: ModelDefinition[] }>(apiUrl).pipe(map(m => m.data));
  }

  public insertNewModelDefinition(request: ModelDefinition): Observable<ModelDefinition> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.modelId) {
      return throwApiClientError('modelId required');
    }

    if (!request.components) {
      return throwApiClientError('components property required');
    }

    const apiUrl = `${this.baseUrl}/ModelDefinitions`;
    return this.http.post<ModelDefinition>(apiUrl, request);
  }

  /**
   * Gets single model definition schema based on model definition id.
   */
  public getModelDefinitionByModelId(request: GetModelDefinitionDetailsRequest): Observable<any> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.modelId) {
      return throwApiClientError('modelId required');
    }

    let apiUrl = `${this.baseUrl}/ModelDefinitions/${request.modelId}`;
    if (!!request.includeDeleted) {
      apiUrl += '?includeDeleted=true';
    }
    return this.http.get<any>(apiUrl);
  }

}
