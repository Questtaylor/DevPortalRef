/* Details at:
* https://abilityplatform.visualstudio.com/Ability%20Platform/_wiki/wikis/Ability%20Platform.wiki?wikiVersion=GBwikiMaster&pagePath=%2FGetting%20Started%2FDevelopment%2FAPI%2FData%20Access%20V1%20Api%2FWarm%20Data
* */

// sample date: "2018-01-01T09:00:00.000Z"


export interface GetDataRawRequest {
  /*required by our API client*/
  requestType: 'variables' | 'events' | 'alarms';
  date: {
    from: string;
    to?: string
  };
  filter?: string;
  select?: {
    /*Comma separated list, e.g. "properties": "objectId,model"*/
    properties?: string
  };
  orderBy?: {
    property: string;
    order: 'asc' | 'desc'
  };
  limit?: number;
}

export const GetDataAggregatedRequestSelectProperties = ['count', 'min', 'max', 'avg', 'sum', 'first', 'last'];

export interface GetDataAggregatedRequest {
  requestType: 'variables' | 'events' | 'alarms';
  date: {
    from: string;
    to?: string
  };
  filter?: string;
  select: {
    count?: string;
    min?: string;
    max?: string;
    avg?: string;
    sum?: string;
    first?: string;
    last?: string;
  };
  groupBy?: {
    time?: string;
    properties?: string
  };
  orderBy?: {
    property: string;
    order: 'asc' | 'desc'
  };
  limit?: number;
}

export interface GetDataResponseItem {
  objectId?: string;
  model?: string;
  timestamp?: Date;
  value?: any;

  alarm?: string;
  event?: string;
  variable?: string;
  quality?: number;

  count?: {count: string};
  min?: {value: string};
  max?: {value: string};
  avg?: {value: string};
  sum?: {value: string};
  first?: {value: string};
  last?: {value: string};
}

export interface GetDataResponse<T extends GetDataResponseItem> {
  data: T[];
}
