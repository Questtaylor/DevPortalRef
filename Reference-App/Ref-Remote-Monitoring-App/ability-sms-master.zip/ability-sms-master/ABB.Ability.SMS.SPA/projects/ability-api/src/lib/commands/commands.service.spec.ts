import {TestBed} from '@angular/core/testing';
import {CommandsService} from './commands.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {DataAccessApiBaseUrl} from '../urlTokens';
import {CallMethodRequest} from './commands.models';
import {
  assertServiceCreation,
  assertExecutionWithIncompleteInput,
  assertExecutionWithCompleteInput
} from '../common.spec';

describe('CommandsService', () => {

  const baseUrl = 'http://testMethod.com';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: DataAccessApiBaseUrl,
          useValue: baseUrl
        },
        CommandsService
      ]
    });
  });

  it('should be created', () => {
    assertServiceCreation<CommandsService>(CommandsService);
  });

  describe('callMethod', () => {

    it('should call method with explicit payload', (done: DoneFn) => {
      const input: CallMethodRequest = {
        modelId: 'dummy',
        objectId: 'asd',
        methodName: 'asdasd',
        payload: {callbackUrl: 'asdasd', timeout: 123}
      };

      assertCallingMethodWithCompleteInput(input, done, input.payload);
    });

    it('should call method with default payload', (done: DoneFn) => {
      const input: CallMethodRequest = {modelId: 'dummy', objectId: 'asd', methodName: 'asdasd'};

      assertCallingMethodWithCompleteInput(input, done, {});
    });

    it('should fail on empty request', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: CallMethodRequest = undefined;

      assertCallingMethodWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty modelId', (done: DoneFn) => {
      const expectedError = 'modelId required';
      const input: CallMethodRequest = {modelId: undefined, objectId: 'asd', methodName: 'asdasd'};

      assertCallingMethodWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty objectId', (done: DoneFn) => {
      const expectedError = 'objectId required';
      const input: CallMethodRequest = {modelId: 'dummy', objectId: undefined, methodName: 'asdasd'};

      assertCallingMethodWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty methodName', (done: DoneFn) => {
      const expectedError = 'methodName required';
      const input: CallMethodRequest = {modelId: 'dummy', objectId: 'asd', methodName: undefined};

      assertCallingMethodWithIncompleteInput(input, expectedError, done);
    });

    function assertCallingMethodWithCompleteInput(input: CallMethodRequest, done: DoneFn, expectedPayload: any) {
      assertExecutionWithCompleteInput<CommandsService>(
        CommandsService,
        (service) => service.callMethod(input),
        {},
        done,
        `${baseUrl}/Objects/${input.objectId}/models/${input.modelId}/methods/${input.methodName}`,
        'POST',
        expectedPayload
      );
    }

    function assertCallingMethodWithIncompleteInput(input: CallMethodRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<CommandsService>(CommandsService, (service) => service.callMethod(input), expectedError, done);
    }
  });

});
