import {TestBed} from '@angular/core/testing';

import {TypeDefinitionsService} from './type-definitions.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {
  GetLastTypeDefinitionRequest,
  AddNewTypeDefinitionRequest,
  GetTypeDefinitionsBasedOnModelIdTypeIdVersionRequest,
  GetVersionsRequest
} from './type-definitions.models';
import {TypeDefinitionApiBaseUrl} from '../urlTokens';
import {
  assertExecutionWithCompleteInput,
  assertExecutionWithIncompleteInput,
  assertServiceCreation
} from '../common.spec';

describe('TypeDefinitionsService', () => {

  const baseUrl = 'http://testMethod.com';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        TypeDefinitionsService,
        {
          provide: TypeDefinitionApiBaseUrl,
          useValue: 'http://testMethod.com'
        }
      ]
    });
  });

  it('should be created', () => {
    assertServiceCreation<TypeDefinitionsService>(TypeDefinitionsService);
  });

  describe('getVersions', () => {

    it('should get versions', async (done: DoneFn) => {
      const input: GetVersionsRequest = {
        typeId: 'abb.ability.cst.device.demorobot',
        modelId: 'abb.ability.device'
      };

      const mockResponseBody = {
        'dummy': 123
      };

      assertExecutionWithCompleteInput<TypeDefinitionsService>(
        TypeDefinitionsService,
        (service) => service.getVersions(input),
        mockResponseBody,
        done,
        `${baseUrl}/ModelDefinitions/${input.modelId}/types/${input.typeId}/versions`,
        'GET',
        undefined
      );
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input = undefined;

      assertGettingVersionWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no model', (done: DoneFn) => {
      const input: GetVersionsRequest = {
        modelId: undefined,
        typeId: 'abb.ability.cst.device.demorobot'
      };

      assertGettingVersionWithIncompleteInput(input, 'modelId required', done);
    });

    it('should fail on no type', (done: DoneFn) => {
      const input: GetVersionsRequest = {
        modelId: 'abb.ability.device',
        typeId: undefined
      };

      assertGettingVersionWithIncompleteInput(input, 'typeId required', done);
    });

    function assertGettingVersionWithIncompleteInput(input: GetVersionsRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<TypeDefinitionsService>(TypeDefinitionsService, (service) => service.getVersions(input), expectedError, done);
    }

  });

  describe('getTypeDefinitionsBasedOnModelIdTypeIdVersion', () => {

    it('should get version', async (done: DoneFn) => {
      const input: GetTypeDefinitionsBasedOnModelIdTypeIdVersionRequest = {
        typeId: 'abb.ability.cst.device.demorobot',
        modelId: 'abb.ability.device',
        version: '1.0.0'
      };

      const mockResponseBody = {
        'dummy': 123
      };

      assertExecutionWithCompleteInput<TypeDefinitionsService>(
        TypeDefinitionsService,
        (service) => service.getTypeDefinitionsBasedOnModelIdTypeIdVersion(input),
        mockResponseBody,
        done,
        `${baseUrl}/ModelDefinitions${input.modelId}/types/${input.typeId}/versions/${input.version}`,
        'GET',
        undefined
      );
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input = undefined;

      assertGettingTypeVersionWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no model', (done: DoneFn) => {
      const input: GetTypeDefinitionsBasedOnModelIdTypeIdVersionRequest = {
        modelId: undefined,
        typeId: 'abb.ability.cst.device.demorobot',
        version: '1.0.0'
      };

      assertGettingTypeVersionWithIncompleteInput(input, 'modelId required', done);
    });

    it('should fail on no type', (done: DoneFn) => {
      const input: GetTypeDefinitionsBasedOnModelIdTypeIdVersionRequest = {
        modelId: 'abb.ability.device',
        typeId: undefined,
        version: '1.0.0'
      };

      assertGettingTypeVersionWithIncompleteInput(input, 'typeId required', done);
    });

    it('should fail on no version', (done: DoneFn) => {
      const input: GetTypeDefinitionsBasedOnModelIdTypeIdVersionRequest = {
        modelId: 'abb.ability.device',
        typeId: 'abb.ability.cst.device.demorobot',
        version: undefined
      };

      assertGettingTypeVersionWithIncompleteInput(input, 'version required', done);
    });

    function assertGettingTypeVersionWithIncompleteInput(input: GetTypeDefinitionsBasedOnModelIdTypeIdVersionRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<TypeDefinitionsService>(TypeDefinitionsService, (service) => service.getTypeDefinitionsBasedOnModelIdTypeIdVersion(input), expectedError, done);
    }

  });

  describe('addNewTypeDefinition', () => {

    it('should add new type', async (done: DoneFn) => {
      const input: AddNewTypeDefinitionRequest = {
        modelId: 'abb.ability.device',
        typeDefinition: {
          'model': 'abb.ability.device',
          'typeId': 'abb.custom.test',
          'version': '1.0.0',
          'properties': {'hubName': {'dataType': 'string'}, 'deviceId': {'dataType': 'string'}}
        }
      };

      const mockResponseBody = {dummy: 120987};

      assertExecutionWithCompleteInput<TypeDefinitionsService>(
        TypeDefinitionsService,
        (service) => service.addNewTypeDefinition(input),
        mockResponseBody,
        done,
        `${baseUrl}/ModelDefinitions/${input.modelId}/types`,
        'POST',
        input.typeDefinition
      );
    });

    it('should fail on no request', (done: DoneFn) => {
      assertAddingNewTypeDefinitionWithIncompleteInput(undefined, 'request required', done);
    });

    it('should fail on no modelId', (done: DoneFn) => {
      const addNewTypeDefinitionRequest: AddNewTypeDefinitionRequest = {
        modelId: undefined,
        typeDefinition: {model: 'a', typeId: 'qwe', version: '123'}
      };

      assertAddingNewTypeDefinitionWithIncompleteInput(addNewTypeDefinitionRequest, 'modelId required', done);
    });

    it('should fail on no typeDefinition', (done: DoneFn) => {
      const addNewTypeDefinitionRequest: AddNewTypeDefinitionRequest = {
        modelId: 'abb.ability.device',
        typeDefinition: undefined
      };

      assertAddingNewTypeDefinitionWithIncompleteInput(addNewTypeDefinitionRequest, 'typeDefinition required', done);
    });

    function assertAddingNewTypeDefinitionWithIncompleteInput(input: AddNewTypeDefinitionRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<TypeDefinitionsService>(TypeDefinitionsService, (service) => service.addNewTypeDefinition(input), expectedError, done);
    }

  });

  describe('getLastTypeDefinition', () => {

    it('should return last type definition', async (done: DoneFn) => {
      const input: GetLastTypeDefinitionRequest = {
        modelId: 'abb.ability.device',
        typeId: 'type'
      };

      const mockResponseBody = {dummy: 29374};

      assertExecutionWithCompleteInput<TypeDefinitionsService>(
        TypeDefinitionsService,
        (service) => service.getLastTypeDefinition(input),
        mockResponseBody,
        done,
        `${baseUrl}/ModelDefinitions/${input.modelId}/types/${input.typeId}`,
        'GET',
        undefined
      );
    });

    it('should fail on no request', (done: DoneFn) => {
      assertGettingLastTypeDefinitionWithIncompleteInput(undefined, 'request required', done);
    });

    it('should fail on no modelId', (done: DoneFn) => {
      const request: GetLastTypeDefinitionRequest = {
        modelId: undefined,
        typeId: 'type'
      };

      assertGettingLastTypeDefinitionWithIncompleteInput(request, 'modelId required', done);
    });

    it('should fail on no typeId', (done: DoneFn) => {
      const request: GetLastTypeDefinitionRequest = {
        modelId: 'abb.ability.device',
        typeId: undefined
      };

      assertGettingLastTypeDefinitionWithIncompleteInput(request, 'typeId required', done);
    });

    function assertGettingLastTypeDefinitionWithIncompleteInput(input: GetLastTypeDefinitionRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<TypeDefinitionsService>(TypeDefinitionsService, (service) => service.getLastTypeDefinition(input), expectedError, done);
    }
  });

});
