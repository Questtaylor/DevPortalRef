import {Inject, Injectable} from '@angular/core';
import {DataAccessApiBaseUrl} from '../urlTokens';
import {throwApiClientError} from '../common';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {GetDataRawRequest, GetDataAggregatedRequest, GetDataResponse, GetDataAggregatedRequestSelectProperties } from './data.models';

@Injectable()
export class DataService {

  constructor(@Inject(DataAccessApiBaseUrl) private baseUrl: string, private http: HttpClient) {
  }

  public getDataRaw<T>(request: GetDataRawRequest): Observable<GetDataResponse<T>> {
    const commonError = this.validateCommonRequestProperties(request);
    if (!!commonError) {
      return commonError;
    }

    const payload = this.createPayload(request);

    return this.http.post<GetDataResponse<T>>(`${this.baseUrl}/data/${request.requestType}`, payload);
  }

  public getDataAggregated<T>(request: GetDataAggregatedRequest): Observable<GetDataResponse<T>> {
    const commonError = this.validateCommonRequestProperties(request);
    if (!!commonError) {
      return commonError;
    }

    if (!request.select) {
      return throwApiClientError('select required');
    }

    const selectObjectContainsAtLeastOneProperProperty = !!GetDataAggregatedRequestSelectProperties.map(p => request.select[p]).filter(m => !!m).length;
    if (!selectObjectContainsAtLeastOneProperProperty) {
      return throwApiClientError(`select object has to define at least one property: ${GetDataAggregatedRequestSelectProperties.join(', ')}`);
    }

    const payload = this.createPayload(request);

    return this.http.post<GetDataResponse<T>>(`${this.baseUrl}/data/${request.requestType}`, payload);
  }

  private createPayload(request: GetDataRawRequest | GetDataAggregatedRequest): GetDataRawRequest | GetDataAggregatedRequest {
    const payload = Object.assign({}, request);
    payload.requestType = undefined;
    return payload;
  }

  private validateCommonRequestProperties(request: GetDataRawRequest | GetDataAggregatedRequest): Observable<never> | undefined {
    if (!request) {
      return throwApiClientError('request required');
    }
    // required by API client - not API itself
    if (!request.requestType) {
      return throwApiClientError('requestType required');
    }
    if (!request.date) {
      return throwApiClientError('date required');
    }
    if (!request.date.from) {
      return throwApiClientError('date.from required');
    }

    if (!!request.orderBy && !request.orderBy.order) {
      return throwApiClientError('if request.orderBy is provided, then request.orderBy.order required');
    }
    if (!!request.orderBy && !request.orderBy.property) {
      return throwApiClientError('if request.orderBy is provided, then request.orderBy.property required');
    }

    return undefined;
  }
}
