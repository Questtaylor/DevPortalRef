import {TestBed, inject} from '@angular/core/testing';

import {LoggingService} from './logging.service';
import {HttpClient} from '@angular/common/http';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {ReferenceUiApiBaseUrl} from '../urlTokens';

describe('LoggingService', () => {

  const baseUrl = 'My funky base URL';
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        {
          provide: ReferenceUiApiBaseUrl,
          useValue: baseUrl
        },
        HttpClient,
        LoggingService
      ]
    });
  });

  it('should be created', inject([LoggingService], async (service: LoggingService) => {
    await expect(service).toBeTruthy();
  }));

  it('should send log request to server', async (done: DoneFn) => {
    await inject([LoggingService, HttpTestingController], async (service: LoggingService, httpMock: HttpTestingController) => {

      const logLevel = 'warn';
      const logEvent = 'asd81729sdjhscda';
      const logMsg = 'Hello log';
      const expectedUrl = `${baseUrl}/api/logs/add/reference-ui/${logLevel}/${logEvent}`;

      await assertLogSending('reference-ui', logMsg, logLevel, logEvent, done, expectedUrl, service, httpMock, logMsg);
    })();
  });

  it('should send log request to server with default log message, level and event', async (done: DoneFn) => {
    await inject([LoggingService, HttpTestingController], async (service: LoggingService, httpMock: HttpTestingController) => {
      const logMsg = 'Hello log';
      const expectedUrl = `${baseUrl}/api/logs/add/reference-ui/debug/no-event`;

      await assertLogSending('reference-ui', undefined, undefined, undefined, done, expectedUrl, service, httpMock, 'No log message provided');
    })();
  });

  it('should send log request to server with default log level and event', async (done: DoneFn) => {
    await inject([LoggingService, HttpTestingController], async (service: LoggingService, httpMock: HttpTestingController) => {
      const logMsg = 'Hello log';
      const expectedUrl = `${baseUrl}/api/logs/add/reference-ui/debug/no-event`;

      await assertLogSending('reference-ui', logMsg, undefined, undefined, done, expectedUrl, service, httpMock, logMsg);
    })();
  });

  async function assertLogSending(loggerName: string,
                                  logMsg: string,
                                  logLevel: 'trace' | 'debug' | 'info' | 'warn' | 'error' | 'fatal',
                                  logEvent: string,
                                  done: DoneFn,
                                  expectedUrl: string,
                                  service: LoggingService,
                                  httpMock: HttpTestingController,
                                  expectedMessage: string) {

    service.log(loggerName, logMsg, logLevel, logEvent)
      .then(() => done())
      .catch((e) => {
        expect(false).toEqual(true, e);
      });

    const request = httpMock.expectOne(expectedUrl);

    await expect(request.request.method).toBe('POST');
    await expect(request.request.headers.get('Content-Type')).toBe('text/plain; charset=utf-8');
    await expect(request.request.body).toBe(expectedMessage);

    const mockOkResponse200 = {
      status: 200, statusText: 'Method called'
    };

    request.flush({}, mockOkResponse200);
  }

});
