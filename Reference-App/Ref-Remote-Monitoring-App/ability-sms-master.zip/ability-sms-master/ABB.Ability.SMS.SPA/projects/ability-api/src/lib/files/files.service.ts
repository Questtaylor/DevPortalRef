import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {
  DeleteFileRequest,
  DownloadFileRequest,
  DownloadFileResponse,
  SearchFilesRequest,
  SearchFilesResponse,
  UploadFileRequest
} from './files.models';
import {DataAccessApiBaseUrl} from '../urlTokens';
import {throwApiClientError} from '../common';


@Injectable()
export class FilesService {

  constructor(@Inject(DataAccessApiBaseUrl) private baseUrl: string, private http: HttpClient) {
  }

  public searchFiles(request: SearchFilesRequest): Observable<SearchFilesResponse> {
    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.filter) {
      return throwApiClientError('filter required');
    }

    const encodedFilter = encodeURIComponent(request.filter);
    let apiUrl = `${this.baseUrl}/storage/object/files/search?filter=${encodedFilter}`;
    if (!!request.limit) {
      apiUrl += `&limit=${request.limit}`;
    }

    return this.http.get<SearchFilesResponse>(apiUrl);
  }

  public downloadFile(request: DownloadFileRequest): Observable<Blob> {
    if (!request) {
      return throwApiClientError('request required');
    }
    if (!request.path) {
      return throwApiClientError('path required');
    }
    if (!request.model) {
      return throwApiClientError('model required');
    }
    if (!request.objectId) {
      return throwApiClientError('objectId required');
    }

    return this.http.post<Blob>(`${this.baseUrl}/storage/object/files/download`, request, {responseType: 'blob' as 'json'});
  }

  public deleteFile(request: DeleteFileRequest): Observable<void> {
    if (!request) {
      return throwApiClientError('request required');
    }
    if (!request.path) {
      return throwApiClientError('path required');
    }
    if (!request.model) {
      return throwApiClientError('model required');
    }
    if (!request.objectId) {
      return throwApiClientError('objectId required');
    }

    return this.http.post<void>(`${this.baseUrl}/storage/object/files/delete`, request);
  }


  public uploadFile(request: UploadFileRequest): Observable<void> {

    if (!request) {
      return throwApiClientError('request required');
    }
    if (!request.objectId) {
      return throwApiClientError('objectId required');
    }
    if (!request.path) {
      return throwApiClientError('path required');
    }
    if (!request.model) {
      return throwApiClientError('model required');
    }
    if (!request.file) {
      return throwApiClientError('file required');
    }

    //todo: GA: WTF? casing ?!
    const apiUrl = `${this.baseUrl}/storage/object/files/upload?ObjectId=${request.objectId}&Model=${request.model}&Path=${request.path}`;
    return this.http.post<void>(apiUrl, request.file);
  }

}

//todo: GA: encode path? what is path?
