import {Inject, Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {InfoModelApiBaseUrl} from '../urlTokens';
import {throwApiClientError} from '../common';
import {
  CreateObjectRequest,
  GetAllModelsRequest,
  GetObjectRequest,
  GremlinQueryRequest,
  UpdateObjectRequest
} from './objects.models';

@Injectable()
export class ObjectsService {

  constructor(@Inject(InfoModelApiBaseUrl) private baseUrl: string, private http: HttpClient) {
  }

  /**
   *  Function return exactly one object.
   *  One objectId can be assign to many Models.
   *  ModelId limits response to only one Model
   * @param objectId string, required
   * @param modelId string, required
   * @param isHolistic boolean, NOT required
   */
  public getObject<T>(request: GetObjectRequest): Observable<T> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.objectId) {
      return throwApiClientError('objectId required');
    }

    if (!request.modelId) {
      return throwApiClientError('modelId required');
    }

    const apiUrl = `${this.baseUrl}/Objects/${request.objectId}/models/${request.modelId}?isHolistic=${!!request.isHolistic}`;
    return this.http.get<T>(apiUrl);
  }

  /**
   * Method for updating InfoModel object
   * @param objectId string
   * @param modelId string
   * @param infoModelObject
   * @param dropReference
   */
  public updateObject(request: UpdateObjectRequest): Observable<void> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.modelId) {
      return throwApiClientError('modelId required');
    }

    if (!request.objectId) {
      return throwApiClientError('objectId required');
    }

    if (!request.infoModelObject) {
      return throwApiClientError('infoModelObject required');
    }

    const apiUrl = `${this.baseUrl}/Objects/${request.objectId}/models/${request.modelId}`;
    return this.http.put<void>(apiUrl, request.infoModelObject);
  }

  public getAllObjects<T>(limit?: number): Observable<{ data: T[] }> {
    let apiUrl = `${this.baseUrl}/Objects`;
    if (!!limit) {
      apiUrl += `?limit=${limit}`;
    }
    return this.http.get<{ data: T[] }>(apiUrl);
  }

  /**
   * Method to insert new InfoModel object.
   * @param model
   */
  public createObject<T>(request: CreateObjectRequest): Observable<T> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.infoModelObject) {
      return throwApiClientError('infoModelObject required');
    }

    const apiUrl = `${this.baseUrl}/Objects`;
    return this.http.post<T>(apiUrl, request.infoModelObject);

  }

  /**
   * Function return all ModelDefiniotions related with selected ObjectId
   * @param objectId string
   */
  public getAllModelsOfObject(request: GetAllModelsRequest): Observable<any> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.objectId) {
      return throwApiClientError('objectId required');
    }

    const apiUrl = `${this.baseUrl}/Objects/${request.objectId}/models`;
    return this.http.get<any>(apiUrl);

  }

  public gremlinQuery<T>(request: GremlinQueryRequest): Observable<T> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.query) {
      return throwApiClientError('query required');
    }

    const apiUrl = `${this.baseUrl}/Objects/query/gremlin`;
    return this.http.post<T>(apiUrl, request.query);

  }

}
