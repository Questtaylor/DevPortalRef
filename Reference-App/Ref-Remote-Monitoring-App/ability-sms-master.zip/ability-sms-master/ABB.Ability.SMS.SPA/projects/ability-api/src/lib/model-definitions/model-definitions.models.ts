export interface GetModelDefinitionsRequest {
  limit: number;
}

export interface GetModelDefinitionDetailsRequest {
  modelId: string;
  includeDeleted?: boolean;
}

export interface ModelDefinitionField {
  description?: string;
  enum?: any[];
  tags?: string[];

  //required for "array" dataType
  items?: PrimitiveValues;

  //required for "map" dataType
  values?: any;
}

export type PrimitiveValues = 'string' | 'number' | 'integer' | 'boolean';

export interface ModelDefinitionVariable extends ModelDefinitionField {
  dataType: PrimitiveValues | 'map' | 'array';
  attributes?: any;
}

export interface ModelDefinitionInputField extends ModelDefinitionField {
  dataType: PrimitiveValues | 'map' | 'array' | 'file';
}

export interface ModelDefinitionOutputField extends ModelDefinitionField {
  dataType: PrimitiveValues | 'map' | 'array';
}
export interface ModelDefinitionProperty extends ModelDefinitionVariable {
  isMandatory?: boolean;

  //not supported for "map"
  value?: string;
}

export interface ModelDefinitionPropertyCategory {
  [key: string]: ModelDefinitionProperty | ModelDefinitionPropertyCategory;
}

export interface ModelDefinitionVariableCategory {
  [key: string]: ModelDefinitionVariable | ModelDefinitionVariableCategory;
}

export interface ModelDefinitionAttributes {
  [key: string]: {
    dataType: PrimitiveValues;
    description?: string;
    enum?: any[];
    tags?: string[];
    appliesTo?: string[];
  };
}

export interface ModelDefinitionMethods {
  [key: string]: {
    description?: string;
    input?: {
      [key2: string]: ModelDefinitionInputField
    };
    output?: {
      [key2: string]: ModelDefinitionOutputField
    };
    errors?: any
  };
}

export interface ModelDefinition {
  modelId: string;
  name?: string;
  description?: string;
  tags?: string[];
  unique?: string[];
  components: {
    properties?: ModelDefinitionPropertyCategory;
    variables?: ModelDefinitionVariableCategory;
    methods?: ModelDefinitionMethods;
    attributes?: ModelDefinitionAttributes;
    references?: {};
  };
}
