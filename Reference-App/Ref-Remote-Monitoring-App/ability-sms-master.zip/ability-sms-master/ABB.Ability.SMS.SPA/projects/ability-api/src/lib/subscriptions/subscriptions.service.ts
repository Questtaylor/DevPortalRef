import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {DataAccessApiBaseUrl} from '../urlTokens';
import {CreateSubscriptionRequest, CreateSubscriptionResponse, RefreshSubscriptionRequest, RefreshSubscriptionResponse, DeleteSubscriptionRequest} from './subscriptions.models';
import {throwApiClientError} from '../common';

@Injectable()
export class SubscriptionsService {

  constructor(@Inject(DataAccessApiBaseUrl) private baseUrl: string, private http: HttpClient) {
  }

  /**
   * Used to create a hot path subscription to servicebus to retrieve hot data based on the requested filter.
   * @param request
   */
  public createSubscription(request: CreateSubscriptionRequest): Observable<CreateSubscriptionResponse> {

    if (!request) {
      return throwApiClientError('request required');
    }
    if (!request.type) {
      return throwApiClientError('type required');
    }
    if (!request.subscriptionTTL) {
      return throwApiClientError('subscriptionTTL required');
    }
    if (request.subscriptionTTL < 5) {
      return throwApiClientError('subscriptionTTL too low (min 5)');
    }
    if (request.subscriptionTTL > 43200) {
      return throwApiClientError('subscriptionTTL too high (max 43200)');
    }

    if (!request.sasTokenTTL) {
      return throwApiClientError('sasTokenTTL required');
    }
    if (request.sasTokenTTL < 5) {
      return throwApiClientError('sasTokenTTL too low (min 5)');
    }
    if (request.sasTokenTTL > 43200) {
      return throwApiClientError('sasTokenTTL too high (max 43200)');
    }

    const apiUrl = `${this.baseUrl}/Subscriptions/${request.type}`;
    return this.http.post<CreateSubscriptionResponse>(apiUrl, request);
  }

  /**
   * Provides the ability to get a refreshed new sas token
   * @param request
   */
  public refreshSasToken(request: RefreshSubscriptionRequest): Observable<RefreshSubscriptionResponse> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.subscriptionId) {
      return throwApiClientError('subscriptionId required');
    }

    if (!request.type) {
      return throwApiClientError('type required');
    }

    if (!request.payload) {
      return throwApiClientError('payload required');
    }

    if (!request.payload.sasTokenTTL) {
      return throwApiClientError('payload.sasTokenTTL required');
    }

    const apiUrl = `${this.baseUrl}/Subscriptions/${request.type}/${request.subscriptionId}`;
    return this.http.put<RefreshSubscriptionResponse>(apiUrl, request.payload);

  }

  /**
   * Deletes a subscription from servicebus.
   * @param request
   */
  public deleteSubscription(request: DeleteSubscriptionRequest): Observable<void> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.subscriptionId) {
      return throwApiClientError('subscriptionId required');
    }

    if (!request.type) {
      return throwApiClientError('type required');
    }

    const apiUrl = `${this.baseUrl}/Subscriptions/${request.type}/${request.subscriptionId}`;
    return this.http.delete<void>(apiUrl);

  }

}
