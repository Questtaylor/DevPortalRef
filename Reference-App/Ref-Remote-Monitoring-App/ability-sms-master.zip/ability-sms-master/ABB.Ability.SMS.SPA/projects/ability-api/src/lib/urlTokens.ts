import {InjectionToken} from '@angular/core';

export const ReferenceUiApiBaseUrl = new InjectionToken<string>('ReferenceUiApiBaseUrl');
export const InfoModelApiBaseUrl = new InjectionToken<string>('InfoModelApiBaseUrl');
export const TypeDefinitionApiBaseUrl = new InjectionToken<string>('TypeDefinitionApiBaseUrl');
export const DataAccessApiBaseUrl = new InjectionToken<string>('DataAccessApiBaseUrl');
export const ArsBaseUrl = new InjectionToken<string>('ArsBaseUrl');
