import {TestBed} from '@angular/core/testing';
import {ObjectsService} from './objects.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {InfoModelApiBaseUrl} from '../urlTokens';

import {
  CreateObjectRequest,
  GetAllModelsRequest,
  GetObjectRequest,
  GremlinQueryRequest,
  UpdateObjectRequest
} from './objects.models';

import {
  assertExecutionWithCompleteInput,
  assertExecutionWithIncompleteInput,
  assertServiceCreation
} from '../common.spec';

describe('ObjectsService', () => {

  const baseUrl = 'http://testMethod.com';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        ObjectsService,
        {
          provide: InfoModelApiBaseUrl,
          useValue: 'http://testMethod.com'
        }
      ]
    });
  });

  it('should be created', () => {
    assertServiceCreation<ObjectsService>(ObjectsService);
  });

  describe('getObject<T>', () => {

    it('should return model with implicit isHolistic=false', (done: DoneFn) => {

      const callMethodRequest: GetObjectRequest = {
        modelId: '123',
        objectId: '123'
      };

      const responseIsHolisticFalse = {dummy: false};

      assertGettingModelWithCompleteInput(callMethodRequest, `${baseUrl}/Objects/${callMethodRequest.objectId}/models/${callMethodRequest.modelId}?isHolistic=false`, responseIsHolisticFalse, done);
    });

    it('should return model with explicit isHolistic=true', (done: DoneFn) => {

      const callMethodRequest: GetObjectRequest = {
        modelId: '123',
        objectId: '123',
        isHolistic: true
      };

      const responseIsHolisticFalse = {dummy: true};

      assertGettingModelWithCompleteInput(callMethodRequest, `${baseUrl}/Objects/${callMethodRequest.objectId}/models/${callMethodRequest.modelId}?isHolistic=true`, responseIsHolisticFalse, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input = undefined;

      assertGettingModelWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no modelId', (done: DoneFn) => {
      const expectedError = 'modelId required';
      const input: GetObjectRequest = {
        modelId: undefined,
        objectId: 'asd'
      };

      assertGettingModelWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no objectId', (done: DoneFn) => {
      const expectedError = 'objectId required';
      const input: GetObjectRequest = {
        modelId: 'asdqwe',
        objectId: undefined
      };

      assertGettingModelWithIncompleteInput(input, expectedError, done);
    });

    function assertGettingModelWithIncompleteInput(input: GetObjectRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ObjectsService>(ObjectsService, (service) => service.getObject<any>(input), expectedError, done);
    }

    function assertGettingModelWithCompleteInput(input: GetObjectRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {
      assertExecutionWithCompleteInput<ObjectsService>(
        ObjectsService,
        (service) => service.getObject<any>(input),
        mockResponseBody,
        done,
        expectedUrl,
        'GET',
        undefined
      );
    }

  });

  describe('updateObject<T>', () => {

    it('should update object', (done: DoneFn) => {

      const input: UpdateObjectRequest = {modelId: 'popo', objectId: '123', infoModelObject: {}};

      const responseIsHolisticFalse = {dummy: false};

      assertUpdatingObjectWithCompleteInput(input, `${baseUrl}/Objects/${input.objectId}/models/${input.modelId}`, responseIsHolisticFalse, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: UpdateObjectRequest = undefined;

      assertUpdatingObjectWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no modelId', (done: DoneFn) => {
      const expectedError = 'modelId required';
      const input: UpdateObjectRequest = {modelId: undefined, objectId: '123', infoModelObject: {}};

      assertUpdatingObjectWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no objectId', (done: DoneFn) => {
      const expectedError = 'objectId required';
      const input: UpdateObjectRequest = {modelId: '1asd', objectId: undefined, infoModelObject: {}};

      assertUpdatingObjectWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no infoModelObject', (done: DoneFn) => {
      const expectedError = 'infoModelObject required';
      const input: UpdateObjectRequest = {modelId: 'asdq2', objectId: '123', infoModelObject: undefined};

      assertUpdatingObjectWithIncompleteInput(input, expectedError, done);
    });

    function assertUpdatingObjectWithCompleteInput(input: UpdateObjectRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {

      assertExecutionWithCompleteInput<ObjectsService>(
        ObjectsService,
        (service) => service.updateObject(input),
        mockResponseBody,
        done,
        expectedUrl,
        'PUT',
        input.infoModelObject
      );
    }

    function assertUpdatingObjectWithIncompleteInput(input: UpdateObjectRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ObjectsService>(ObjectsService, (service) => service.updateObject(input), expectedError, done);
    }
  });

  describe('getAllObjects<T>', () => {
    it('should get all objects without explicit limit', (done: DoneFn) => {

      const mockResponseBody = {dummy: false};

      assertExecutionWithCompleteInput<ObjectsService>(
        ObjectsService,
        (service) => service.getAllObjects<any>(),
        mockResponseBody,
        done,
        `${baseUrl}/Objects`,
        'GET',
        undefined
      );
    });

    it('should get all objects with explicit limit', (done: DoneFn) => {

      const mockResponseBody = {dummy: false};

      assertExecutionWithCompleteInput<ObjectsService>(
        ObjectsService,
        (service) => service.getAllObjects<any>(123),
        mockResponseBody,
        done,
        `${baseUrl}/Objects?limit=123`,
        'GET',
        undefined
      );
    });
  });

  describe('createObject<T>', () => {

    it('should create object', (done: DoneFn) => {

      const input: CreateObjectRequest = {infoModelObject: {}};

      const responseIsHolisticFalse = {dummy: false};

      assertCreatingObjectWithCompleteInput(input, `${baseUrl}/Objects`, responseIsHolisticFalse, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: CreateObjectRequest = undefined;

      assertCreatingObjectWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no infoModelObject', (done: DoneFn) => {
      const expectedError = 'infoModelObject required';
      const input: CreateObjectRequest = {infoModelObject: undefined};

      assertCreatingObjectWithIncompleteInput(input, expectedError, done);
    });

    function assertCreatingObjectWithCompleteInput(input: CreateObjectRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {
      assertExecutionWithCompleteInput<ObjectsService>(
        ObjectsService,
        (service) => service.createObject<any>(input),
        mockResponseBody,
        done,
        expectedUrl,
        'POST',
        input.infoModelObject
      );
    }

    function assertCreatingObjectWithIncompleteInput(input: CreateObjectRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ObjectsService>(ObjectsService, (service) => service.createObject<any>(input), expectedError, done);
    }
  });

  describe('getAllModelsOfObject', () => {

    it('should get all models of object', (done: DoneFn) => {

      const input: GetAllModelsRequest = {objectId: 'asdqwe'};

      const response = {dummy: false};

      assertGettingAllModelsWithCompleteInput(input, `${baseUrl}/Objects/${input.objectId}/models`, response, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: GetAllModelsRequest = undefined;

      assertGettingAllModelsWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no objectId', (done: DoneFn) => {
      const expectedError = 'objectId required';
      const input: GetAllModelsRequest = {objectId: undefined};

      assertGettingAllModelsWithIncompleteInput(input, expectedError, done);
    });

    function assertGettingAllModelsWithCompleteInput(input: GetAllModelsRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {
      assertExecutionWithCompleteInput<ObjectsService>(
        ObjectsService,
        (service) => service.getAllModelsOfObject(input),
        mockResponseBody,
        done,
        expectedUrl,
        'GET',
        undefined
      );
    }

    function assertGettingAllModelsWithIncompleteInput(input: GetAllModelsRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ObjectsService>(ObjectsService, (service) => service.getAllModelsOfObject(input), expectedError, done);
    }
  });

  describe('gremlinQuery', () => {

    it('should get all models of object', (done: DoneFn) => {

      const input: GremlinQueryRequest = {query: 'asdqwe'};

      const response = {dummy: false};

      assertGettingAllModelsWithCompleteInput(input, `${baseUrl}/Objects/query/gremlin`, response, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: GremlinQueryRequest = undefined;

      assertGettingAllModelsWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no query', (done: DoneFn) => {
      const expectedError = 'query required';
      const input: GremlinQueryRequest = {query: undefined};

      assertGettingAllModelsWithIncompleteInput(input, expectedError, done);
    });

    function assertGettingAllModelsWithCompleteInput(input: GremlinQueryRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {
      assertExecutionWithCompleteInput<ObjectsService>(
        ObjectsService,
        (service) => service.gremlinQuery<any>(input),
        mockResponseBody,
        done,
        expectedUrl,
        'POST',
        input.query
      );
    }

    function assertGettingAllModelsWithIncompleteInput(input: GremlinQueryRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ObjectsService>(ObjectsService, (service) => service.gremlinQuery(input), expectedError, done);
    }
  });
});
