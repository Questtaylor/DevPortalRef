import {TestBed} from '@angular/core/testing';

import {FilesService} from './files.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {DataAccessApiBaseUrl} from '../urlTokens';
import {assertExecutionWithCompleteInput, assertExecutionWithIncompleteInput, assertServiceCreation} from '../common.spec';
import {DeleteFileRequest, DownloadFileRequest, SearchFilesRequest, UploadFileRequest} from './files.models';

describe('FilesService', () => {

  const baseUrl = 'http://testMethod.com';
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: DataAccessApiBaseUrl,
          useValue: baseUrl
        },
        FilesService
      ]
    });
  });

  it('should be created', () => {
    assertServiceCreation<FilesService>(FilesService);
  });

  describe('searchFiles', () => {

    it('should search files with explicit limit', (done: DoneFn) => {
      const input: SearchFilesRequest = {filter: `objectId = '123'`, limit: 250};
      const mockResponseBody = {dummy: 123};

      assertFileSearchingWithCompleteInput(input, mockResponseBody, done, `${baseUrl}/storage/object/files/search?filter=objectId%20%3D%20'123'&limit=${input.limit}`);
    });

    it('should search files with default limit', (done: DoneFn) => {
      const input: SearchFilesRequest = {filter: `objectId = '123'`};
      const mockResponseBody = {dummy: 123};

      assertFileSearchingWithCompleteInput(input, mockResponseBody, done, `${baseUrl}/storage/object/files/search?filter=objectId%20%3D%20'123'`);
    });

    it('should fail on empty request', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: SearchFilesRequest = undefined;

      assertFileSearchingWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty filter', (done: DoneFn) => {
      const expectedError = 'filter required';
      const input: SearchFilesRequest = {filter: undefined, limit: 250};

      assertFileSearchingWithIncompleteInput(input, expectedError, done);
    });

    function assertFileSearchingWithCompleteInput(input: SearchFilesRequest, mockResponseBody: any, done: DoneFn, expectedUrl: string) {
      assertExecutionWithCompleteInput<FilesService>(
        FilesService,
        (service) => service.searchFiles(input),
        mockResponseBody,
        done,
        expectedUrl,
        'GET',
        undefined
      );
    }

    function assertFileSearchingWithIncompleteInput(input: SearchFilesRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<FilesService>(FilesService, (service) => service.searchFiles(input), expectedError, done);
    }
  });

  describe('downloadFile', () => {

    it('should download file', (done: DoneFn) => {
      const input: DownloadFileRequest = {objectId: 'asdqwe', model: 'avbb', path: 'qweqwe'};
      const mockResponseBody: Blob = null;

      assertDownloadingFileWithCompleteInput(input, mockResponseBody, done, `${baseUrl}/storage/object/files/download`);
    });

    it('should fail on empty request', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: DownloadFileRequest = undefined;

      assertDownloadingFileWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty objectId', (done: DoneFn) => {
      const expectedError = 'objectId required';
      const input: DownloadFileRequest = {objectId: undefined, model: 'avbb', path: 'qweqwe'};

      assertDownloadingFileWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty model', (done: DoneFn) => {
      const expectedError = 'model required';
      const input: DownloadFileRequest = {objectId: 'asdqwe', model: undefined, path: 'qweqwe'};

      assertDownloadingFileWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty path', (done: DoneFn) => {
      const expectedError = 'path required';
      const input: DownloadFileRequest = {objectId: 'asdqwe', model: 'avbb', path: undefined};

      assertDownloadingFileWithIncompleteInput(input, expectedError, done);
    });

    function assertDownloadingFileWithCompleteInput(input: DownloadFileRequest, mockResponseBody: any, done: DoneFn, expectedUrl: string) {
      assertExecutionWithCompleteInput<FilesService>(
        FilesService,
        (service) => service.downloadFile(input),
        mockResponseBody,
        done,
        expectedUrl,
        'POST',
        input,
        'blob'
      );
    }

    function assertDownloadingFileWithIncompleteInput(input: DownloadFileRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<FilesService>(FilesService, (service) => service.downloadFile(input), expectedError, done);
    }
  });

  describe('deleteFile', () => {

    it('should delete file', (done: DoneFn) => {
      const input: DeleteFileRequest = {objectId: 'asdqwe', model: 'avbb', path: 'qweqwe'};
      const mockResponseBody = {dummy: 123};

      assertDeletingFileWithCompleteInput(input, mockResponseBody, done, `${baseUrl}/storage/object/files/delete`);
    });

    it('should fail on empty request', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: DeleteFileRequest = undefined;

      assertDeletingFileWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty objectId', (done: DoneFn) => {
      const expectedError = 'objectId required';
      const input: DeleteFileRequest = {objectId: undefined, model: 'avbb', path: 'qweqwe'};

      assertDeletingFileWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty model', (done: DoneFn) => {
      const expectedError = 'model required';
      const input: DeleteFileRequest = {objectId: 'asdqwe', model: undefined, path: 'qweqwe'};

      assertDeletingFileWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty path', (done: DoneFn) => {
      const expectedError = 'path required';
      const input: DeleteFileRequest = {objectId: 'asdqwe', model: 'avbb', path: undefined};

      assertDeletingFileWithIncompleteInput(input, expectedError, done);
    });

    function assertDeletingFileWithCompleteInput(input: DeleteFileRequest, mockResponseBody: any, done: DoneFn, expectedUrl: string) {
      assertExecutionWithCompleteInput<FilesService>(
        FilesService,
        (service) => service.deleteFile(input),
        mockResponseBody,
        done,
        expectedUrl,
        'POST',
        input
      );
    }

    function assertDeletingFileWithIncompleteInput(input: DeleteFileRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<FilesService>(FilesService, (service) => service.deleteFile(input), expectedError, done);
    }
  });

  describe('uploadFile', () => {

    it('should upload file', (done: DoneFn) => {
      const input: UploadFileRequest = {objectId: 'asdqwe', model: 'avbb', path: 'qweqwe', file: new FormData()};
      const mockResponseBody = {dummy: 123};

      assertUploadingFileWithCompleteInput(input, mockResponseBody, done, `${baseUrl}/storage/object/files/upload?ObjectId=${input.objectId}&Model=${input.model}&Path=${input.path}`);
    });

    it('should fail on empty request', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: UploadFileRequest = undefined;

      assertUploadingFileWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty objectId', (done: DoneFn) => {
      const expectedError = 'objectId required';
      const input: UploadFileRequest = {objectId: undefined, model: 'avbb', path: 'qweqwe', file: new FormData()};

      assertUploadingFileWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty model', (done: DoneFn) => {
      const expectedError = 'model required';
      const input: UploadFileRequest = {objectId: 'asdqwe', model: undefined, path: 'qweqwe', file: new FormData()};

      assertUploadingFileWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty path', (done: DoneFn) => {
      const expectedError = 'path required';
      const input: UploadFileRequest = {objectId: 'asdqwe', model: 'avbb', path: undefined, file: new FormData()};

      assertUploadingFileWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty file', (done: DoneFn) => {
      const expectedError = 'file required';
      const input: UploadFileRequest = {objectId: 'asdqwe', model: 'avbb', path: 'qweqwe', file: undefined};

      assertUploadingFileWithIncompleteInput(input, expectedError, done);
    });

    function assertUploadingFileWithCompleteInput(input: UploadFileRequest, mockResponseBody: any, done: DoneFn, expectedUrl: string) {
      assertExecutionWithCompleteInput<FilesService>(
        FilesService,
        (service) => service.uploadFile(input),
        mockResponseBody,
        done,
        expectedUrl,
        'POST',
        input.file
      );
    }

    function assertUploadingFileWithIncompleteInput(input: UploadFileRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<FilesService>(FilesService, (service) => service.uploadFile(input), expectedError, done);
    }
  });

});
