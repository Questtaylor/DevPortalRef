import {TestBed} from '@angular/core/testing';

import {DataService} from './data.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {DataAccessApiBaseUrl} from '../urlTokens';
import {assertExecutionWithCompleteInput, assertExecutionWithIncompleteInput, assertServiceCreation} from '../common.spec';
import {GetDataAggregatedRequest, GetDataAggregatedRequestSelectProperties, GetDataRawRequest} from './data.models';

describe('DataService', () => {
  const baseUrl = 'http://testMethod.com';
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: DataAccessApiBaseUrl,
          useValue: baseUrl
        },
        DataService
      ]
    });
  });

  it('should be created', () => {
    assertServiceCreation<DataService>(DataService);
  });

  describe('getDataRaw', () => {

    it('should get raw data', (done: DoneFn) => {
      const input: GetDataRawRequest = {date: {from: 'asdasd'}, requestType: 'alarms'};
      const mockResponseBody = {dummy: 123};

      assertGettingRawDataWithCompleteInput(input, mockResponseBody, done, `${baseUrl}/data/${input.requestType}`);
    });

    it('should fail on empty request', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: GetDataRawRequest = undefined;

      assertGettingRawDataWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty requestType', (done: DoneFn) => {
      const expectedError = 'requestType required';
      const input: GetDataRawRequest = {date: {from: 'asdasd'}, requestType: undefined};

      assertGettingRawDataWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty date', (done: DoneFn) => {
      const expectedError = 'date required';
      const input: GetDataRawRequest = {date: undefined, requestType: 'alarms'};

      assertGettingRawDataWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty date.from', (done: DoneFn) => {
      const expectedError = 'date.from required';
      const input: GetDataRawRequest = {date: {from: undefined}, requestType: 'alarms'};

      assertGettingRawDataWithIncompleteInput(input, expectedError, done);
    });

    function assertGettingRawDataWithCompleteInput(input: GetDataRawRequest, mockResponseBody: any, done: DoneFn, expectedUrl: string) {
      const expectedPayload = Object.assign({}, input);
      expectedPayload.requestType = undefined;

      assertExecutionWithCompleteInput<DataService>(
        DataService,
        (service) => service.getDataRaw<any>(input),
        mockResponseBody,
        done,
        expectedUrl,
        'POST',
        expectedPayload
      );
    }

    function assertGettingRawDataWithIncompleteInput(input: GetDataRawRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<DataService>(DataService, (service) => service.getDataRaw<any>(input), expectedError, done);
    }
  });

  describe('getDataAggregated', () => {

    it('should get aggregated data', (done: DoneFn) => {
      const input: GetDataAggregatedRequest = {date: {from: 'asdasd'}, requestType: 'alarms', select: {count: 'qwe'}};
      const mockResponseBody = {dummy: 123};

      assertGettingAggregatedDataWithCompleteInput(input, mockResponseBody, done, `${baseUrl}/data/${input.requestType}`);
    });

    it('should fail on empty request', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: GetDataAggregatedRequest = undefined;

      assertGettingAggregatedDataWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty requestType', (done: DoneFn) => {
      const expectedError = 'requestType required';
      const input: GetDataAggregatedRequest = {date: {from: 'asdasd'}, requestType: undefined, select: {count: 'qwe'}};

      assertGettingAggregatedDataWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty date', (done: DoneFn) => {
      const expectedError = 'date required';
      const input: GetDataAggregatedRequest = {date: undefined, requestType: 'alarms', select: {count: 'qwe'}};

      assertGettingAggregatedDataWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty date.from', (done: DoneFn) => {
      const expectedError = 'date.from required';
      const input: GetDataAggregatedRequest = {date: {from: undefined}, requestType: 'alarms', select: {count: 'qwe'}};

      assertGettingAggregatedDataWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty select', (done: DoneFn) => {
      const expectedError = 'select required';
      const input: GetDataAggregatedRequest = {date: {from: 'asdasd'}, requestType: 'alarms', select: undefined};

      assertGettingAggregatedDataWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no select item', (done: DoneFn) => {
      const expectedError = `select object has to define at least one property: ${GetDataAggregatedRequestSelectProperties.join(', ')}`;
      const input: GetDataAggregatedRequest = {date: {from: 'asdasd'}, requestType: 'alarms', select: {}};

      assertGettingAggregatedDataWithIncompleteInput(input, expectedError, done);
    });

    function assertGettingAggregatedDataWithCompleteInput(input: GetDataAggregatedRequest, mockResponseBody: any, done: DoneFn, expectedUrl: string) {
      const expectedPayload = Object.assign({}, input);
      expectedPayload.requestType = undefined;

      assertExecutionWithCompleteInput<DataService>(
        DataService,
        (service) => service.getDataAggregated<any>(input),
        mockResponseBody,
        done,
        expectedUrl,
        'POST',
        expectedPayload
      );
    }

    function assertGettingAggregatedDataWithIncompleteInput(input: GetDataAggregatedRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<DataService>(DataService, (service) => service.getDataAggregated<any>(input), expectedError, done);
    }
  });

});
