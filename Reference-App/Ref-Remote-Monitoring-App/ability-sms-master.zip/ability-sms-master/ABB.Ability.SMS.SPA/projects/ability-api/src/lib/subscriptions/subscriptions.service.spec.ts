import {TestBed} from '@angular/core/testing';
import {SubscriptionsService} from './subscriptions.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {DataAccessApiBaseUrl} from '../urlTokens';
import {CreateSubscriptionRequest, RefreshSubscriptionRequest, DeleteSubscriptionRequest} from './subscriptions.models';

import {
  assertExecutionWithCompleteInput,
  assertExecutionWithIncompleteInput,
  assertServiceCreation
} from '../common.spec';

describe('SubscriptionsService', () => {

  const baseUrl = 'http://testMethod.com';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: DataAccessApiBaseUrl,
          useValue: baseUrl
        },
        SubscriptionsService
      ]
    });
  });

  it('should be created', () => {
    assertServiceCreation<SubscriptionsService>(SubscriptionsService);
  });

  describe('createSubscription', () => {

    it('should create subscription with explicit filter', (done: DoneFn) => {

      const request: CreateSubscriptionRequest = {
        type: 'alarms',
        sasTokenTTL: 5,
        subscriptionTTL: 10,
        filter: 'asdasd'
      };

      const response = {dummy: 123};

      assertCreatingSubscriptionWithCompleteInput(request, `${baseUrl}/Subscriptions/${request.type}`, response, done);
    });

    it('should create subscription with no filter', (done: DoneFn) => {

      const request: CreateSubscriptionRequest = {
        type: 'alarms',
        sasTokenTTL: 5,
        subscriptionTTL: 10
      };

      const response = {dummy: 123};

      assertCreatingSubscriptionWithCompleteInput(request, `${baseUrl}/Subscriptions/${request.type}`, response, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const request: CreateSubscriptionRequest = undefined;

      assertCreatingSubscriptionWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on no type', (done: DoneFn) => {
      const expectedError = 'type required';
      const request: CreateSubscriptionRequest = {
        type: undefined,
        sasTokenTTL: 5,
        subscriptionTTL: 10
      };

      assertCreatingSubscriptionWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on no sasTokenTTL', (done: DoneFn) => {
      const expectedError = 'sasTokenTTL required';
      const request: CreateSubscriptionRequest = {
        type: 'alarms',
        sasTokenTTL: undefined,
        subscriptionTTL: 10
      };

      assertCreatingSubscriptionWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on too low sasTokenTTL', (done: DoneFn) => {
      const expectedError = 'sasTokenTTL too low (min 5)';
      const request: CreateSubscriptionRequest = {
        type: 'alarms',
        sasTokenTTL: 4,
        subscriptionTTL: 10
      };

      assertCreatingSubscriptionWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on too high sasTokenTTL', (done: DoneFn) => {
      const expectedError = 'sasTokenTTL too high (max 43200)';
      const request: CreateSubscriptionRequest = {
        type: 'alarms',
        sasTokenTTL: 43201,
        subscriptionTTL: 10
      };

      assertCreatingSubscriptionWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on no subscriptionTTL', (done: DoneFn) => {
      const expectedError = 'subscriptionTTL required';
      const request: CreateSubscriptionRequest = {
        type: 'alarms',
        sasTokenTTL: 5,
        subscriptionTTL: undefined
      };

      assertCreatingSubscriptionWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on too low subscriptionTTL', (done: DoneFn) => {
      const expectedError = 'subscriptionTTL too low (min 5)';
      const request: CreateSubscriptionRequest = {
        type: 'alarms',
        sasTokenTTL: 5,
        subscriptionTTL: 4
      };

      assertCreatingSubscriptionWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on too high subscriptionTTL', (done: DoneFn) => {
      const expectedError = 'subscriptionTTL too high (max 43200)';
      const request: CreateSubscriptionRequest = {
        type: 'alarms',
        sasTokenTTL: 5,
        subscriptionTTL: 43201
      };

      assertCreatingSubscriptionWithIncompleteInput(request, expectedError, done);
    });

    function assertCreatingSubscriptionWithIncompleteInput(input: CreateSubscriptionRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<SubscriptionsService>(SubscriptionsService, (service) => service.createSubscription(input), expectedError, done);
    }

    function assertCreatingSubscriptionWithCompleteInput(input: CreateSubscriptionRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {
      assertExecutionWithCompleteInput<SubscriptionsService>(
        SubscriptionsService,
        (service) => service.createSubscription(input),
        mockResponseBody,
        done,
        expectedUrl,
        'POST',
        input
      );
    }

  });

  describe('refreshSasToken', () => {

    it('should refresh token', (done: DoneFn) => {

      const request: RefreshSubscriptionRequest = {
        subscriptionId: 'asdasd',
        type: 'alarms',
        payload: {
          sasTokenTTL: 1235
        }
      };

      const response = {dummy: 123};

      assertRefreshingSasTokenWithCompleteInput(request, `${baseUrl}/Subscriptions/${request.type}/${request.subscriptionId}`, response, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const request: RefreshSubscriptionRequest = undefined;

      assertRefreshingSasTokenWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on no type', (done: DoneFn) => {
      const expectedError = 'type required';
      const request: RefreshSubscriptionRequest = {
        subscriptionId: 'asdasd',
        type: undefined,
        payload: {
          sasTokenTTL: 1235
        }
      };

      assertRefreshingSasTokenWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on no subscriptionId', (done: DoneFn) => {
      const expectedError = 'subscriptionId required';
      const request: RefreshSubscriptionRequest = {
        subscriptionId: undefined,
        type: 'alarms',
        payload: {
          sasTokenTTL: 1235
        }
      };

      assertRefreshingSasTokenWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on no payload.sasTokenTTL', (done: DoneFn) => {
      const expectedError = 'payload.sasTokenTTL required';
      const request: RefreshSubscriptionRequest = {
        subscriptionId: 'asdasd',
        type: 'alarms',
        payload: {
          sasTokenTTL: undefined
        }
      };

      assertRefreshingSasTokenWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on no payload', (done: DoneFn) => {
      const expectedError = 'payload required';
      const request: RefreshSubscriptionRequest = {
        subscriptionId: 'asdasd',
        type: 'alarms',
        payload: undefined
      };

      assertRefreshingSasTokenWithIncompleteInput(request, expectedError, done);
    });

    function assertRefreshingSasTokenWithIncompleteInput(input: RefreshSubscriptionRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<SubscriptionsService>(SubscriptionsService, (service) => service.refreshSasToken(input), expectedError, done);
    }

    function assertRefreshingSasTokenWithCompleteInput(input: RefreshSubscriptionRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {
      assertExecutionWithCompleteInput<SubscriptionsService>(
        SubscriptionsService,
        (service) => service.refreshSasToken(input),
        mockResponseBody,
        done,
        expectedUrl,
        'PUT',
        input.payload
      );
    }

  });

  describe('deleteSubscription', () => {

    it('should delete token', (done: DoneFn) => {

      const request: DeleteSubscriptionRequest = {
        subscriptionId: 'asdasd',
        type: 'alarms'
      };

      const response = {dummy: 123};

      assertRefreshingSasTokenWithCompleteInput(request, `${baseUrl}/Subscriptions/${request.type}/${request.subscriptionId}`, response, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const request: DeleteSubscriptionRequest = undefined;

      assertRefreshingSasTokenWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on no type', (done: DoneFn) => {
      const expectedError = 'type required';
      const request: DeleteSubscriptionRequest = {
        subscriptionId: 'asdasd',
        type: undefined
      };

      assertRefreshingSasTokenWithIncompleteInput(request, expectedError, done);
    });

    it('should fail on no subscriptionId', (done: DoneFn) => {
      const expectedError = 'subscriptionId required';
      const request: DeleteSubscriptionRequest = {
        subscriptionId: undefined,
        type: 'alarms'
      };

      assertRefreshingSasTokenWithIncompleteInput(request, expectedError, done);
    });

    function assertRefreshingSasTokenWithIncompleteInput(input: DeleteSubscriptionRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<SubscriptionsService>(SubscriptionsService, (service) => service.deleteSubscription(input), expectedError, done);
    }

    function assertRefreshingSasTokenWithCompleteInput(input: DeleteSubscriptionRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {
      assertExecutionWithCompleteInput<SubscriptionsService>(
        SubscriptionsService,
        (service) => service.deleteSubscription(input),
        mockResponseBody,
        done,
        expectedUrl,
        'DELETE',
        undefined
      );
    }

  });

});
