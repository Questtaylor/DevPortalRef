import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {
  GetLastTypeDefinitionRequest,
  AddNewTypeDefinitionRequest,
  GetTypeDefinitionsBasedOnModelIdTypeIdVersionRequest,
  GetVersionsResponse,
  GetVersionsRequest,
  BasicTypeDefinition
} from './type-definitions.models';
import {TypeDefinitionApiBaseUrl} from '../urlTokens';
import {throwApiClientError} from '../common';

@Injectable()
export class TypeDefinitionsService {

  constructor(@Inject(TypeDefinitionApiBaseUrl) private baseUrl: string, private http: HttpClient) {
  }

  public getVersions(request: GetVersionsRequest): Observable<GetVersionsResponse> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.modelId) {
      return throwApiClientError('modelId required');
    }

    if (!request.typeId) {
      return throwApiClientError('typeId required');
    }

    const apiUrl = `${this.baseUrl}/ModelDefinitions/${request.modelId}/types/${request.typeId}/versions`;
    return this.http.get<GetVersionsResponse>(apiUrl);
  }

  public getTypeDefinitionsBasedOnModelIdTypeIdVersion<T extends BasicTypeDefinition>(request: GetTypeDefinitionsBasedOnModelIdTypeIdVersionRequest): Observable<T> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.modelId) {
      return throwApiClientError('modelId required');
    }

    if (!request.typeId) {
      return throwApiClientError('typeId required');
    }

    if (!request.version) {
      return throwApiClientError('version required');
    }

    const apiUrl = `${this.baseUrl}/ModelDefinitions${request.modelId}/types/${request.typeId}/versions/${request.version}`;
    return this.http.get<T>(apiUrl);

  }

  public addNewTypeDefinition<T extends BasicTypeDefinition>(request: AddNewTypeDefinitionRequest): Observable<T> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.modelId) {
      return throwApiClientError('modelId required');
    }

    if (!request.typeDefinition) {
      return throwApiClientError('typeDefinition required');
    }

    const apiUrl = `${this.baseUrl}/ModelDefinitions/${request.modelId}/types`;
    return this.http.post<T>(apiUrl, request.typeDefinition);
  }

  public getLastTypeDefinition<T extends BasicTypeDefinition>(request: GetLastTypeDefinitionRequest): Observable<T> {

    if (!request) {
      return throwApiClientError('request required');
    }

    if (!request.modelId) {
      return throwApiClientError('modelId required');
    }

    if (!request.typeId) {
      return throwApiClientError('typeId required');
    }

    const apiUrl = `${this.baseUrl}/ModelDefinitions/${request.modelId}/types/${request.typeId}`;
    return this.http.get<T>(apiUrl);

  }

}
