import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {ReferenceUiApiBaseUrl} from '../urlTokens';

@Injectable()
export class LoggingService {

  constructor(@Inject(ReferenceUiApiBaseUrl) private referenceUiApiBaseUrl: string, private http: HttpClient) {
  }

  public async log(loggerName: string, logMsg: string, logLevel: 'trace' | 'debug' | 'info' | 'warn' | 'error' | 'fatal' = 'debug', logEvent: string = 'no-event'): Promise<void> {
    try {
      const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
      const apiUrl = `${this.referenceUiApiBaseUrl}/api/logs/add/${loggerName}/${logLevel}/${logEvent}`;

      await this.http.post<string>(apiUrl, logMsg || 'No log message provided', {headers}).toPromise();
    } catch (e) {
      console.error('cannot send logs to server');
      if (logLevel === 'error') {
        console.error(logMsg);
      } else {
        console.log(logMsg);
      }
      console.error(e);
    }
  }

}
