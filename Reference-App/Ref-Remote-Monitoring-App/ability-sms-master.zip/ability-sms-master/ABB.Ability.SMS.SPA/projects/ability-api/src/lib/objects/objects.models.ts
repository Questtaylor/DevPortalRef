export interface CreateObjectRequest {
  infoModelObject: {};
}

export interface GetObjectRequest {
  objectId: string;
  modelId: string;
  isHolistic?: boolean;
}

export interface GetAllModelsRequest {
  objectId: string;
}

export interface UpdateObjectRequest {
  objectId: string;
  modelId: string;
  infoModelObject: any;
}

export interface GremlinQueryRequest {
  query: string;
}

