export interface SearchFilesRequest {
  filter: string;
  limit?: number;
}

export interface SearchFilesResponse {
  hasMore: boolean;
  data: File[];
}

export interface File {
  objectId: string;
  model: string;
  path: string;
  timestamp: string;
  size: string;
}

export interface DownloadFileRequest {
  path: string;
  objectId: string;
  model: string;
}

export interface DownloadFileResponse {
  fileStream: {
    canRead: boolean;
    canSeek: boolean;
    canTimeout: boolean;
    canWrite: boolean;
    length: number;
    position: number;
    readTimeout: number;
    writeTimeout: number
  };
  contentType: string;
  fileDownloadName: string;
  lastModified: string;
  entityTag: {
    tag: {
      buffer: string;
      offset: number;
      length: number;
      value: string;
      hasValue: boolean
    };
    isWeak: boolean;
  };
}

export interface DeleteFileRequest {
  path: string;
  objectId: string;
  model: string;
}

export interface UploadFileRequest {
  file: FormData;
  path: string;
  objectId: string;
  model: string;
}
