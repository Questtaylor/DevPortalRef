import {HttpTestingController} from '@angular/common/http/testing';
import {inject} from '@angular/core/testing';
import {Observable} from 'rxjs';

export function assertServiceCreation<T>(token) {
  inject([token], async function (service: T) {
    await expect(service).toBeTruthy();
  })();
}

export function assertExecutionWithIncompleteInput<T>(serviceToken, serviceMethod: (s: T) => Observable<any>, expectedError: string, done: DoneFn) {
  inject([serviceToken], (service: T) => {
    serviceMethod(service).subscribe(
      () => reportTestFailureDueToLackOfApiClientError(),
      error => assertApiClientResponseError(error, expectedError, done)
    );
  })();
}

export function assertExecutionWithCompleteInput<T>(serviceToken, serviceMethod: (s: T) => Observable<any>, mockResponseBody: any, done: DoneFn,
                                                    expectedUrl: string, expectedVerb: 'GET' | 'POST' | 'PUT' | 'DELETE', expectedPayload: any,
                                                    expectedResponseType?: 'json' | 'blob'
) {
  inject([serviceToken, HttpTestingController], async (service: T, httpMock: HttpTestingController) => {

    serviceMethod(service).subscribe(
      data => assertApiClientResponse(data, mockResponseBody, done),
      error => reportTestFailureDueUnexpectedApiClientError(error)
    );

    await simulateHttpResponse(httpMock, expectedUrl, expectedVerb, mockResponseBody, expectedPayload, expectedResponseType);

  })();
}

function reportTestFailureDueUnexpectedApiClientError(actualError) {
  expect(actualError).toBeUndefined('Unexpected error');
}

function assertApiClientResponse(actualResponse, expectedResponse, done: DoneFn) {
  expect(actualResponse).toBeDefined('No response returned by the client');
  expect(actualResponse).toEqual(expectedResponse);
  done();
}

async function simulateHttpResponse(httpMock: HttpTestingController, expectedUrl: string, expectedVerb: 'GET' | 'POST' | 'PUT' | 'DELETE',
                                    mockResponseBody: any, expectedBody: any, expectedResponseType?: 'json' | 'blob') {
  const request = httpMock.expectOne(expectedUrl);

  await expect(request.cancelled).toBeFalsy();
  await expect(request.request.responseType).toEqual(expectedResponseType || 'json');
  await expect(request.request.method).toBe(expectedVerb);

  if (!!expectedBody) {
    await expect(request.request.body).toEqual(expectedBody);
  } else {
    await expect(!!request.request.body).toEqual(false, 'expected empty payload, but payload present');
  }

  const mockResponse = {
    status: 200, statusText: 'Method called'
  };

  request.flush(mockResponseBody, mockResponse);
}

function reportTestFailureDueToLackOfApiClientError() {
  expect(true).toBe(false, 'error supposed to be rised');
}

function assertApiClientResponseError(actualResponse, expectedResponseMessage, done: DoneFn) {
  expect(actualResponse).toBeDefined('No response returned by the client');
  expect(actualResponse.error).toEqual(expectedResponseMessage, 'Expected response to have property "error" with given text.');
  done();
}
