export interface CreateSubscriptionRequest {
  type: SubscriptionTypes;
  /*Minutes. From 5 to 43200*/
  subscriptionTTL: number;
  /*Minutes. From 5 to 43200*/
  sasTokenTTL: number;
  filter?: string;
}

export interface CreateSubscriptionResponse {
  /*name of the created subscription*/
  subscriptionId: string;

  /*fully qualified url of the created subscription*/
  connectionUrl: string;

  /*security token granting access to the created subscription for the requested sasTokenTTL time.*/
  sasToken: string;
}

export interface RefreshSubscriptionRequest {
  type: SubscriptionTypes;
  subscriptionId: string;
  payload: {
    sasTokenTTL: number;
  };
}

export interface RefreshSubscriptionResponse {
  subscriptionName: string;
  sasToken: string;
  namespace: string;
}

export interface DeleteSubscriptionRequest {
  subscriptionId: string;
  type: SubscriptionTypes;
}

export type SubscriptionTypes = 'variables' | 'events' | 'alarms' | 'platformEvents';
