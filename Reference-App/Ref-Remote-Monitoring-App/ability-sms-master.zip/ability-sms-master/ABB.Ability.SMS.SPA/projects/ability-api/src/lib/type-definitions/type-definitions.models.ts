import {
  ModelDefinitionAttributes,
  ModelDefinitionMethods,
  ModelDefinitionPropertyCategory,
  ModelDefinitionVariableCategory
} from '../model-definitions';

export interface GetVersionsResponse {
  model: string;
  typeId: string;
  versions: string[];
}

export interface GetVersionsRequest {
  modelId: string;
  typeId: string;
}

export interface GetTypeDefinitionsBasedOnModelIdTypeIdVersionRequest {
  modelId: string;
  typeId: string;
  version: string;
}

export interface GetLastTypeDefinitionRequest {
  modelId: string;
  typeId: string;
}

export interface AddNewTypeDefinitionRequest {
  modelId: string;
  typeDefinition: BasicTypeDefinition;
}

export interface BasicTypeDefinition {
  model: string;
  typeId: string;
  version: string;
  name?: string;
  description?: string;
  tags?: string[];
  unique?: string[];
  isExtensible?: boolean;
  baseTypes?: string[];
  relatedModels?: {
    [key: string]: {
      type: string;
      uniqueMapping?: {
        [propertyName: string]: string
      };
    }
  };

  properties?: ModelDefinitionPropertyCategory;
  variables?: ModelDefinitionVariableCategory;
  methods?: ModelDefinitionMethods;
  attributes?: ModelDefinitionAttributes;
  references?: {
    [key: string]: {
      isContainment?: boolean;
      isHierarchical?: boolean;
      description?: string;
      attributes?: {};
      to: {
        type: string;
        min?: number;
      }[];
    }
  };
}
