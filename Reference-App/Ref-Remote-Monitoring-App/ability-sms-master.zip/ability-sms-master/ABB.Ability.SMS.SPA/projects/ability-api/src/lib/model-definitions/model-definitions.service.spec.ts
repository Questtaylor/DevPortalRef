import {TestBed} from '@angular/core/testing';
import {ModelDefinitionsService} from './model-definitions.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {TypeDefinitionApiBaseUrl} from '../urlTokens';
import {GetModelDefinitionDetailsRequest, GetModelDefinitionsRequest, ModelDefinition} from './model-definitions.models';
import {
  assertExecutionWithCompleteInput,
  assertExecutionWithIncompleteInput,
  assertServiceCreation
} from '../common.spec';

describe('ModelDefinitionsService', () => {

  const baseUrl = 'modello definitio apio urlo';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: TypeDefinitionApiBaseUrl,
          useValue: baseUrl
        },
        ModelDefinitionsService
      ]
    });
  });

  it('should be created', () => {
    assertServiceCreation<ModelDefinitionsService>(ModelDefinitionsService);
  });

  describe('getModelDefinitions', () => {

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input = undefined;

      assertGettingModelDefinitionWithIncompleteInput(input, expectedError, done);
    });

    it('should get model definitions with user-defined limit', (done: DoneFn) => {
      const request: GetModelDefinitionsRequest = {
        limit: 256
      };

      const expectedLimit = 256;

      assertGettingModelDefinitionWithCompleteInput(request, done, expectedLimit);
    });

    it('should get model definitions with default limit', (done: DoneFn) => {
      const request: GetModelDefinitionsRequest = {
        limit: undefined
      };

      const expectedLimit = 100;

      assertGettingModelDefinitionWithCompleteInput(request, done, expectedLimit);
    });

    function assertGettingModelDefinitionWithCompleteInput(input: GetModelDefinitionsRequest, done: DoneFn, expectedLimit) {
      assertExecutionWithCompleteInput<ModelDefinitionsService>(
        ModelDefinitionsService,
        (service) => service.getModelDefinitions(input),
        [],
        done,
        `${baseUrl}/ModelDefinitions?limit=${expectedLimit}`,
        'GET',
        undefined
      );
    }

    function assertGettingModelDefinitionWithIncompleteInput(input: GetModelDefinitionsRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ModelDefinitionsService>(ModelDefinitionsService, (service) => service.getModelDefinitions(input), expectedError, done);
    }

  });

  describe('insertNewModelDefinition', () => {

    it('should insert new model definition', (done: DoneFn) => {
      const input: ModelDefinition = {modelId: 'dummy', components: {}};
      const mockResponseBody: ModelDefinition = {modelId: 'dummy ha ha', components: {properties: {}}};

      assertExecutionWithCompleteInput<ModelDefinitionsService>(
        ModelDefinitionsService,
        (service) => service.insertNewModelDefinition(input),
        mockResponseBody,
        done,
        `${baseUrl}/ModelDefinitions`,
        'POST',
        input
      );
    });

    it('should fail on empty request', (done: DoneFn) => {
      const expectedError = 'request required';
      const input = undefined;

      assertInsertingNewModelDefinitionWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty modelId', (done: DoneFn) => {
      const expectedError = 'modelId required';
      const input: ModelDefinition = {modelId: undefined, components: {}};

      assertInsertingNewModelDefinitionWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on null components', (done: DoneFn) => {
      const expectedError = 'components property required';
      const input: ModelDefinition = {modelId: 'mic check', components: undefined};

      assertInsertingNewModelDefinitionWithIncompleteInput(input, expectedError, done);
    });

    function assertInsertingNewModelDefinitionWithIncompleteInput(input: ModelDefinition, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ModelDefinitionsService>(ModelDefinitionsService, (service) => service.insertNewModelDefinition(input), expectedError, done);
    }
  });

  describe('getModelDefinitionDetailsRequest', () => {

    it('should get model definition by modelId', (done: DoneFn) => {
      const input: GetModelDefinitionDetailsRequest = {modelId: 'model-id'};
      const expectedUrl = `${baseUrl}/ModelDefinitions/${input.modelId}`;

      assertGetModelDefinitionByModelWithCompleteInput(input, done, expectedUrl);
    });

    it('should get model definition by modelId when model was deleted', (done: DoneFn) => {
      const input: GetModelDefinitionDetailsRequest = {modelId: 'model-id', includeDeleted: true};
      const expectedUrl = `${baseUrl}/ModelDefinitions/${input.modelId}?includeDeleted=true`;

      assertGetModelDefinitionByModelWithCompleteInput(input, done, expectedUrl);
    });

    it('should fail on empty request', (done: DoneFn) => {
      const expectedError = 'request required';
      const input = undefined;

      assertGetModelDefinitionByModelWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on empty model', (done: DoneFn) => {
      const expectedError = 'modelId required';
      const input: GetModelDefinitionDetailsRequest = {modelId: undefined};

      assertGetModelDefinitionByModelWithIncompleteInput(input, expectedError, done);
    });

    function assertGetModelDefinitionByModelWithCompleteInput(input: GetModelDefinitionDetailsRequest, done: DoneFn, expectedUrl: string) {
      const mockResponseBody = {testProp: true};

      assertExecutionWithCompleteInput<ModelDefinitionsService>(
        ModelDefinitionsService,
        (service) => service.getModelDefinitionByModelId(input),
        mockResponseBody,
        done,
        expectedUrl,
        'GET',
        undefined
      );
    }

    function assertGetModelDefinitionByModelWithIncompleteInput(input: GetModelDefinitionDetailsRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ModelDefinitionsService>(ModelDefinitionsService, (service) => service.getModelDefinitionByModelId(input), expectedError, done);
    }
  });
});
