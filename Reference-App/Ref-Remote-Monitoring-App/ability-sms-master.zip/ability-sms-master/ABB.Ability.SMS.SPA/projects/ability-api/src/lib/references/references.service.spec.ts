import {TestBed} from '@angular/core/testing';

import {ReferencesService} from './references.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {InfoModelApiBaseUrl} from '../urlTokens';
import {assertExecutionWithCompleteInput, assertExecutionWithIncompleteInput, assertServiceCreation} from '../common.spec';
import {CreateReferenceRequest, CreateReferenceResponse, GetReferenceRequest, GetReferencesOfObjectRequest} from './references.models';

describe('ReferencesService', () => {
  const baseUrl = 'http://testMethod.com';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        ReferencesService,
        {
          provide: InfoModelApiBaseUrl,
          useValue: 'http://testMethod.com'
        }
      ]
    });
  });

  it('should be created', () => {
    assertServiceCreation<ReferencesService>(ReferencesService);
  });

  describe('getReferencesById', () => {

    it('should get reference', (done: DoneFn) => {

      const input: GetReferenceRequest = {referenceId: 'asdqwe'};

      const response = {dummy: false};

      assertGettingReferenceWithCompleteInput(input, `${baseUrl}/references/${input.referenceId}`, response, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: GetReferenceRequest = undefined;

      assertGettingReferenceWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no referenceId', (done: DoneFn) => {
      const expectedError = 'referenceId required';
      const input: GetReferenceRequest = {referenceId: undefined};

      assertGettingReferenceWithIncompleteInput(input, expectedError, done);
    });

    function assertGettingReferenceWithCompleteInput(input: GetReferenceRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {
      assertExecutionWithCompleteInput<ReferencesService>(
        ReferencesService,
        (service) => service.getReferencesById(input),
        mockResponseBody,
        done,
        expectedUrl,
        'GET',
        undefined
      );
    }

    function assertGettingReferenceWithIncompleteInput(input: GetReferenceRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ReferencesService>(ReferencesService, (service) => service.getReferencesById(input), expectedError, done);
    }
  });

  describe('createReference', () => {

    it('should create reference', (done: DoneFn) => {

      const input: CreateReferenceRequest = {
        reference: {to: {objectId: 'ttt', model: 'qwe'}, name: 'sdfgw'},
        parentObjectId: 'aaa',
        parentModelId: 'bb'
      };

      const response: CreateReferenceResponse[] = [{referenceId: 'asdasd'}];

      assertCreatingReferenceWithCompleteInput(input, `${baseUrl}/Objects/${input.parentObjectId}/models/${input.parentModelId}/references/out`, response, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: CreateReferenceRequest = undefined;

      assertCreatingReferenceWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no parentObjectId', (done: DoneFn) => {
      const expectedError = 'parentObjectId required';
      const input: CreateReferenceRequest = {
        reference: {to: {objectId: 'ttt', model: 'qwe'}, name: 'sdfgw'},
        parentObjectId: undefined,
        parentModelId: 'bb'
      };

      assertCreatingReferenceWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no parentModelId', (done: DoneFn) => {
      const expectedError = 'parentModelId required';
      const input: CreateReferenceRequest = {
        reference: {to: {objectId: 'ttt', model: 'qwe'}, name: 'sdfgw'},
        parentObjectId: 'aaa',
        parentModelId: undefined
      };

      assertCreatingReferenceWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no reference', (done: DoneFn) => {
      const expectedError = 'reference required';
      const input: CreateReferenceRequest = {
        reference: undefined,
        parentObjectId: 'aaa',
        parentModelId: 'bb'
      };

      assertCreatingReferenceWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no reference.name', (done: DoneFn) => {
      const expectedError = 'reference.name required';
      const input: CreateReferenceRequest = {
        reference: {to: {objectId: 'ttt', model: 'qwe'}, name: undefined},
        parentObjectId: 'aaa',
        parentModelId: 'bb'
      };

      assertCreatingReferenceWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no reference.to', (done: DoneFn) => {
      const expectedError = 'reference.to required';
      const input: CreateReferenceRequest = {
        reference: {to: undefined, name: 'sdfgw'},
        parentObjectId: 'aaa',
        parentModelId: 'bb'
      };

      assertCreatingReferenceWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no reference.to.model', (done: DoneFn) => {
      const expectedError = 'reference.to.model required';
      const input: CreateReferenceRequest = {
        reference: {to: {objectId: 'ttt', model: undefined}, name: 'sdfgw'},
        parentObjectId: 'aaa',
        parentModelId: 'bb'
      };

      assertCreatingReferenceWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no reference.to.objectId', (done: DoneFn) => {
      const expectedError = 'reference.to.objectId required';
      const input: CreateReferenceRequest = {
        reference: {to: {objectId: undefined, model: 'qwe'}, name: 'sdfgw'},
        parentObjectId: 'aaa',
        parentModelId: 'bb'
      };

      assertCreatingReferenceWithIncompleteInput(input, expectedError, done);
    });

    function assertCreatingReferenceWithCompleteInput(input: CreateReferenceRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {
      assertExecutionWithCompleteInput<ReferencesService>(
        ReferencesService,
        (service) => service.createReference(input),
        mockResponseBody,
        done,
        expectedUrl,
        'POST',
        [input.reference]//array intentional
      );
    }

    function assertCreatingReferenceWithIncompleteInput(input: CreateReferenceRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ReferencesService>(ReferencesService, (service) => service.createReference(input), expectedError, done);
    }
  });

  describe('getReferencesOfObject', () => {

    it('should get references', (done: DoneFn) => {

      const input: GetReferencesOfObjectRequest = {modelId: 'asdqwe', objectId: '12313'};

      const response = {dummy: false};

      assertGettingReferencesWithCompleteInput(input, `${baseUrl}/objects/${input.objectId}/models/${input.modelId}/references`, response, done);
    });

    it('should fail on no input', (done: DoneFn) => {
      const expectedError = 'request required';
      const input: GetReferencesOfObjectRequest = undefined;

      assertGettingReferencesWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no modelId', (done: DoneFn) => {
      const expectedError = 'modelId required';
      const input: GetReferencesOfObjectRequest = {modelId: undefined, objectId: '12313'};

      assertGettingReferencesWithIncompleteInput(input, expectedError, done);
    });

    it('should fail on no objectId', (done: DoneFn) => {
      const expectedError = 'objectId required';
      const input: GetReferencesOfObjectRequest = {modelId: 'asdqwe', objectId: undefined};

      assertGettingReferencesWithIncompleteInput(input, expectedError, done);
    });

    function assertGettingReferencesWithCompleteInput(input: GetReferencesOfObjectRequest, expectedUrl: string, mockResponseBody: any, done: DoneFn) {
      assertExecutionWithCompleteInput<ReferencesService>(
        ReferencesService,
        (service) => service.getReferencesOfObject(input),
        mockResponseBody,
        done,
        expectedUrl,
        'GET',
        undefined
      );
    }

    function assertGettingReferencesWithIncompleteInput(input: GetReferencesOfObjectRequest, expectedError: string, done: DoneFn) {
      assertExecutionWithIncompleteInput<ReferencesService>(ReferencesService, (service) => service.getReferencesOfObject(input), expectedError, done);
    }
  });
});
