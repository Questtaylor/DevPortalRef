import {HttpErrorResponse} from '@angular/common/http';
import {throwError, Observable} from 'rxjs';

export function throwApiClientError(errorMessage: string): Observable<never> {
  return throwError(new HttpErrorResponse({
    error: errorMessage
    // status: 0
  }));
}
