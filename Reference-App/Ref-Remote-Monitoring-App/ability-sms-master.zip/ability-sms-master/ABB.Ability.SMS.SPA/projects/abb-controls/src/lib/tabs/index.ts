export * from './tabs.module';
