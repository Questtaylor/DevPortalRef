export interface IErrorTranslation {
  error: string;
  text: string;
}
